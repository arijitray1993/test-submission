# Method note - frame extension over the occupied ground floor

Issued with the method package of TWP-09 rev C clause 1.2: construction sequence, temporary-works
design, stability check sheet, workspace and resource occupancy report, constraint register and this note.

## Which document governs where the issued set disagrees with itself

* **TWP-09 revision C governs; revision B is superseded and not applied.** Rev B carries day 310
  completion, 4500 sf / 160 ft yard stock, 10 gangs, 12 crane hours, reshoring at 10 ft centres, a
  21-day full-strength age and early striking without reshoring. None of these is used or
  registered. The programme works to day 250, 3600 sf of soffit and 120 ft of face, 8 gangs, 10
  crane hours per shift, RS-16 reshoring at 8 ft centres and a 28-day full-strength age. Rev C's
  text and its parameter schedule (TWP-09_parameters.csv) agree on every value, and both are cited.
* **The issued activity list governs the superseded baseline programme rev A.** Rev A shows 4-day
  SHOR durations and leaves out the L3/L4 SCAF dependencies on the scaffold strike of the lift
  below. The package programmes the issued 2-day SHOR durations and keeps every issued dependency,
  including the SCST -> SCAF links. TWP-09 3.1 lets me add logic but not drop any; I added two
  rules: whole-zone-lift sequencing (7.2) and the strike age (6.3).
* **The design schedules govern the partial IFC exports.** The column, slab, storey and zone
  schedules are the takeoff, and neither IFC carries every column. MS-14 (facade replacement) is a
  different scope and is not used.
* The activity list and programme/precedence_index.csv carry the same 308 dependencies. The crane
  chart starts at 40 ft, so two standing positions that would put a zone centroid inside that
  radius (CP-W to Z-A-S and CP-C to Z-D-S, about 38.5 ft) are off the chart and are not used.
* Where TWP-09 is stricter than the adopted CFR text, TWP-09 is applied. Examples: the 2000 psf
  mud-sill bearing limit, rest platforms on every scaffold over 35 ft whatever the access means,
  and Option (3) demarcation under 1926.1408.

## Striking and reshoring method

Every one of the 42 slabs is struck at its mix's early-strike age and **reshored as the original
shores come out** (29 CFR 1926.703(b)(10), TWP-09 6.3). M40-PUMP slabs (bands A-D) are struck 7
days after the pour finishes and M50-HE slabs (bands E-G) 4 days after. The STRK start is never
earlier than POUR finish_day plus that age, so the age is counted from the day after the last pour
day. RS-16 reshores go in at 8 ft centres both ways, one per 8 x 8 ft cell of the zone's plan, rounded up in each direction (15-24 per zone). They go
in on the STRK day and come out no earlier than POUR finish_day + 28 (TWP-09 6.4, 1926.703(e)(2)),
which is the `remove_day` declared for each zone-lift. Leaving forms in place for 28 days was
rejected for two reasons. It would hold the full soffit area in the yard for 33 days per
zone-lift, and the 3600 sf yard could not then reach day 250. It would also hold each stair-core
zone shored for about 32 days, against 9 stair-core zone-lifts and a one-at-a-time egress limit.
In the yard the reshores count at 25 % of the zone's area, from the STRK day through POUR
finish_day + 28 inclusive. That is a day longer than the clause needs, kept as margin.

## Programme

All 294 issued activities are programmed with their issued durations. The last activity finishes
on day **200**, inside the day-250 completion (margin 50 days). Each zone-lift is
programmed tight: COL and SCAF, then two days of SHOR, then RBAR and POUR, then the strike age,
then STRK and SCST. The order of the zone-lifts was optimised to bring the sum of zone-lift finish
days, and so the 4 units/day programme price, as low as possible. In my own re-simulation the
peaks are: crane 9.69 of 10 h/day, gangs 7 of 8, yard soffit
3596 of 3600 sf, scaffold face 115.8 of 120 ft and laydown
15 of 16 units. The level above never starts in a zone until the level below has
finished there, and I leave at least one clear day between them (TWP-09 7.2). That clear day
means the rule holds even if a zone-lift's finish day is counted as a day in progress. At most one stair-core zone (Z-A-N, Z-B-S, Z-E-S) is shored on any day. Between
one stair-core zone being struck and the next being shored I leave at least one clear day, so
the two-means-of-egress limit holds whether or not the strike day is counted as a shored day.

## Price

Temporary works for all 42 zone-lifts total 25312 units (TWP-09 10.1). The programme
charge (TWP-09 10.2, 4 units per day to each zone-lift's last finish) totals 15916 units.
The mean zone-lift finishes on day 94.7. Each zone-lift uses the
cheapest design that passes every check: SP-16 at the widest grid its load allows, SF-3 frames
where the planks fit, SF-5 only where five heavy-duty planks are needed, and an adjacent diaphragm
in place of XB-1 bracing wherever the timing allows it.

## Lateral stability

The demand is the greater of 12 psf on the exposed area and 2 % of the shoring design load times
the area. The 2 % notional load governs every zone-lift: about 5.8 to 9.5 kip, against 0.8 to
1.5 kip from wind. 34 zone-lifts use the completed slab of an adjacent zone on the same
level. Each of those adjacent zone-lifts had finished, and its slab had passed its early-strike age
at least one clear day before the zone's shoring went up. The stability sheet records which slab
and the day it reached early-strike age. The other 8 use XB-1
cross-bracing at 4000 lb per braced bay, rounded up to cover the demand: L2-Z-A-S, L2-Z-E-N, L2-Z-E-S, L2-Z-F-N, L3-Z-A-S, L3-Z-E-N, L4-Z-A-N, L4-Z-E-N.

## The constraint that governs each zone

- **Z-A-N** (finishes L2/L3/L4 on days 37/61/81): it carries a stair core, so its shoring is programmed inside the single egress window of TWP-09 7.3 (one stair-core zone shored on any day); at L2 the ground floor below stays occupied, so the deck load of 15 psf takes the design load to 387.6 psf, SP-16 posts at 3.5 ft (79 % of 6000 lb) and a medium-duty scaffold; above L2 the post capacity governs: 372.6 psf on a 4.0 ft grid is 5962 lb per SP-16 post (99.4 %); from CP-C the radius is 105.1 ft and the rated capacity 9403 lb against an 8752 lb column, so crane capacity at radius is the next-tightest check (7.4 % margin).
- **Z-A-S** (finishes L2/L3/L4 on days 14/47/140): at L2 the ground floor below stays occupied, so the deck load of 15 psf takes the design load to 387.6 psf, SP-16 posts at 3.5 ft (79 % of 6000 lb) and a medium-duty scaffold; above L2 the post capacity governs: 372.6 psf on a 4.0 ft grid is 5962 lb per SP-16 post (99.4 %).
- **Z-B-N** (finishes L2/L3/L4 on days 152/173/189): at L2 the ground floor below stays occupied, so the deck load of 15 psf takes the design load to 387.6 psf, SP-16 posts at 3.5 ft (79 % of 6000 lb) and a medium-duty scaffold; above L2 the post capacity governs: 372.6 psf on a 4.0 ft grid is 5962 lb per SP-16 post (99.4 %); at 1227 sf it is the largest soffit and takes a third of the 3600 sf yard stock, so the yard governs when it can be shored; its 30.0 ft face needs 5 bays of 7 ft on SF-3, and the 35 ft run needs 3 tie columns at 30 ft maximum spacing.
- **Z-B-S** (finishes L2/L3/L4 on days 164/185/200): it carries a stair core, so its shoring is programmed inside the single egress window of TWP-09 7.3 (one stair-core zone shored on any day); at L2 the ground floor below stays occupied, so the deck load of 15 psf takes the design load to 387.6 psf, SP-16 posts at 3.5 ft (79 % of 6000 lb) and a medium-duty scaffold; above L2 the post capacity governs: 372.6 psf on a 4.0 ft grid is 5962 lb per SP-16 post (99.4 %); at 1178 sf it is the largest soffit and takes a third of the 3600 sf yard stock, so the yard governs when it can be shored; its 30.0 ft face needs 5 bays of 7 ft on SF-3, and the 35 ft run needs 3 tie columns at 30 ft maximum spacing.
- **Z-C-N** (finishes L2/L3/L4 on days 59/83/117): at L2 the ground floor below stays occupied, so the deck load of 15 psf takes the design load to 387.6 psf, SP-16 posts at 3.5 ft (79 % of 6000 lb) and a medium-duty scaffold; above L2 the post capacity governs: 372.6 psf on a 4.0 ft grid is 5962 lb per SP-16 post (99.4 %).
- **Z-C-S** (finishes L2/L3/L4 on days 95/118/176): at L2 the ground floor below stays occupied, so the deck load of 15 psf takes the design load to 387.6 psf, SP-16 posts at 3.5 ft (79 % of 6000 lb) and a medium-duty scaffold; above L2 the post capacity governs: 372.6 psf on a 4.0 ft grid is 5962 lb per SP-16 post (99.4 %).
- **Z-D-N** (finishes L2/L3/L4 on days 25/50/94): above L2 the post capacity governs: 372.6 psf on a 4.0 ft grid is 5962 lb per SP-16 post (99.4 %); its 30 in columns weigh up to 13674 lb, so crane capacity at radius governs the standing position (CP-C at 78.5 ft, 16114 lb).
- **Z-D-S** (finishes L2/L3/L4 on days 49/117/139): above L2 the post capacity governs: 372.6 psf on a 4.0 ft grid is 5962 lb per SP-16 post (99.4 %); its 30 in columns weigh up to 13674 lb, so crane capacity at radius governs the standing position (CP-E at 76.8 ft, 16851 lb).
- **Z-E-N** (finishes L2/L3/L4 on days 12/25/69): it is placed by crane and bucket, so the 75 psf live load gives 397.6 psf, SP-16 at 3.5 ft (81 %), a heavy-duty scaffold whose five PL-95 planks only fit the 5 ft SF-5 frame, and 8-9.5 crane hours per pour that govern the crane day.
- **Z-E-S** (finishes L2/L3/L4 on days 13/95/139): it carries a stair core, so its shoring is programmed inside the single egress window of TWP-09 7.3 (one stair-core zone shored on any day); it is placed by crane and bucket, so the 75 psf live load gives 397.6 psf, SP-16 at 3.5 ft (81 %), a heavy-duty scaffold whose five PL-95 planks only fit the 5 ft SF-5 frame, and 8-9.5 crane hours per pour that govern the crane day.
- **Z-F-N** (finishes L2/L3/L4 on days 14/60/82): it is placed by crane and bucket, so the 75 psf live load gives 397.6 psf, SP-16 at 3.5 ft (81 %), a heavy-duty scaffold whose five PL-95 planks only fit the 5 ft SF-5 frame, and 8-9.5 crane hours per pour that govern the crane day.
- **Z-F-S** (finishes L2/L3/L4 on days 24/71/105): it is placed by crane and bucket, so the 75 psf live load gives 397.6 psf, SP-16 at 3.5 ft (81 %), a heavy-duty scaffold whose five PL-95 planks only fit the 5 ft SF-5 frame, and 8-9.5 crane hours per pour that govern the crane day.
- **Z-G-N** (finishes L2/L3/L4 on days 105/127/150): it is placed by crane and bucket, so the 75 psf live load gives 397.6 psf, SP-16 at 3.5 ft (81 %), a heavy-duty scaffold whose five PL-95 planks only fit the 5 ft SF-5 frame, and 8-9.5 crane hours per pour that govern the crane day; from CP-C the radius is 102.6 ft and the rated capacity 9797 lb against an 8752 lb column, so crane capacity at radius is the next-tightest check (11.9 % margin); its 24.03 ft face needs 4 bays of 7 ft on SF-5.
- **Z-G-S** (finishes L2/L3/L4 on days 35/128/160): it is placed by crane and bucket, so the 75 psf live load gives 397.6 psf, SP-16 at 3.5 ft (81 %), a heavy-duty scaffold whose five PL-95 planks only fit the 5 ft SF-5 frame, and 8-9.5 crane hours per pour that govern the crane day; its 24.03 ft face needs 4 bays of 7 ft on SF-5.

## Margins applied

* **Shoring.** Post numbers are counted as a real layout: one post per s x s cell of the zone's
  plan, rounded up in each direction (Z-A-N at 3.5 ft is 6 x 12 = 72 posts). That is never fewer
  than area/s^2 (67 for Z-A-N), so no post carries more than s^2 of soffit. Utilisation is
  79-81 % at 3.5 ft centres and 99.4 % at 4.0 ft. The 4.0 ft grid is
  used only where 372.6 psf x 16 sf = 5961.6 lb is still at or below the 6000 lb rating. Every
  post is SP-16, because a 16 ft extension is needed against the required 13.83 ft and the SP-09
  and SP-13 posts are too short.
* **Planks.** The plank count covers the planks' own weight as well as 4 x MIL. Light duty uses
  3 planks (4500 lb against 3135 lb), medium 3 planks (4500 against 4135) and heavy 5 planks
  (7500 against 7225). The platform widths of 28.5 and 47.5 in exceed 18 in.
* **Guardrails, front edge and access.** Toprails are at 42 in, inside the 38-45 in band. The front
  edge sits 12 in from the work, against 14 in allowed. Guardrails run along the outer side and both
  ends of every platform level. The end guardrails also block the 18 in plank cantilevers on the
  7 ft bay systems (4.8). Rest platforms are fitted on every scaffold over 35 ft.
* **Ties and bearing.** Ties follow 1926.451(c)(1)(ii) exactly: the first at the horizontal member
  closest to the 4:1 height, then the highest member within 20 ft (SF-3) or 26 ft (SF-5), at both
  ends and at no more than 30 ft along the run. Frame lifts are rounded up, so L4 has 9 lifts for
  its 52.08 ft. Bearing is checked with a full bay on one leg over a 2x10 pad: under 1300 psf
  against 2000.
* **Crane.** The single tower crane works from the central hard stand CP-C for every zone the chart allows. Z-D-S (at about 38.5 ft from CP-C, inside the chart minimum radius) is served from CP-E. Every radius is on the chart (between 40 and 140 ft), and the capacity
  margin over the heaviest pick is at least 7.4 %. That minimum is at L3-Z-A-N. The work zone is
  demarcated at 140 ft, inside the permitted 145 ft (155 ft to the line less the 10 ft Table A
  distance).
* **Lateral bracing.** XB-1 braced bays are rounded up, so capacity over demand is at least 1.17 (L2-Z-E-N). A diaphragm is only claimed where the adjacent zone-lift has finished and its slab passed early-strike age at least one clear day before the shoring went up.
* **Day counting.** Day counting is conservative wherever the procedure is open to reading:
  * strike age counted from POUR finish_day;
  * shoring counted in the yard through the STRK day;
  * reshores held through day 28 inclusive;
  * laydown held through the pour finish day;
  * one clear day between stair-core shoring windows;
  * one clear day between successive zone-lifts in the same zone.

## Attribution

The building geometry (storey elevations, column grid and sections,
slab thickness, stair cores) used in this package is derived from the LivingBIM Dataset:
As-designed and As-built Dataset for an Academic Building including BIM 3d models, Point Clouds,
and Panoramic Images, DOI 10.5281/zenodo.17934615, licensed CC BY 4.0
(https://creativecommons.org/licenses/by/4.0/). The design schedules have been adapted for this
package.
