# DC-2 Helena Data Centre, Building A - Roof deck design basis

Project DC2-2026-014. Roof deck: NORDECK B-36, 1-1/2 in wide-rib (Type B), 36 in cover width, spanning 6 ft-0 in across the 26K9 joists in 3-span continuous lengths. All plan coordinates are project grid coordinates in feet (x along grids 1 to 9, y along grids A to G, origin at grid 1-A).

## 1. Governing documents and how conflicts were resolved

* **Document precedence - transmittal T-118.** Only the current revisions listed on T-118 were used: EOR-DC-RD-01 Rev 2 (criteria), LAT-2026-003 Rev 1, SNOW-2026-014 Rev 0, A-201 Rev C, M-401 Rev C, S-101 Rev 3, S-501 Rev 2, the DC2-A-STR Rev C model and cost plan CP-RD-2026 Rev 0.
* **Structural design criteria EOR-DC-RD-01 Rev 2 govern; Rev 1 (archive) is withdrawn.** Rev 1 told us to design the deck for the reduced roof live load (12 psf) and left the snow out of the seismic weight. Rev 2 clause 4.2 says the deck gets the unreduced Lr = 20 psf, because one panel only carries 18 sq ft, which is below the 200 sq ft reduction threshold. Clause 7.2 adds 20 % of pf to the seismic weight because pf > 30 psf. Clause 5.4 states the windward/leeward drift rules and the four wind directions, and clauses 9.3 and 10.4 add the classification and boundary/opening rules. Rev 2 was applied throughout.
* **Geometry of record - DC2-A-STR Rev C model (IFC, millimetres, divided by 304.8 to get feet).** Where the model and the drawings differ, the model governs (model note section 5, T-118 note 3.1, A-201 Rev C note 5). The equipment screen wall SCR-N sits at y = 163.67 to 164.33 ft, as on A-201 Rev C and M-401 Rev C. The withdrawn A-201 Rev B shows it at y = 158 ft and was not used. The model places SCR-E at x = 215.67 to 216.33 ft, y = 24 to 144 ft; the 2D sheets draw it as a line from y = 23.67 to 144.33 ft, and the model governs. Openings come from the model and S-101 Rev 3: RO-1 x 96-108, y 48-60; RO-2 x 132-144, y 120-132; RO-3 x 180-210, y 60-80. Obstruction heights come from the model and the rooftop equipment schedule. The schedule rows for DC-1 Building B are not on this roof and were ignored.
* **Ground snow load - SNOW-2026-014 (AHJ-accepted case study).** It gives pg = 63 psf on a Risk Category II basis, as UFC 3-301-01 para 2-4.5 / section 1608.2.3 requires. The Risk Category III importance factor Is = 1.10 is applied once, in pf. The Canyon Ferry met-station CSV is only a supporting record, and the mapped/USGS files do not give a ground snow load, so neither was used for pg.
* **Seismic parameters.** SDS = 0.44, SD1 = 0.24, Site Class D, SDC D, Ie = 1.25, R = 3.25, Omega_0 = 2.0, rho = 1.0, from criteria 7.1. These match the ASCE 7-22 RC III Site Class D design-map file. The ASCE 7-16 RC II Site Class C "2019 preliminary" file does not match the project basis and was not used.
* **Roof live load.** UFC 3-301-01 Table E-1 item 51 gives 20 psf for an ordinary flat roof (criteria 1.3 and 4.1). Snow and roof live load are not combined (4.4, 8.2).
* **Procurement.** 16 gage is a 14-week mill order, beyond the Owner's 9-week release-to-site allowance (OBD section 5, stock sheet), so it is not available. 22, 20 and 18 gage are ex stock in 2 to 4 weeks. UFC 3-301-01 section 2208.1 sets 22 gage as the thinnest permitted roof deck.
* **Archive reference design (Hall A, Butte 2019).** Not transferable (different site, building and risk category, and the product is discontinued). It was not used.
* **Openings.** No deck over framed openings (criteria 10.5, S-501 detail 3). The OSHA 1926.754(e)(2)(ii) practice of decking over openings is replaced by purpose-made covers meeting 1926.754(e)(3), as criteria 10.5 requires. Following the checking convention, every 6 x 6 ft cell an opening touches carries no deck. RO-3 therefore removes cells x 180-210, y 60-84.

## 2. Gravity basis

* Dead load: collateral 10.5 psf (roofing 4.5 + suspended MEP 6.0) plus deck self weight (22 ga 1.6 psf, 18 ga 2.5 psf). Rooftop equipment sits on curbs carried by reinforced framing and is not a uniform load on the deck (criteria 3.1).
* Roof live load Lr = 20 psf, unreduced (criteria 4.2).
* Flat roof snow: pf = 0.7 Ce Ct Is pg = 0.7 x 0.90 x 1.00 x 1.10 x 63 = 43.66 psf. Density gamma = 0.13 pg + 14 = 22.19 pcf; hb = pf/gamma = 1.968 ft; clear height hc = h - hb.
* Drifts follow criteria 5.4 exactly as written. hd = 0.43 lu^(1/3) (pg+10)^(1/4) - 1.5 with lu not less than 20 ft. Windward drift height is 0.75 hd with lu = fetch from the upwind roof edge to the face; leeward drift height is hd with lu = along-wind length of the obstruction. The shape is triangular: w = 4 hd at full height, or peak hc gamma and w = min(4hd^2/hc, 8hc) when truncated. All four wind directions are enveloped, not superimposed. Every obstruction with hc > 2 ft gets a drift on every face: the enclosure (12 ft), SCR-N (6 ft), SCR-E (7 ft) and all twelve rooftop units (7 to 9 ft). The parapet (3.5 ft, hc = 1.53 ft) uses the windward rule with lu = roof dimension.
* Each 6 x 6 ft cell carries the peak surcharge found anywhere inside it (criteria 5.4.7). The deck checks are ASD (criteria 8.1, 10.1):
  * strength: total load against the allowable load 1000 Fb Sn/(1.2 L^2), with Fb = 40/1.67 ksi. This gives 106.4 psf for 22 ga and 176.9 psf for 18 ga, which reproduces catalogue Table 3-1.
  * deflection: 0.0069 w L^4/(E I) under the live or snow load, limited to L/240 = 0.30 in.
  * bearing: interior reaction 1.1 wL against the Table 4-1 end reaction.

Reported drifts (envelope over the four wind directions):

| location | face | governing case | lu (ft) | peak surcharge (psf) | band (ft) |
|---|---|---|---|---|---|
| MEP-PH-1 | W | leeward from E | 120.0 | 104.28 | 60.00 to 41.20 |
| SCR-N | S | windward from S | 163.7 | 89.46 | 163.67 to 147.54 |
| PARAPET | N | windward from S | 180.0 | 34.01 | 179.33 to 167.07 |
| RTU-1 | E | windward from E | 204.0 | 98.17 | 36.00 to 53.70 |

Under one reading, SCR-N and SCR-E are thin walls whose end faces also form leeward drifts (lu = wall length). Those end strips were included. The deck was also checked with drifts from different obstructions in one wind direction superimposed, with these end strips left out.

## 3. Wind uplift basis

qh = 0.00256 Kz Kzt Kd Ke V^2 = 29.93 psf (V = 115 mph, Exposure C, Kz = 1.04, Kd = 0.85). a = 12.8 ft. Net uplift qh(GCp - GCpi): Zone 3 corners -101.2 psf, Zone 2 perimeter -74.2 psf, Zone 1 -47.3 psf, Zone 1-prime -32.3 psf (criteria Table 6-2).

Resistance is phi_t x Pnov x n / (3 ft x 6 ft), with phi_t = 0.50, plus 0.9 x (deck + roofing 4.5 psf). The MEP allowance is excluded. Every cell is checked against the most severe pressure zone it overlaps. On the 6 ft grid:

* Zone 3 covers the 18 x 18 ft corners, and only 18 ga 36/9 resists 101.2 psf (126.0 psf).
* Zone 2 covers the outer 18 ft band.
* Zone 1 covers the band 18 to 30 ft from the edge.

## 4. Seismic and lateral basis

* Effective seismic weight: pf = 43.66 psf > 30 psf, so W = 18 + 0.2 x 43.66 = 26.73 psf over the 240 x 180 ft roof plan, which is 1155 kip.
* Cs = SDS Ie/R = 0.1692, between 0.2 SDS Ie = 0.110 and 0.4 SDS Ie = 0.220. Single storey, so Fpx = V = Cs W = **195.4 kip**, applied uniformly over the plan by tributary area with accidental eccentricity 0.05 x plan dimension (9 ft for x, 12 ft for y) as a plan couple, both senses.
* Wind: 118.0 kip along x and 152.0 kip along y (LAT Table 4-1), half applied as a line load on each wall perpendicular to the force. Case 2 (75 %, eccentricity 0.15 B) was also run. Seismic governs every lateral check.
* In-plane model, as described in LAT-2026-003 section 7 and criteria 9.3:
  * shear panels one joist bay (6 ft) wide by one girder bay (30 ft) deep, each carrying constant shear flow with G' from catalogue Tables 5-1/5-3 for the zone specification. The five 6 ft strips stacked in a panel act in series, and a panel touching an opening carries no shear.
  * axial bars on every joist line (EA 87,580 kip) and girder line (221,850 kip), with the edge angle (74,240 kip) added on the four boundary lines.
  * each braced frame modelled as two springs of k/2 at its column lines (Table 3-1).
  * a small regularising spring (0.001 kip/in) on every DOF, which carries less than 0.5 % of the load in every case.
* Diaphragm shear is checked as phi_d Sn = 0.70 Sn per cell.
* The chord force is the largest axial force on the two perimeter chord lines. The collector force is the largest axial force in a perimeter member within one bay of a braced frame of that direction, amplified by Omega_0 = 2.0 in S10 and compared with the 58.0 kip splice capacity. The chord force is compared with the 38.0 kip splice capacity (LAT 6.2.1).
* Classification (criteria 9.3): the maximum in-plane deflection of the diaphragm (relative to the supporting frame lines) is compared with 2.0 x the average drift of the braced frames of that direction. In every case it stays below that value, so the roof is **semi-rigid** and was analysed with finite deck stiffness and frame springs. It is not assumed rigid or flexible.

| scenario | dir | max shear (plf) | max diaphragm deflection (in) | avg frame drift (in) | chord (kip) | collector (kip) | class |
|---|---|---|---|---|---|---|---|
| S05 | x | 385 | 0.54 | 0.77 | 11.5 | 15.1 | semi-rigid |
| S06 | y | 706 | 1.05 | 0.86 | 21.8 | 16.7 | semi-rigid |
| S07 | x | 642 | 0.91 | 1.59 | 19.2 | 25.6 | semi-rigid |
| S08 | y | 981 | 1.41 | 1.39 | 28.6 | 21.9 | semi-rigid |
| S10 | x | 642 | 0.91 | 1.59 | 19.2 | 51.2 (x2.0) | semi-rigid |

## 5. Zoning decisions

Constraints (criteria 10.2 to 10.4):

* not more than 2 gages, 3 attachment patterns, 12 zones and 14 rectangles on the 6 ft grid.
* sidelap connectors at 36 in maximum, so at least 2 per span.
* every zone touching the perimeter or an opening uses at least 36/7 with 3 sidelap connectors.
* button punch is not permitted on 18 ga.

Rectangles with the same specification are grouped as one zone, which avoids extra zone set-up costs.

| zone | gage | support | sidelap | per span | area (sf) | rectangles (x0,y0,x1,y1) |
|---|---|---|---|---|---|---|
| DZ-1 | 18 | 36/9 | SCREW-10 | 5 | 6912 | (0,0,60,18); (210,0,240,180); (0,156,18,180) |
| DZ-2 | 22 | 36/9 | BP | 3 | 5364 | (60,0,210,18); (96,18,108,48); (18,168,210,180) |
| DZ-3 | 22 | 36/9 | SCREW-10 | 5 | 2484 | (0,18,18,156) |
| DZ-4 | 18 | 36/7 | SCREW-10 | 3 | 27432 | (18,18,96,60); (108,18,210,60); (18,60,180,84); (18,84,210,120); (18,120,132,132); (144,120,210,132); (18,132,210,168) |

| zone | governing | shear demand/capacity (plf) | gravity demand/capacity (psf) | uplift demand/capacity (psf) |
|---|---|---|---|---|
| DZ-1 | S04 | 981 / 1226 | 160.9 / 176.9 | 101.2 / 126.0 |
| DZ-2 | S07 | 459 / 484 | 89.8 / 106.5 | 74.2 / 80.0 |
| DZ-3 | S09 | 549 / 819 | 89.8 / 106.5 | 74.2 / 80.0 |
| DZ-4 | S02 | 646 / 743 | 160.9 / 176.9 | 74.2 / 99.4 |

### What drove each zone

* **DZ-1** (18 ga, 36/9, SCREW-10 x 5):
  * drift surcharge up to 104 psf exceeds what 22 ga carries (about 50 psf over balanced snow), so 18 ga.
  * Zone 3 corner uplift 101.2 psf needs 18 ga 36/9 (126 psf).
  * touches the roof perimeter or a framed opening, so at least 36/7 with 3 sidelap connectors (criteria 10.4).
  * peak diaphragm shear 981 plf vs phi Sn 1226 plf, G' = 45.6 kip/in.
* **DZ-2** (22 ga, 36/9, BP x 3):
  * peak drift surcharge in the zone 34 psf is within 22 ga capacity.
  * touches the roof perimeter or a framed opening, so at least 36/7 with 3 sidelap connectors (criteria 10.4).
  * perimeter Zone 2 uplift 74.2 psf (capacity 80.0 psf).
  * peak diaphragm shear 459 plf vs phi Sn 484 plf, G' = 16.1 kip/in.
* **DZ-3** (22 ga, 36/9, SCREW-10 x 5):
  * peak drift surcharge in the zone 47 psf is within 22 ga capacity.
  * touches the roof perimeter or a framed opening, so at least 36/7 with 3 sidelap connectors (criteria 10.4).
  * perimeter Zone 2 uplift 74.2 psf (capacity 80.0 psf).
  * peak diaphragm shear 549 plf vs phi Sn 819 plf, G' = 29.8 kip/in.
* **DZ-4** (18 ga, 36/7, SCREW-10 x 3):
  * drift surcharge up to 104 psf exceeds what 22 ga carries (about 50 psf over balanced snow), so 18 ga.
  * touches the roof perimeter or a framed opening, so at least 36/7 with 3 sidelap connectors (criteria 10.4).
  * perimeter Zone 2 uplift 74.2 psf (capacity 99.4 psf).
  * peak diaphragm shear 646 plf vs phi Sn 743 plf, G' = 26.8 kip/in.

### Zoning strategy

1. **Gravity (snow drift) sets the gage.** With balanced snow of 43.66 psf, 22 ga carries a drift surcharge of only about 50 psf and 18 ga about 119 psf. Several drifts are much larger:
   * MEP-PH-1 leeward drift 104 psf on its W and E faces, 76 psf on its N and S faces;
   * SCR-N windward drift 89 psf along its south face;
   * SCR-E windward drift 100 psf along its west face;
   * rooftop-unit windward drifts of 81-98 psf on the faces with long upwind fetch.

   These cells need 18 ga. With only 14 rectangles they are gathered into a few large 18 ga bands, while the light 22 ga stays where the peak drift in the whole rectangle is within its capacity:
   * a north band (SCR-N, RTU-5 to RTU-9);
   * a south band (RTU-1 to RTU-4, RTU-10);
   * the ring around the enclosure (including RTU-11 and RTU-12);
   * the SCR-E strip.
2. **Uplift sets the perimeter.** The 18 x 18 ft corners (Zone 3, 101.2 psf) need 18 ga 36/9. The perimeter band (Zone 2, 74.2 psf) needs 22 ga 36/9 or 18 ga 36/7. Every zone touching the perimeter or an opening uses at least 36/7 with 3 sidelap connectors (criteria 10.4).
3. **The lateral system sets the stiffness pattern.** The criteria and LAT-2026-003 make the deck stiffness a design variable:
   * Under seismic along y the stiff east frames (68 kip/in) attract most of the force. The deck next to grid 9 carries about 1,000 plf and controls the diaphragm deflection, so the east and west strips are 18 ga 36/9 with 5 SCREW-10 per span (G' 45.6 kip/in, phi Sn 1,226 plf).
   * Under seismic along x the stiff south frames (55 kip/in each, against 18 kip/in on grid G) draw force into the grid-A drag struts. The collector splice (58 kip after Omega_0 = 2.0) is the limit: a uniformly stiff deck pushes the amplified collector force above 58 kip.
   * The deck along the south perimeter between and alongside the two south braced frames (x = 60 to 210 ft, y = 0 to 18 ft) is therefore deliberately the most flexible specification that still meets the boundary and uplift rules: 22 ga 36/9 with 3 button punches, G' 16.1 kip/in. The stiff 18 ga deck at the south-west corner feeds the frame bay directly. This keeps the amplified collector force near 51 kip, while the stiff end strips hold the diaphragm deflection to about 1.4 in.
4. **Cost.** Rectangles with the same specification are grouped into one zone, so the design uses four zones, two gages (22 and 18) and three attachment patterns. The cells that need 18 ga for drift are scattered across the roof (every rooftop unit, both screens and the enclosure), and only 14 rectangles are allowed. So the interior between the screens is one 18 ga 36/7 zone with 3 SCREW-10, set out as seven rectangles that frame the three openings. 22 ga is kept wherever the peak drift in the whole rectangle is within its capacity:
   * the south and north perimeter strips;
   * the strip below RO-1;
   * the west wall strip.

   The lighter interior options (22 ga 36/4 with 2 button punches, 18 ga 36/4) were tried in the optimisation. They were rejected because every interior rectangle either touches an opening (so 10.4 requires 36/7 and 3 connectors) or contains 18 ga drift cells.

### Design margins and interpretation

* The design was checked with a margin of at least 1 psf on gravity, at least 4 % on diaphragm shear, the amplified collector force kept at 55 kip or less (limit 58), chord force 35 kip or less (limit 38) and diaphragm deflection 1.45 in or less (limit 1.60).
* It was also checked under two alternative readings of the cell convention:
  * a drift strip ending exactly on a cell line loads both adjacent cells;
  * drifts from different obstructions in one wind direction are superimposed.
* The 22 ga gravity capacity was taken as the lesser of the Table 3-1 value (106 psf) and the value reproduced from the stated basis (106.4 psf).


## 6. Installed cost (cost plan CP-RD-2026 rates)

* Deck: 18 ga 34344 sf, 22 ga 7848 sf; 42192 sf in total.
* Support fasteners: 18048 ea; sidelap connectors: SCREW-10 7182 ea, BP 894 ea.
* Costs: deck $175737, fasteners $24365, sidelaps $8545, set-up (4 zones, 14 rectangles, 2 gages, 3 patterns) $21040.
* **Total installed cost $229687.**

## 7. Notes for the erector

* Lay the deck in 3-span continuous lengths, attached at every support with the pattern scheduled for the zone.
* Each sheet must bear at least 1.5 in. The 2.5 in joist top chord cannot give two butted sheets 1.5 in each, so lap panel ends over the joists rather than butting them; otherwise report to the engineer per joist schedule note N1.
* Terminate the deck on the opening header angles at RO-1, RO-2 and RO-3, with no deck inside the opening cells. Any cover used during erection must be a purpose-made cover that is secured and marked per 29 CFR 1926.754(e)(3).
* Thermal effects are excluded by AHJ agreement (criteria 1.5, OBD section 9).