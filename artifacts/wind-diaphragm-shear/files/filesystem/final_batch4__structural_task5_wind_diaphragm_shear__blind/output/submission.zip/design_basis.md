# Design basis - Building A2 roof diaphragm, chords, collectors and precast shear walls for wind

Northern Divide Data Campus, Building A2, Lewis and Clark County, Montana. Delegated lateral package (wind). All loads, unit shears, line loads, reactions, chord forces and deflections reported in this submittal are **ASD quantities (0.6W)** per EOR-NDDC-A2-S01 Rev 2 clause 3.3.

## Values the design was built on

| item | value | source |
|---|---|---|
| Kzt | 1.19 | TS-2026-02 section 4 (whole footprint); EOR-NDDC-A2-S01 Rev 2 clause 4.3 |
| Ke | 0.8670 | EOR-NDDC-A2-S01 Rev 2 clause 4.4; zg = 3941.02 ft, ALTA-2025-77 benchmark BM-2 |
| q_h_psf | 28.74 | EOR-NDDC-A2-S01 Rev 2 clause 4.2 at h = 28.00 ft (strength level; ASD 0.6 q_h = 17.25 psf) |
| screen_wall_top_ft | 36.00 | SR-2026-118 section 5.2; federated model panels N108-N111 (x = 96 to 168 ft) |
| asbuilt_opening_panel | S14 | Federated model opening S14-O1, field-cut after erection, not on PC-S01 (2024) or PC-S02 Rev 2 |
| asd_combination | 0.6W | EOR-NDDC-A2-S01 Rev 2 clause 3.3 |
| omega_d | 2.35 | CDS-B36 Note 2 |
| analysis_method | semi-rigid diaphragm, DIAPH-MT 1.0 finite element membrane model | EOR-NDDC-A2-S01 Rev 2 section 9; NDDC-AHJ-014 section 3 |
| mesh_level | L2 | EOR-NDDC-A2-S01 Rev 2 clause 9.7 (H = 5.0 ft) |

## Governing wind scenario for each wall line

| line | governing scenario |
|---|---|
| S | W05 |
| E | W03 |
| N1 | W01 |
| W | W07 |
| N2 | W01 |
| E2 | W07 |

The governing scenario of a wall line is the scenario that produces the largest roof-level wall line load on that line (the wind envelope for the wall line, WT-2026-07 section 2; ShearWalls schedule, line_load_plf). For reference, the scenarios giving the largest in-plane shear wall reaction on each line are: S W07 (34.4 kips), E W10 (20.8 kips), N1 W07 (23.4 kips), W W01 (47.6 kips), N2 W08 (23.1 kips), E2 W01 (47.0 kips).

## Design summary

- Analysis: DIAPH-MT 1.0 semi-rigid membrane model (EOR-NDDC-A2-S01 Rev 2 section 9), reported at mesh level L2 (H = 5.0 ft, 1584 elements). Verification example VE-1 reproduced exactly (240/273, 20.00 k, 10.00/10.00 k, 185.2 plf, 2.57 k, 0.1669 in). Convergence: W-line reaction in W01 changes 0.19 % between L2 and L3 (limit 5 %).
- Wind: V = 115 mph (NDDC-AHJ-014), Risk Category III, Exposure C, Kd = 0.85, Kzt = 1.19 (TS-2026-02), Ke = 0.8670 (zg = 3941.02 ft, ALTA-2025-77 BM-2), q_h = 28.74 psf at h = 28.00 ft (strength; ASD 17.25 psf); parapet q_p = 29.37 psf at 31.00 ft and 30.31 psf at the 36.00 ft screen wall.
- Deck: 4 distinct deck types (limit 4, OBD 4.6): D20-36/4-2, D22-36/4-2, D22-36/4-4, D22-36/7-4. Zones: Z11 D22-36/4-4; Z12 D22-36/7-4; Z13 D22-36/4-4; Z21 D22-36/4-4; Z22 D22-36/4-2; Z23 D22-36/4-2; Z31 D22-36/4-4; Z32 D22-36/4-4; Z33 D22-36/7-4; Z41 D22-36/4-4; Z42 D22-36/4-4; Z43 D20-36/4-2.
- Chords and collectors: C-S PL3x3/8; C-N1 PL3x3/8; C-N2 PL3x3/8; C-E PL3x3/8; C-E2 PL12x1; C-W PL3x3/8; K-N2 PL3x3/8; K-E2 PL3x3/8; O-S PL3x3/8; O-N PL3x3/8; O-W PL5x1/2; O-E PL3x3/8.
- Panel base tie-downs (T1): S01, N201, N202, N204, E201, E202, E203, E204, N101, N110, N112, W01, W15. E1 embeds: 141 in total.
- Maximum diaphragm deflection relative to supports: X 0.316 in, Y 0.541 in (limit 0.55 in, EOR 8.2 / OBD 4.4).
- Installed cost: $211527.02 (cap $310,000, OBD 4.7): deck $134788.00, chords and collectors $18804.01, embeds $26085.00, tie-downs $31850.00.

## Conflicts between issued documents and how they were resolved

- **Basic wind speed and risk category.** The superseded criteria EOR-NDDC-A2-S01 Revision 0 (archive) and the 2024 pre-application memorandum used V = 105 mph at Risk Category II. The AHJ letter NDDC-AHJ-014 (which supersedes the memorandum) and criteria Revision 2 clause 4.3 govern: V = 115 mph, Risk Category III. Revision 0 was not used.
- **Topographic factor.** Revision 0 carried Kzt = 1.00 pending the study; TS-2026-02 section 4 gives Kzt = 1.19 over the whole footprint at all elevations and azimuths, and criteria Revision 2 clause 4.3 adopts it. Kzt = 1.19 was used.
- **Ground elevation factor.** Revision 0 and the Hall B study took Ke = 1.0; criteria Revision 2 clause 4.4 requires Ke = exp(-0.0000362 zg) and forbids Ke = 1.0. zg = 3941.02 ft (ALTA-2025-77 site benchmark BM-2; the finished floor 3940.0 ft gives the same Ke to four decimals), Ke = 0.8670.
- **Diaphragm idealisation.** Revision 0 permitted a rigid distribution and the Hall B (Building A1) study used a flexible tributary distribution; criteria Revision 2 section 9 and NDDC-AHJ-014 section 3 reject both. The DIAPH-MT 1.0 semi-rigid model was used and verified against VE-1.
- **Screen wall height.** The 2024 precast panel schedule PC-S01 (and the elevations PC-S02 Rev 2 panel outlines) show the north elevation panels at a top of 31.00 ft; the roof line scan SR-2026-118 section 5.2 and the federated model show the screen wall panels N108, N109, N110 and N111 (x = 96 ft to 168 ft) at 36.00 ft, 8.00 ft above the deck. Per criteria clause 5.3 the as-built geometry governs: 36.00 ft was used for those panels (parapet band 28-36 ft, q_p at 36 ft), and Revision 0's uniform 3 ft parapet was not used.
- **Field-cut opening in S14.** The federated model shows opening S14-O1 (x = 194.5 ft to 202.5 ft, sill 0, head 12.0 ft, "field-cut after erection") that is not on the 2024 precast schedule PC-S01, nor on PC-S02 Rev 2 (note 4) or the A-301 Rev C elevations. As-built governs (clause 5.3): S14 is a 2.5 ft leg (pier S14-P1) and a 1.5 ft leg that is neglected under clause 5.4 (no stiffness, no shear). The superseded PC-S02 Rev 1 was not used (it also shows the S10 opening at 138-154 ft; the model gives 136-152 ft, which was used).
- **Opening elevations.** PC-S01 lists the E06 opening as 12.0 ft x 12.0 ft and the N107-N109 openings as 16.0 ft x 14.0 ft without sill elevations; the federated model gives E06 sill 14.0 ft / head 26.0 ft and N107-N109 sill 12.0 ft / head 26.0 ft. The model governs; openings divide the panels into full-height legs (clause 5.4) and do not reduce the loaded gross area (clause 6.3).
- **Roof outline.** The superseded roof plan A-101 Rev A shows a 240 ft x 180 ft rectangle; A-101 Rev C, S-201 Rev C and the federated model show the generator yard notch (x = 180-240 ft, y = 140-180 ft) and the mechanical well opening (x = 100-140 ft, y = 100-130 ft). The as-built outline was meshed; zone Z43 is 1,200 sf and zones Z22, Z23, Z32, Z33 are reduced by the well.
- **Deck span and G'.** SJ-201 Note 1 states joists at 5 ft 0 in on centre but a 6 ft 0 in deck span; CDS-B36 Note 4 tabulates G' for a 6 ft span and gives an adjustment only for a 4 ft span. The tabulated G' was used outside Z22 (no adjustment rule exists for any other span and the schedule states the 6 ft span); in Z22 (joists at 4 ft 0 in, deck span 4 ft 0 in per SJ-201 Note 2 and S-201) G' x 1.15 was used for stiffness only, never strength (criteria 7.3). EAy uses the 5 ft joist spacing (13,920 kip/ft), and 4 ft in Z22 (17,400 kip/ft).
- **E2 wall face orientation.** The federated model places the E2 panels (E201-E204) on the west side of grid line x = 180 ft, and the WT-2026-07 coefficients for those patches are those of a west-facing elevation (windward, GCpn = +1.5, for azimuths 225-315 deg); A-301 titles it the generator yard west elevation. The E2 line load was applied along the inward normal of that modelled face (+x), consistent with the model and the coefficient data. The deck, chord, collector and connection design was also checked with the E2 line load reversed (geometric inward normal -x) and remains within every limit.
- **Deflection criteria.** Criteria clause 2 refers to the more restrictive of the code and UFC 3-301-01 Table 2-1; the Owner's Basis of Design 4.4 and criteria clause 8.2 set 0.55 in for the diaphragm deflection relative to its supports (UFC Table 2-1 addresses framing supporting exterior finishes and does not give a more restrictive diaphragm value). 0.55 in was applied to every scenario and both axes; pier drift was checked against h/400.
- **Other building.** The Hall B Lateral Study (Building A1: q_h = 18.9 psf, single 22 gauge deck, 302 plf) is for another building and was not used for any value.
- **Panel schedule status.** PC-S01 (2024) is for information only and superseded by the federated model (T-204 item 10); panel marks, lengths, thicknesses, tops and openings were taken from the federated model and the roof line scan.

