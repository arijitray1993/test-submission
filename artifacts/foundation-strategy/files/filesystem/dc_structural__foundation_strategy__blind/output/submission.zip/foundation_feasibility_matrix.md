# Foundation-type feasibility and optimisation matrix - Cattail Run Data Campus, Phase 1 (AV-CR-2604)

Units: kips, ksf, in, ft, USD at the project budget unit prices (BoD Rev 3 sec. 5; bid schedule Rev 1; Kettleridge KGS-26-0917). Demand = SERVICE_D_PLUS_L (bearing, settlement) and STRENGTH_1.2D_1.6L (shear, flexure) per the load-combination memo. q_net = P/(BL) + (150 - 118 pcf) t. q_allow,net = min(Meyerhof, Vesic) solution of the general equation (UFC 3-220-20 Eq. 5-15, Table 5-6; EM 1110-1-1905 Eq. 4-1) / FS (UFC 3-220-01 Table 2-3) - sigma'zD (Eq. 5-14), groundwater-corrected (Fig. 5-6); Terzaghi and Brinch Hansen computed as the other two methods. Settlement = layered elastic compression (RFI-019; GEC 13 Eq. 5-14), plus qg/kg upper zone for improved footings (GEC 13 Eq. 5-12/5-13). Angular distortion limit 1/500 between adjacent units (UFC 3-220-01 2-4.7.1). Stand-alone alternative costs are the cheapest individually-compliant spread and improved-spread design for that unit at the pad bearing depth (pad-level chain constraints not applied); the pad-level costs are the optimised whole-pad programmes that decided the pad.

Campus programme: improved pads CR-P1, CR-P2, CR-P4, CR-P6; 2 rig(s) mobilised (RIG-1: CR-P1, CR-P2; RIG-2: CR-P4, CR-P6); mobilisation $80,000; campus total $412,014.


## CR-P1 - Data Hall 1

- Occupancy: Light Industrial, Public; FS on bearing 3.5 (UFC 3-220-01 Table 2-3). Bearing depth 45 in (frost minimum 42 in); stabilised groundwater 8.0 ft; dewatering 0 days.
- Concrete: f'c 4000 psi, max w/cm 0.50 (classes F1, S1, W1, C1; sulfate 0.140 % -> S1).
- Stratum I base at stations 0/24/44/60/72/77 ft: 6.0/8.0/9.7/11.1/12.1/12.5 ft; Stratum II 14.0 ft thick; Es I/II/III = 110/1500/3500 ksf.
- Pad governing constraint: **BEARING**. Decision: **IMPROVED_SPREAD**.
- Pad alternatives (whole-pad optimised, incl. dewatering and modulus test, excl. campus mobilisation): spread-only $241,639 (spread footings at 120 in bearing depth (F1-F3 in Stratum II; F4-W1 in Stratum I, up to 25 ft wide), 6 dewatering days, 1.5H:1V excavation); improved $77,244 (selected design: all six units on rammed aggregate piers at 45 in). Selected: IMPROVED_SPREAD.

| Tag | Sta (ft) | P svc / Pu (k) | Type | B x L x t (in) | Stratum | q_net (ksf) | q_allow,net (ksf) | q/qa | Settlement (in) | Ang. dist. to next | Piers n x depth (ft), Ra, qg (psf) | Reinf. | Governing | Stand-alone spread cost | Stand-alone improved cost | Selected cost |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 0 | 610.0 / 838.0 | IMPROVED_SPREAD | 126 x 126 x 27 | I | 5.605 | 5.615 | 1.00 | 0.683 | 1/2878 (F1-F2) | 8 x 8, 0.356, 13327 | #7 @ 10 in (rho 0.00222) | BEARING | $5,969 (156x156) | $5,790 (126x126, 8 piers) | $5,790 |
| F2 | 24 | 1180.0 / 1622.0 | IMPROVED_SPREAD | 174 x 174 x 39 | I | 5.717 | 5.847 | 0.98 | 0.783 | 1/3571 (F2-F3) | 15 x 8, 0.350, 13769 | #9 @ 12 in (rho 0.00214) | BEARING | $26,947 (300x300) | $12,420 (174x174, 15 piers) | $12,420 |
| F3 | 44 | 1420.0 / 1953.0 | IMPROVED_SPREAD | 189 x 189 x 42 | I | 5.837 | 5.916 | 0.99 | 0.850 | 1/2982 (F3-F4) | 17 x 8, 0.336, 14491 | #9 @ 11 in (rho 0.00216) | BEARING | $46,674 (387x387) | $14,988 (189x189, 17 piers) | $14,988 |
| F4 | 60 | 980.0 / 1348.0 | IMPROVED_SPREAD | 159 x 159 x 33 | I | 5.671 | 5.720 | 0.99 | 0.786 | 1/1083 (F4-F5) | 12 x 8, 0.336, 14106 | #8 @ 10 in (rho 0.00239) | BEARING | $31,910 (339x339) | $9,739 (159x159, 12 piers) | $9,739 |
| F5 | 72 | 520.0 / 715.0 | IMPROVED_SPREAD | 120 x 120 x 24 | I | 5.264 | 5.515 | 0.95 | 0.653 | 1/647 (F5-W1) | 7 x 9, 0.344, 12863 | #7 @ 10 in (rho 0.00250) | BEARING | $13,562 (240x240) | $5,278 (120x120, 7 piers) | $5,278 |
| W1 | 77 | 1650.0 / 2244.0 | IMPROVED_SPREAD | 168 x 288 x 30 | I | 4.991 | 5.084 | 0.98 | 0.745 | - | 23 x 9, 0.336, 12402 | #10 @ 12 in (rho 0.00353) | BEARING | infeasible at 45 in (s > 1 in or t > D-3 in within B <= 34 ft) | $19,529 (168x288, 23 piers) | $19,529 |

Shear-wall footing W1 stability (wall 24 ft x 12 in, footing 168 x 288 x 30 in):
- Sliding (0.6D + W: P = 708.0 k, H = 96.0 k; wind uplift 260.0 k deducted; footing + soil x 0.6 = 103.2 k; base friction tan(17.3 deg) = 0.312; 1/2 passive on end face = 27.2 k): FS = 2.08 >= 2.0 (UFC 3-220-01 2-4.6.3). Without uplift deduction FS = 2.92.
- Overturning (D + L + W: P = 1650.0 k, H = 96.0 k, M = 880.0 k-ft): e = (M + H D)/(P - U) = 10.71 in <= L/6 = 48.0 in and B/6 = 28.0 in (middle third).
- Uplift (UPLIFT_W = -260.0 k; dead load 1180.0 k): FS = 0.6(Wf + Ws + D)/U = 3.12 >= 1.5 (UFC 3-220-20 Fig. 5-41).
- Pad cost of the selected design: footings $67,744 + fixed $9,500 = $77,244.

## CR-P2 - Data Hall 2

- Occupancy: Light Industrial, Public; FS on bearing 3.5 (UFC 3-220-01 Table 2-3). Bearing depth 45 in (frost minimum 42 in); stabilised groundwater 9.0 ft; dewatering 0 days.
- Concrete: f'c 4500 psi, max w/cm 0.45 (classes F1, S2, W1, C1; sulfate 0.230 % -> S2).
- Stratum I base at stations 0/24/44/60/72/77 ft: 13.5/12.1/10.9/10.0/9.3/9.0 ft; Stratum II 12.0 ft thick; Es I/II/III = 85/1400/3400 ksf.
- Pad governing constraint: **BEARING**. Decision: **IMPROVED_SPREAD**.
- Pad alternatives (whole-pad optimised, incl. dewatering and modulus test, excl. campus mobilisation): spread-only $261,599 (spread footings at 120 in bearing depth (F1-F3 in Stratum I up to 22 ft wide; F4-W1 in Stratum II), 3 dewatering days, 1.5H:1V excavation); improved $82,330 (selected design: all six units on rammed aggregate piers at 45 in). Selected: IMPROVED_SPREAD.

| Tag | Sta (ft) | P svc / Pu (k) | Type | B x L x t (in) | Stratum | q_net (ksf) | q_allow,net (ksf) | q/qa | Settlement (in) | Ang. dist. to next | Piers n x depth (ft), Ra, qg (psf) | Reinf. | Governing | Stand-alone spread cost | Stand-alone improved cost | Selected cost |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 0 | 646.6 / 888.3 | IMPROVED_SPREAD | 132 x 132 x 27 | I | 5.416 | 5.644 | 0.96 | 0.752 | 1/1582 (F1-F2) | 9 x 10, 0.365, 12636 | #6 @ 7 in (rho 0.00233) | BEARING | $30,027 (342x342) | $7,070 (132x132, 9 piers) | $7,070 |
| F2 | 24 | 1250.8 / 1719.3 | IMPROVED_SPREAD | 177 x 177 x 39 | I | 5.854 | 5.906 | 0.99 | 0.934 | 1/10648 (F2-F3) | 15 x 9, 0.338, 14467 | #7 @ 7 in (rho 0.00220) | BEARING | infeasible at 45 in (s > 1 in or t > D-3 in within B <= 34 ft) | $13,595 (177x177, 15 piers) | $13,595 |
| F3 | 44 | 1505.2 / 2070.2 | IMPROVED_SPREAD | 192 x 192 x 42 | I | 5.992 | 5.999 | 1.00 | 0.956 | 1/2914 (F3-F4) | 19 x 8, 0.364, 14003 | #8 @ 8 in (rho 0.00235) | BEARING | infeasible at 45 in (s > 1 in or t > D-3 in within B <= 34 ft) | $16,511 (192x192, 19 piers) | $16,511 |
| F4 | 60 | 1038.8 / 1428.9 | IMPROVED_SPREAD | 162 x 162 x 33 | I | 5.788 | 5.846 | 0.99 | 0.890 | 1/1605 (F4-F5) | 13 x 8, 0.350, 13943 | #9 @ 12 in (rho 0.00253) | BEARING | $42,647 (378x378) | $10,588 (162x162, 13 piers) | $10,588 |
| F5 | 72 | 551.2 / 757.9 | IMPROVED_SPREAD | 120 x 120 x 24 | I | 5.576 | 5.644 | 0.99 | 0.800 | 1/695 (F5-W1) | 7 x 8, 0.344, 13625 | #7 @ 10 in (rho 0.00250) | BEARING | $14,545 (243x243) | $5,193 (120x120, 7 piers) | $5,193 |
| W1 | 77 | 1749.0 / 2378.6 | IMPROVED_SPREAD | 171 x 288 x 30 | I | 5.195 | 5.242 | 0.99 | 0.887 | - | 23 x 8, 0.330, 13080 | #8 @ 7 in (rho 0.00376) | BEARING | infeasible at 45 in (s > 1 in or t > D-3 in within B <= 34 ft) | $19,873 (171x288, 23 piers) | $19,873 |

Shear-wall footing W1 stability (wall 24 ft x 12 in, footing 171 x 288 x 30 in):
- Sliding (0.6D + W: P = 750.5 k, H = 101.8 k; wind uplift 275.6 k deducted; footing + soil x 0.6 = 105.1 k; base friction tan(17.3 deg) = 0.312; 1/2 passive on end face = 27.7 k): FS = 2.05 >= 2.0 (UFC 3-220-01 2-4.6.3). Without uplift deduction FS = 2.90.
- Overturning (D + L + W: P = 1749.0 k, H = 101.8 k, M = 932.8 k-ft): e = (M + H D)/(P - U) = 10.71 in <= L/6 = 48.0 in and B/6 = 28.5 in (middle third).
- Uplift (UPLIFT_W = -275.6 k; dead load 1250.8 k): FS = 0.6(Wf + Ws + D)/U = 3.10 >= 1.5 (UFC 3-220-20 Fig. 5-41).
- Pad cost of the selected design: footings $72,830 + fixed $9,500 = $82,330.

## CR-P3 - Electrical Yard Building

- Occupancy: Light Industrial, Public; FS on bearing 3.5 (UFC 3-220-01 Table 2-3). Bearing depth 45 in (frost minimum 42 in); stabilised groundwater 19.0 ft; dewatering 0 days.
- Concrete: f'c 4000 psi, max w/cm 0.50 (classes F1, S0, W1, C1; sulfate 0.070 % -> S0).
- Stratum I base at stations 0/24/44/60/72/77 ft: 5.5/6.0/6.4/6.7/6.9/7.0 ft; Stratum II 16.0 ft thick; Es I/II/III = 210/1700/3700 ksf.
- Pad governing constraint: **BEARING**. Decision: **SPREAD**.
- Pad alternatives (whole-pad optimised, incl. dewatering and modulus test, excl. campus mobilisation): spread-only $31,427 (selected design: six spread footings at 45 in); improved $51,932 (all six units on rammed aggregate piers at 45 in bearing depth). Selected: SPREAD.

| Tag | Sta (ft) | P svc / Pu (k) | Type | B x L x t (in) | Stratum | q_net (ksf) | q_allow,net (ksf) | q/qa | Settlement (in) | Ang. dist. to next | Piers n x depth (ft), Ra, qg (psf) | Reinf. | Governing | Stand-alone spread cost | Stand-alone improved cost | Selected cost |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 0 | 439.2 / 603.4 | SPREAD | 105 x 105 x 21 | I | 5.793 | 5.972 | 0.97 | 0.688 | 1/1098 (F1-F2) | - | #5 @ 6 in (rho 0.00246) | BEARING | $2,551 (105x105) | $3,916 (105x105, 6 piers) | $2,551 |
| F2 | 24 | 849.6 / 1167.8 | SPREAD | 141 x 141 x 30 | I | 6.234 | 6.325 | 0.99 | 0.950 | 1/15086 (F2-F3) | - | #8 @ 11 in (rho 0.00239) | BEARING | $5,273 (141x141) | $7,550 (141x141, 10 piers) | $5,273 |
| F3 | 44 | 1022.4 / 1406.2 | SPREAD | 168 x 168 x 33 | I | 5.305 | 6.541 | 0.81 | 0.966 | 1/15963 (F3-F4) | - | #9 @ 12 in (rho 0.00253) | SETTLEMENT | $7,875 (168x168) | $9,018 (153x153, 11 piers) | $7,875 |
| F4 | 60 | 705.6 / 970.6 | SPREAD | 138 x 138 x 27 | I | 5.408 | 6.297 | 0.86 | 0.954 | 1/2215 (F4-F5) | - | #7 @ 9 in (rho 0.00247) | SETTLEMENT | $4,802 (138x138) | $6,046 (129x129, 8 piers) | $4,802 |
| F5 | 72 | 374.4 / 514.8 | SPREAD | 99 x 99 x 21 | I | 5.557 | 5.893 | 0.94 | 0.895 | 1/709 (F5-W1) | - | #6 @ 10 in (rho 0.00210) | BEARING | $2,235 (99x99) | $3,891 (105x105, 6 piers) | $2,235 |
| W1 | 77 | 1188.0 / 1615.7 | SPREAD | 126 x 288 x 24 | I | 4.779 | 5.230 | 0.91 | 0.965 | - | - | #8 @ 11 in (rho 0.00299) | SETTLEMENT | $8,690 (126x288) | $12,011 (120x288, 17 piers) | $8,690 |

Shear-wall footing W1 stability (wall 24 ft x 12 in, footing 126 x 288 x 24 in):
- Sliding (0.6D + W: P = 509.8 k, H = 69.1 k; wind uplift 187.2 k deducted; footing + soil x 0.6 = 73.6 k; base friction tan(17.3 deg) = 0.312; 1/2 passive on end face = 17.1 k): FS = 2.04 >= 2.0 (UFC 3-220-01 2-4.6.3). Without uplift deduction FS = 2.88.
- Overturning (D + L + W: P = 1188.0 k, H = 69.1 k, M = 633.6 k-ft): e = (M + H D)/(P - U) = 10.71 in <= L/6 = 48.0 in and B/6 = 21.0 in (middle third).
- Uplift (UPLIFT_W = -187.2 k; dead load 849.6 k): FS = 0.6(Wf + Ws + D)/U = 3.11 >= 1.5 (UFC 3-220-20 Fig. 5-41).
- Pad cost of the selected design: footings $31,427 + fixed $0 = $31,427.

## CR-P4 - Administration and Operations Building

- Occupancy: Apartments, Office; FS on bearing 3.0 (UFC 3-220-01 Table 2-3). Bearing depth 45 in (frost minimum 42 in); stabilised groundwater 8.0 ft; dewatering 0 days.
- Concrete: f'c 4000 psi, max w/cm 0.50 (classes F1, S1, W1, C1; sulfate 0.110 % -> S1).
- Stratum I base at stations 0/24/44/60/72/77 ft: 6.0/7.1/8.0/8.7/9.3/9.5 ft; Stratum II 15.0 ft thick; Es I/II/III = 130/1600/3600 ksf.
- Pad governing constraint: **BEARING**. Decision: **IMPROVED_SPREAD**.
- Pad alternatives (whole-pad optimised, incl. dewatering and modulus test, excl. campus mobilisation): spread-only $63,106 (six spread footings on Stratum I at 45 in bearing depth (settlement-governed)); improved $43,715 (selected design: F1 spread, F2-W1 on rammed aggregate piers at 45 in). Selected: IMPROVED_SPREAD.

| Tag | Sta (ft) | P svc / Pu (k) | Type | B x L x t (in) | Stratum | q_net (ksf) | q_allow,net (ksf) | q/qa | Settlement (in) | Ang. dist. to next | Piers n x depth (ft), Ra, qg (psf) | Reinf. | Governing | Stand-alone spread cost | Stand-alone improved cost | Selected cost |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 0 | 384.3 / 527.9 | SPREAD | 108 x 108 x 21 | I | 4.801 | 6.541 | 0.73 | 0.969 | 1/1148 (F1-F2) | - | #6 @ 9 in (rho 0.00233) | SETTLEMENT | $2,658 (108x108) | $3,848 (105x105, 6 piers) | $2,658 |
| F2 | 24 | 743.4 / 1021.9 | IMPROVED_SPREAD | 129 x 129 x 30 | I | 6.513 | 6.624 | 0.98 | 0.719 | 1/25903 (F2-F3) | 8 x 8, 0.340, 16049 | #7 @ 10 in (rho 0.00200) | BEARING | $9,187 (189x189) | $6,128 (129x129, 8 piers) | $6,128 |
| F3 | 44 | 894.6 / 1230.4 | IMPROVED_SPREAD | 141 x 141 x 30 | I | 6.560 | 6.678 | 0.98 | 0.728 | 1/3707 (F3-F4) | 10 x 8, 0.355, 15619 | #6 @ 6 in (rho 0.00244) | BEARING | $14,324 (231x231) | $7,574 (141x141, 10 piers) | $7,574 |
| F4 | 60 | 617.4 / 849.2 | IMPROVED_SPREAD | 120 x 120 x 27 | I | 6.246 | 6.556 | 0.95 | 0.676 | 1/1969 (F4-F5) | 7 x 8, 0.344, 15263 | #7 @ 11 in (rho 0.00202) | BEARING | $9,501 (198x198) | $5,157 (120x120, 7 piers) | $5,157 |
| F5 | 72 | 327.6 / 450.4 | IMPROVED_SPREAD | 87 x 87 x 18 | I | 6.281 | 6.440 | 0.98 | 0.603 | 1/6911 (F5-W1) | 4 x 8, 0.373, 14399 | #6 @ 10 in (rho 0.00244) | BEARING | $4,162 (138x138) | $2,614 (87x87, 4 piers) | $2,614 |
| W1 | 77 | 1039.5 / 1413.7 | IMPROVED_SPREAD | 102 x 288 x 27 | I | 5.168 | 5.283 | 0.98 | 0.611 | - | 14 x 8, 0.337, 12817 | #6 @ 9 in (rho 0.00181) | BEARING | $23,274 (282x288) | $10,082 (102x288, 14 piers) | $10,082 |

Shear-wall footing W1 stability (wall 24 ft x 12 in, footing 102 x 288 x 27 in):
- Sliding (0.6D + W: P = 446.0 k, H = 60.5 k; wind uplift 163.8 k deducted; footing + soil x 0.6 = 60.4 k; base friction tan(17.3 deg) = 0.312; 1/2 passive on end face = 15.2 k): FS = 2.02 >= 2.0 (UFC 3-220-01 2-4.6.3). Without uplift deduction FS = 2.86.
- Overturning (D + L + W: P = 1039.5 k, H = 60.5 k, M = 554.4 k-ft): e = (M + H D)/(P - U) = 10.71 in <= L/6 = 48.0 in and B/6 = 17.0 in (middle third).
- Uplift (UPLIFT_W = -163.8 k; dead load 743.4 k): FS = 0.6(Wf + Ws + D)/U = 3.09 >= 1.5 (UFC 3-220-20 Fig. 5-41).
- Pad cost of the selected design: footings $34,215 + fixed $9,500 = $43,715.

## CR-P5 - Logistics and Spares Warehouse

- Occupancy: Warehouse; FS on bearing 2.5 (UFC 3-220-01 Table 2-3). Bearing depth 42 in (frost minimum 42 in); stabilised groundwater 21.0 ft; dewatering 0 days.
- Concrete: f'c 5000 psi, max w/cm 0.40 (classes F3, S0, W1, C1; sulfate 0.050 % -> S0).
- Stratum I base at stations 0/24/44/60/72/77 ft: 4.5/4.8/5.1/5.3/5.4/5.5 ft; Stratum II 18.0 ft thick; Es I/II/III = 250/1800/3800 ksf.
- Pad governing constraint: **BEARING**. Decision: **SPREAD**.
- Pad alternatives (whole-pad optimised, incl. dewatering and modulus test, excl. campus mobilisation): spread-only $18,277 (selected design: six spread footings at 42 in); improved $38,137 (all six units on rammed aggregate piers at 42 in bearing depth). Selected: SPREAD.

| Tag | Sta (ft) | P svc / Pu (k) | Type | B x L x t (in) | Stratum | q_net (ksf) | q_allow,net (ksf) | q/qa | Settlement (in) | Ang. dist. to next | Piers n x depth (ft), Ra, qg (psf) | Reinf. | Governing | Stand-alone spread cost | Stand-alone improved cost | Selected cost |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 0 | 335.5 / 460.9 | SPREAD | 81 x 81 x 18 | I | 7.412 | 8.008 | 0.93 | 0.532 | 1/1379 (F1-F2) | - | #5 @ 8 in (rho 0.00215) | BEARING | $1,499 (81x81) | $2,641 (87x87, 4 piers) | $1,499 |
| F2 | 24 | 649.0 / 892.1 | SPREAD | 108 x 108 x 24 | I | 8.077 | 8.383 | 0.96 | 0.741 | 1/1924 (F2-F3) | - | #6 @ 7 in (rho 0.00262) | BEARING | $3,000 (108x108) | $4,938 (114x114, 7 piers) | $3,000 |
| F3 | 44 | 781.0 / 1074.2 | SPREAD | 117 x 117 x 27 | I | 8.288 | 8.524 | 0.97 | 0.865 | 1/4470 (F3-F4) | - | #8 @ 12 in (rho 0.00244) | BEARING | $3,671 (117x117) | $5,667 (120x120, 8 piers) | $3,671 |
| F4 | 60 | 539.0 / 741.4 | SPREAD | 99 x 99 x 21 | I | 7.976 | 8.236 | 0.97 | 0.822 | 1/1109 (F4-F5) | - | #7 @ 10 in (rho 0.00286) | BEARING | $2,420 (99x99) | $4,059 (105x105, 6 piers) | $2,420 |
| F5 | 72 | 286.0 / 393.3 | SPREAD | 75 x 75 x 18 | I | 7.370 | 7.927 | 0.93 | 0.711 | 1/647 (F5-W1) | - | #4 @ 6 in (rho 0.00185) | BEARING | $1,287 (75x75) | $1,970 (75x75, 3 piers) | $1,287 |
| W1 | 77 | 907.5 / 1234.2 | SPREAD | 96 x 288 x 24 | I | 4.791 | 6.675 | 0.72 | 0.618 | - | - | #6 @ 10 in (rho 0.00183) | SLIDING | $6,399 (96x288) | $9,362 (96x288, 13 piers) | $6,399 |

Shear-wall footing W1 stability (wall 24 ft x 12 in, footing 96 x 288 x 24 in):
- Sliding (0.6D + W: P = 389.4 k, H = 52.8 k; wind uplift 143.0 k deducted; footing + soil x 0.6 = 52.4 k; base friction tan(17.3 deg) = 0.312; 1/2 passive on end face = 12.4 k): FS = 2.00 >= 2.0 (UFC 3-220-01 2-4.6.3). Without uplift deduction FS = 2.85.
- Overturning (D + L + W: P = 907.5 k, H = 52.8 k, M = 484.0 k-ft): e = (M + H D)/(P - U) = 10.50 in <= L/6 = 48.0 in and B/6 = 16.0 in (middle third).
- Uplift (UPLIFT_W = -143.0 k; dead load 649.0 k): FS = 0.6(Wf + Ws + D)/U = 3.08 >= 1.5 (UFC 3-220-20 Fig. 5-41).
- Pad cost of the selected design: footings $18,277 + fixed $0 = $18,277.

## CR-P6 - Data Hall 3

- Occupancy: Light Industrial, Public; FS on bearing 3.5 (UFC 3-220-01 Table 2-3). Bearing depth 45 in (frost minimum 42 in); stabilised groundwater 8.5 ft; dewatering 0 days.
- Concrete: f'c 4500 psi, max w/cm 0.45 (classes F1, S2, W1, C1; sulfate 0.260 % -> S2).
- Stratum I base at stations 0/24/44/60/72/77 ft: 14.0/11.7/9.7/8.2/7.0/6.5 ft; Stratum II 13.0 ft thick; Es I/II/III = 95/1450/3450 ksf.
- Pad governing constraint: **BEARING**. Decision: **IMPROVED_SPREAD**.
- Pad alternatives (whole-pad optimised, incl. dewatering and modulus test, excl. campus mobilisation): spread-only $209,229 (spread footings at 96 in bearing depth (F1-F4 in Stratum I up to 26 ft wide; F5, W1 in Stratum II), no dewatering, 1.5H:1V excavation); improved $79,023 (selected design: all six units on rammed aggregate piers at 45 in). Selected: IMPROVED_SPREAD.

| Tag | Sta (ft) | P svc / Pu (k) | Type | B x L x t (in) | Stratum | q_net (ksf) | q_allow,net (ksf) | q/qa | Settlement (in) | Ang. dist. to next | Piers n x depth (ft), Ra, qg (psf) | Reinf. | Governing | Stand-alone spread cost | Stand-alone improved cost | Selected cost |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 0 | 622.2 / 854.8 | IMPROVED_SPREAD | 129 x 129 x 27 | I | 5.457 | 5.576 | 0.98 | 0.713 | 1/2033 (F1-F2) | 8 x 11, 0.340, 13445 | #7 @ 10 in (rho 0.00222) | BEARING | $25,566 (318x318) | $6,784 (129x129, 8 piers) | $6,784 |
| F2 | 24 | 1203.6 / 1654.4 | IMPROVED_SPREAD | 174 x 174 x 36 | I | 5.821 | 5.850 | 1.00 | 0.855 | 1/4615 (F2-F3) | 15 x 8, 0.350, 14020 | #9 @ 11 in (rho 0.00253) | BEARING | infeasible at 45 in (s > 1 in or t > D-3 in within B <= 34 ft) | $12,663 (174x174, 15 piers) | $12,663 |
| F3 | 44 | 1448.4 / 1992.1 | IMPROVED_SPREAD | 189 x 189 x 39 | I | 5.943 | 5.960 | 1.00 | 0.907 | 1/2459 (F3-F4) | 17 x 8, 0.336, 14756 | #8 @ 8 in (rho 0.00253) | BEARING | infeasible at 45 in (s > 1 in or t > D-3 in within B <= 34 ft) | $15,317 (189x189, 17 piers) | $15,317 |
| F4 | 60 | 999.6 / 1375.0 | IMPROVED_SPREAD | 159 x 159 x 33 | I | 5.782 | 5.805 | 1.00 | 0.829 | 1/1115 (F4-F5) | 12 x 8, 0.336, 14384 | #8 @ 10 in (rho 0.00239) | BEARING | $26,176 (300x300) | $10,007 (159x159, 12 piers) | $10,007 |
| F5 | 72 | 530.4 / 729.3 | IMPROVED_SPREAD | 120 x 120 x 24 | I | 5.368 | 5.625 | 0.95 | 0.700 | 1/743 (F5-W1) | 7 x 8, 0.344, 13117 | #7 @ 10 in (rho 0.00250) | BEARING | $8,031 (180x180) | $5,193 (120x120, 7 piers) | $5,193 |
| W1 | 77 | 1683.0 / 2288.9 | IMPROVED_SPREAD | 168 x 288 x 30 | I | 5.089 | 5.192 | 0.98 | 0.780 | - | 23 x 8, 0.336, 12647 | #9 @ 9 in (rho 0.00370) | BEARING | $42,568 (381x288) | $19,558 (168x288, 23 piers) | $19,558 |

Shear-wall footing W1 stability (wall 24 ft x 12 in, footing 168 x 288 x 30 in):
- Sliding (0.6D + W: P = 722.2 k, H = 97.9 k; wind uplift 265.2 k deducted; footing + soil x 0.6 = 103.2 k; base friction tan(17.3 deg) = 0.312; 1/2 passive on end face = 27.2 k): FS = 2.06 >= 2.0 (UFC 3-220-01 2-4.6.3). Without uplift deduction FS = 2.91.
- Overturning (D + L + W: P = 1683.0 k, H = 97.9 k, M = 897.6 k-ft): e = (M + H D)/(P - U) = 10.71 in <= L/6 = 48.0 in and B/6 = 28.0 in (middle third).
- Uplift (UPLIFT_W = -265.2 k; dead load 1203.6 k): FS = 0.6(Wf + Ws + D)/U = 3.11 >= 1.5 (UFC 3-220-20 Fig. 5-41).
- Pad cost of the selected design: footings $69,523 + fixed $9,500 = $79,023.
