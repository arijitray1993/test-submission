```json
{
 "frost": {
  "afi_100yr_F_days": 556,
  "afi_product_period": "1981-2010",
  "frost_depth_in": 42,
  "superseded_product_period": "1951-1980",
  "superseded_afi_100yr_F_days": 416
 },
 "pads": {
  "CR-P1": {
   "governing_constraint": "BEARING",
   "foundation_decision": "IMPROVED_SPREAD",
   "spread_only_cost_usd": 241639.0,
   "improved_cost_usd": 77243.98
  },
  "CR-P2": {
   "governing_constraint": "BEARING",
   "foundation_decision": "IMPROVED_SPREAD",
   "spread_only_cost_usd": 261599.0,
   "improved_cost_usd": 82329.61
  },
  "CR-P3": {
   "governing_constraint": "BEARING",
   "foundation_decision": "SPREAD",
   "spread_only_cost_usd": 31426.68,
   "improved_cost_usd": 51932.32
  },
  "CR-P4": {
   "governing_constraint": "BEARING",
   "foundation_decision": "IMPROVED_SPREAD",
   "spread_only_cost_usd": 63106.24,
   "improved_cost_usd": 43714.74
  },
  "CR-P5": {
   "governing_constraint": "BEARING",
   "foundation_decision": "SPREAD",
   "spread_only_cost_usd": 18276.79,
   "improved_cost_usd": 38136.57
  },
  "CR-P6": {
   "governing_constraint": "BEARING",
   "foundation_decision": "IMPROVED_SPREAD",
   "spread_only_cost_usd": 209229.0,
   "improved_cost_usd": 79022.55
  }
 },
 "campus": {
  "rigs_mobilised": 2,
  "mobilisation_cost_usd": 80000.0,
  "total_cost_usd": 412014.39,
  "pads_improved": [
   "CR-P1",
   "CR-P2",
   "CR-P4",
   "CR-P6"
  ]
 },
 "rejected_criteria": [
  "UFC 3-220-01N Foundation Design (2005) - cancelled predecessor volume",
  "UFC 3-220-10N Soil Mechanics (2005) - cancelled predecessor volume (DM 7.1 edition in data room)",
  "AV-CR-2604 Geotechnical Addendum 1 - superseded by Data Report Rev 2 (Es 320/900/2400 ksf and 4,000 psf presumptive withdrawn)",
  "AV-CR-2604 Basis of Design Rev 1 - superseded by Rev 3 (all-Warehouse occupancy, F0, 1-in dimensions, 20 ft depth)",
  "NOAA NCEI air-freezing-index return periods 1951-1980 (416 F-days at USC00444909) - superseded edition",
  "Presumptive bearing values: Data Report Rev 2 sec. 7 (3,000 psf) and building-code presumptive values - prohibited by AHJ Amendment 4",
  "Broadview Commons adjacent parcel report (5,500 psf) - different property, information only",
  "FHWA GEC 6 bridge tolerable-movement criteria (angular distortion 0.004-0.005) - manual for a different class of structure",
  "EM 1110-2-2104 Table 3-1 hydraulic-structure load factors - not applicable per load-combination memo",
  "Proprietary vendor stress-concentration ratios (20 or higher) - not accepted per RFI-011",
  "UFC 3-220-20 sec. 5-4 subgrade-reaction (ks) estimator - not the settlement method for isolated footings per RFI-019"
 ]
}
```

# Design basis - Phase 1 foundation strategy, Cattail Run Data Campus (AV-CR-2604)

Structural engineer of record, Phase 1 foundation package. Six pads (CR-P1 to CR-P6), each with one instrumented column line of five isolated column footings (F1-F5) and one continuous shear-wall footing (W1). Every number below is derived from the documents in the data room; the deliverables foundation_geometry.json, ground_improvement_plan.json, foundation_schedule.xlsx, foundation_feasibility_matrix.md and constraint_register.xlsx carry the same values.

## 1. Governing criteria and documents set aside

The criteria that govern are: UFC 3-220-01 Geotechnical Engineering (1 Nov 2012, Change 3, 1 Jul 2025) for bearing, factors of safety (Table 2-3), settlement limits, minimum widths and depth, frost and presumptive-value prohibition; UFC 3-301-01 Structural Engineering (2023, Change 4) for load combinations (2-4.3) and thick-footing reinforcement (1808.8.2.1); UFGS 03 30 00 paragraph 2.5.2 for the concrete exposure-class limits; the Loudoun County AHJ letter LC-BD-26-0774 (Amendment 3 frost depth, Amendment 4 no presumptive values); the Basis of Design Rev 3; the Geotechnical Data Report Rev 2 with its boring logs and laboratory summary; the civil grading and groundwater record; the load-combination memo; the RFI log; the Kettleridge proposal KGS-26-0917 for pier parameters, prices and the mobilisation rule; and the BIM parameter standard Rev 2. The analysis references applied are UFC 3-220-20 (DM 7.2, 2025) chapter 5 for bearing capacity and its sections 4-5.1.2/4-5.1.3 and Figure 5-41 for wall stability, EM 1110-1-1905 for the bearing-capacity cross-check and groundwater adjustment, FHWA GEC 13 chapter 5 for rammed aggregate piers and the elastic settlement equation, EM 1110-2-2502 for the sliding limit-equilibrium procedure, EM 1110-2-2104 for reinforced-concrete strength (shear per paragraph 5.1) and EM 1110-2-2000 Table 2-2 for the sulfate exposure condition.

Documents reviewed and set aside, with the reason:

- UFC 3-220-01N Foundation Design (2005) and UFC 3-220-10N Soil Mechanics (2005) were set aside because they are cancelled predecessor volumes; UFC 3-220-01 (2012, Change 3) and UFC 3-220-20 (2025) replace them.
- Geotechnical Addendum 1 was set aside because it is superseded in its entirety by Data Report Rev 2 (its Es values of 320/900/2400 ksf and its 4,000 psf presumptive value are withdrawn).
- Basis of Design Rev 1 was set aside because Rev 3 supersedes it (Rev 1 classified every building as Warehouse with F0 concrete, allowed 1-in dimensions and 20 ft depth).
- The NOAA NCEI 1951-1980 air-freezing-index tables were set aside because the AHJ letter Amendment 3 and RFI-007 name them the superseded edition of the product.
- The Broadview Commons adjacent-parcel report (5,500 psf) was set aside because it is a different property with different stratigraphy (RFI-013).
- FHWA GEC 6 (shallow foundations for bridges) was set aside because it is written for a different class of structure; its bridge movement criteria are not used.
- EM 1110-2-2104 Table 3-1 load factors were set aside because they are for hydraulic structures and the load-combination memo states they do not apply.
- The 3,000 psf presumptive value of Data Report Rev 2 section 7 and all building-code presumptive values were set aside because AHJ Amendment 4, UFC 3-220-01 2-4.5.2/2-4.6.4 and RFI-009 prohibit presumptive bearing values where a site investigation has been made.

## 2. Bearing-capacity and settlement methods applied; factor of safety at each pad

Bearing capacity was evaluated with three widely accepted methods, as UFC 3-220-01 paragraph 2-4.7.1 requires: Terzaghi (UFC 3-220-20 Table 5-2/5-5), Meyerhof 1963 (Table 5-6) and Brinch Hansen 1970 (Table 5-8), each in the general drained bearing-capacity equation UFC 3-220-20 Eq. 5-15 with the drained parameters of the bearing stratum (Stratum I: phi' = 26 deg, c' = 0.25 ksf, 118 pcf); the Vesic solution of the same general equation (EM 1110-1-1905 Eq. 4-1, Table 4-4) was also computed. The groundwater correction of UFC 3-220-20 Figure 5-6 (EM 1110-1-1905 Eq. 1-6) was applied at every footing with the stabilised piezometer depths (8.0, 9.0, 19.0, 8.0, 21.0 and 8.5 ft); at CR-P1, CR-P2, CR-P4 and CR-P6 the water table lies within one footing width below the bearing level, so the N-gamma term uses the reduced average unit weight gamma_av = gamma - gamma_w (Df + B - Dw)/B. Engineering judgement under RFI-021 selects the design value: the Meyerhof (1963) solution of the general equation, which UFC 3-220-20 Table 5-3 identifies as applicable to any bearing condition and suited to soils whose strength is dominated by frictional parameters (the Terzaghi method is listed for undrained conditions), capped by the Vesic solution where that is lower. The reported net allowable bearing pressure is therefore q_allow,net = min(qult,Meyerhof, qult,Vesic) / FS - sigma'zD (UFC 3-220-20 Eq. 5-14, the more conservative net convention), so it is never more permissive than the general bearing-capacity equation of the foundations manual (RFI-021 test b). The Terzaghi and Brinch Hansen results are tabulated below as the lower-bound methods; the design value lies 4-19 percent above the least of the three and below the Vesic value computed with the net-ultimate convention (qult - sigma'zD)/FS. The applied net pressure is q_net = P/(B L) + (150 - 118 pcf) t under the D + L service reactions and is <= q_allow,net at every footing. No presumptive value was used anywhere.

The factor of safety at each pad is the UFC 3-220-01 Table 2-3 minimum for the STRUCTURE row assigned in Basis of Design Rev 3 section 2: FS = 3.5 at CR-P1, CR-P2, CR-P3 and CR-P6 (Light Industrial, Public); FS = 3.0 at CR-P4 (Apartments, Office); FS = 2.5 at CR-P5 (Warehouse - the Table 2-3 note calling for FS > 3 for super-flat warehouse floors is not invoked because the Basis of Design sets no such floor requirement). The same FS is used for improved footings, whose allowable pressure is conservatively the unimproved Stratum I value.

Settlement was computed by the method RFI-019 directs: layered elastic compression, s = sum(delta-sigma x H / Es), with the net stress increment from the 2 vertical to 1 horizontal distribution for a rectangular loaded area, delta-sigma = q_net B L / ((B + z)(L + z)), evaluated at the mid-height of uniform 0.25 ft layers carried to max(4B, 40 ft) below the bearing surface, with the pad-specific Es of Data Report Rev 2 and the Stratum I base interpolated by station (rounded to 0.1 ft). This is FHWA GEC 13 Eq. 5-14. For improved footings the GEC 13 two-layer method was used: upper-zone settlement s_uz = qg / kg (Eq. 5-13) with qg = q ns / (ns Ra - Ra + 1) (Eq. 5-12), plus the same layered elastic compression below the treatment depth (Eq. 5-11/5-14). Every settlement was also re-run with the layer compliance split at the stratum contacts; the larger value is reported. The subgrade-reaction estimator of the combined-footing and mat chapter (UFC 3-220-20 5-4) was not used.

| Pad | Occupancy (BoD Rev 3) | FS | Bearing depth (in) | Sulfate class | Exposure classes | fc (psi) / max w/cm | Governing constraint | Decision | Spread-only cost | Improved cost |
|---|---|---|---|---|---|---|---|---|---|---|
| CR-P1 | Light Industrial, Public | 3.5 | 45 | S1 | F1, S1, W1, C1 | 4000 / 0.50 | BEARING | IMPROVED_SPREAD | $241,639 | $77,244 |
| CR-P2 | Light Industrial, Public | 3.5 | 45 | S2 | F1, S2, W1, C1 | 4500 / 0.45 | BEARING | IMPROVED_SPREAD | $261,599 | $82,330 |
| CR-P3 | Light Industrial, Public | 3.5 | 45 | S0 | F1, S0, W1, C1 | 4000 / 0.50 | BEARING | SPREAD | $31,427 | $51,932 |
| CR-P4 | Apartments, Office | 3.0 | 45 | S1 | F1, S1, W1, C1 | 4000 / 0.50 | BEARING | IMPROVED_SPREAD | $63,106 | $43,715 |
| CR-P5 | Warehouse | 2.5 | 42 | S0 | F3, S0, W1, C1 | 5000 / 0.40 | BEARING | SPREAD | $18,277 | $38,137 |
| CR-P6 | Light Industrial, Public | 3.5 | 45 | S2 | F1, S2, W1, C1 | 4500 / 0.45 | BEARING | IMPROVED_SPREAD | $209,229 | $79,023 |

Ultimate bearing capacity by method and the reported net allowable (ksf):

| Foundation | qult Terzaghi | qult Meyerhof | qult Brinch Hansen | qult Vesic | least-of-three net allowable | q_allow,net reported (design) | q_net applied |
|---|---|---|---|---|---|---|---|
| CR-P1-F1 | 19.00 | 21.20 | 19.27 | 21.85 | 4.987 | 5.615 | 5.605 |
| CR-P1-F2 | 20.03 | 22.02 | 19.48 | 22.18 | 5.124 | 5.847 | 5.716 |
| CR-P1-F3 | 20.30 | 22.26 | 19.56 | 22.30 | 5.146 | 5.916 | 5.836 |
| CR-P1-F4 | 19.57 | 21.57 | 19.32 | 21.92 | 5.077 | 5.720 | 5.670 |
| CR-P1-F5 | 18.66 | 20.85 | 19.15 | 21.65 | 4.888 | 5.515 | 5.264 |
| CR-P1-W1 | 19.38 | 19.35 | 17.88 | 20.59 | 4.665 | 5.084 | 4.991 |
| CR-P2-F1 | 19.14 | 21.30 | 19.29 | 21.88 | 5.027 | 5.644 | 5.416 |
| CR-P2-F2 | 20.21 | 22.22 | 19.57 | 22.32 | 5.148 | 5.906 | 5.853 |
| CR-P2-F3 | 20.61 | 22.61 | 19.71 | 22.55 | 5.190 | 5.999 | 5.992 |
| CR-P2-F4 | 19.95 | 22.01 | 19.51 | 22.22 | 5.132 | 5.846 | 5.788 |
| CR-P2-F5 | 19.02 | 21.30 | 19.35 | 21.97 | 4.992 | 5.644 | 5.576 |
| CR-P2-W1 | 19.88 | 19.90 | 18.22 | 21.11 | 4.763 | 5.242 | 5.194 |
| CR-P3-F1 | 19.74 | 22.45 | 19.95 | 22.92 | 5.199 | 5.972 | 5.792 |
| CR-P3-F2 | 21.34 | 23.92 | 20.44 | 23.69 | 5.397 | 6.325 | 6.234 |
| CR-P3-F3 | 22.54 | 25.14 | 20.92 | 24.44 | 5.533 | 6.541 | 5.304 |
| CR-P3-F4 | 21.19 | 23.76 | 20.38 | 23.59 | 5.379 | 6.297 | 5.407 |
| CR-P3-F5 | 19.43 | 22.17 | 19.87 | 22.79 | 5.108 | 5.893 | 5.557 |
| CR-P3-W1 | 20.27 | 19.86 | 18.32 | 21.61 | 4.792 | 5.230 | 4.778 |
| CR-P4-F1 | 18.59 | 20.95 | 19.26 | 21.83 | 5.754 | 6.541 | 4.800 |
| CR-P4-F2 | 19.03 | 21.20 | 19.26 | 21.83 | 5.902 | 6.624 | 6.513 |
| CR-P4-F3 | 19.27 | 21.36 | 19.28 | 21.86 | 5.981 | 6.678 | 6.560 |
| CR-P4-F4 | 18.77 | 21.00 | 19.21 | 21.75 | 5.816 | 6.556 | 6.246 |
| CR-P4-F5 | 18.00 | 20.65 | 19.31 | 21.90 | 5.559 | 6.440 | 6.281 |
| CR-P4-W1 | 17.55 | 17.18 | 16.46 | 18.86 | 5.045 | 5.283 | 5.168 |
| CR-P5-F1 | 18.27 | 21.05 | 19.12 | 21.91 | 6.896 | 8.008 | 7.412 |
| CR-P5-F2 | 19.48 | 21.99 | 19.33 | 22.24 | 7.317 | 8.383 | 8.076 |
| CR-P5-F3 | 19.87 | 22.34 | 19.44 | 22.41 | 7.363 | 8.524 | 8.288 |
| CR-P5-F4 | 19.05 | 21.62 | 19.22 | 22.06 | 7.209 | 8.236 | 7.975 |
| CR-P5-F5 | 17.97 | 20.85 | 19.10 | 21.88 | 6.776 | 7.927 | 7.370 |
| CR-P5-W1 | 18.27 | 17.72 | 16.71 | 19.55 | 6.269 | 6.675 | 4.791 |
| CR-P6-F1 | 18.92 | 21.07 | 19.20 | 21.73 | 4.965 | 5.576 | 5.456 |
| CR-P6-F2 | 20.04 | 22.03 | 19.49 | 22.19 | 5.125 | 5.850 | 5.821 |
| CR-P6-F3 | 20.43 | 22.41 | 19.63 | 22.41 | 5.166 | 5.960 | 5.943 |
| CR-P6-F4 | 19.81 | 21.87 | 19.45 | 22.13 | 5.115 | 5.805 | 5.782 |
| CR-P6-F5 | 18.97 | 21.24 | 19.32 | 21.92 | 4.976 | 5.625 | 5.368 |
| CR-P6-W1 | 19.75 | 19.72 | 18.12 | 20.97 | 4.733 | 5.192 | 5.089 |

## 3. Tolerable-movement criteria

The tolerable-movement criteria adopted are those of UFC 3-220-01 paragraph 2-4.7.1: total post-construction settlement not more than 1 in, and differential settlement not producing an angular distortion greater than 1/500 between adjacent foundation units (difference in settlement divided by the distance between the units). Adjacent units are F1-F2 (24 ft), F2-F3 (20 ft), F3-F4 (16 ft), F4-F5 (12 ft) and F5-W1 (5 ft, i.e. 0.12 in maximum differential). Every foundation was designed to a computed settlement of 0.97 in or less and every adjacent pair to the 1/500 limit less 0.01 in, on both layer-assignment variants. EM 1110-1-1905 paragraph 4-1b (1 in, 1/500) is consistent. The competing criterion rejected is the FHWA GEC 6 bridge criterion (angular distortion 0.004 for continuous and 0.005 for simple spans, section 5.3.1) and its 1/300 masonry figure (section 8.3.1), which are for a different class of structure and are less restrictive than the governing 1/500.

## 4. Ground-improvement design parameters and authority

- Stress concentration ratio ns = 10: FHWA GEC 13 chapter 5 section 4.2.1 value for structure foundation support under rigid footings, as directed by RFI-011 (vendor manual ratios of 20 or more are not accepted).
- Pier diameter 30 in (area 4.909 sf) and minimum clear spacing 1.0 ft (3.5 ft centres): Kettleridge proposal section 2; this fixes the maximum area replacement ratio at 0.401 (square grid) / 0.463 (staggered).
- Minimum area replacement ratio Ra = 0.33: FHWA GEC 13 section 4.2.1 (Collin 2007); adopted Ra 0.33-0.40, Ra = n x 4.909 / (B L), with the pier count checked to fit inside the footing footprint.
- Stiffness modulus kg: Kettleridge proposal section 3 as-tested pad values (CR-P1 165, CR-P2 140, CR-P4 195, CR-P6 155 pci; CR-P3 210 and CR-P5 230 pci not needed), used in GEC 13 Eq. 5-13.
- Treatment depth 8 to 25 ft below footing soffit, whole feet: Kettleridge section 2 and BoD Rev 3 section 4; adopted 8-11 ft, chosen so that at 23 of the 23 improved footings the piers penetrate the full thickness of the compressible Stratum I below the soffit (residual Stratum I below tips: 0.00 ft); only the stiff Strata II/III contribute to the lower-zone compression.
- Maximum design top-of-pier stress 18,000 psf: Kettleridge section 2 (verified at 150 percent in the modulus test); maximum design qg = 16049 psf.
- Verification: one production modulus test per improved pad (Kettleridge section 5; GEC 13 section 4.4).

| Improved pad | kg (pci) | Improved units | Treatment depth (ft) | Total pier LF | Piers |
|---|---|---|---|---|---|
| CR-P1 | 165 | F1, F2, F3, F4, F5, W1 | 9 | 686 | 82 |
| CR-P2 | 140 | F1, F2, F3, F4, F5, W1 | 10 | 721 | 86 |
| CR-P4 | 195 | F2, F3, F4, F5, W1 | 8 | 344 | 43 |
| CR-P6 | 155 | F1, F2, F3, F4, F5, W1 | 11 | 680 | 82 |

## 5. Conflicts between documents and their resolution

- Frost depth: the 1981-2010 NCEI product gives a 100-year AFI of 556 F-days at USC00444909 (LINCOLN, VA) while the 1951-1980 tables give 416 F-days. Resolved by AHJ Amendment 3 and RFI-007: the current 1981-2010 product governs, 556 > 500 F-days, so the governing frost depth is 42 in (not 30 in). UFC 3-220-01 2-4.8.4 directs use of the local published value; the 18 in UFC minimum is exceeded.
- Presumptive bearing: Data Report Rev 2 section 7 (3,000 psf), Addendum 1 (4,000 psf) and the adjacent parcel (5,500 psf) versus AHJ Amendment 4 / UFC 3-220-01 2-4.5.1, 2-4.5.2, 2-4.6.4 / RFI-009. Resolved: no presumptive value; governing values are the site-specific q_allow,net of each footing (5.08-8.52 ksf).
- Elastic moduli: Addendum 1 (320/900/2400 ksf, all pads) versus Data Report Rev 2 pad-specific values. Resolved: Rev 2 governs (e.g. Stratum I 85 ksf at CR-P2, 250 ksf at CR-P5).
- Occupancy and exposure: BoD Rev 1 (all Warehouse, F0) versus Rev 3. Resolved: Rev 3 governs - FS 3.5/3.0/2.5 and F1 (F3 at CR-P5 for de-icing exposure).
- Sliding factor of safety: UFC 3-220-01 2-4.6.3 (2.0), UFC 3-220-20 4-5.1.3 (1.5, or 2.0 with passive) and EM 1110-2-2502 Table 4-1 (1.5 usual). Resolved: the governing criteria value 2.0 is used, and is also the DM 7.2 value when passive resistance is counted. The 0.6D + W normal force is taken net of the exported wind uplift (conservative).
- Minimum reinforcement: BoD Rev 3 (0.0018 each direction) versus UFC 3-301-01 1808.8.2.1 and UFC 3-220-01 2-4.7.7 (0.0015 for footings over 3 ft thick). Resolved per BoD: the thick-footing minimum is not higher, so 0.0018 governs, with No. 4 minimum bars at 12 in maximum spacing.
- Load factors: EM 1110-2-2104 Table 3-1 (hydraulic) versus the load-combination memo (UFC 3-301-01 2-4.3). Resolved: memo combinations 1.2D + 1.6L, D + L, 0.6D + W and D + L + W govern.
- Stress concentration ratio: vendor manuals (20+) versus GEC 13 (10 for rigid footings). Resolved by RFI-011: ns = 10.
- Settlement method: UFC 3-220-01 Appendix B points to EM 1110-1-1904 and DM 7.1 (not in the data room / cancelled edition). Resolved by RFI-019: layered elastic compression, 0.25 ft layers, max(4B, 40 ft).
- Footing spacing 1.5B (UFC 3-220-01 2-4.8.1, EM 1110-1-1905 1-4e) versus the Phase 1 grid. Resolved by RFI-017: individual units sized, scheduled and priced, no overlap reduction; combined footings follow in the construction documents.
- Sulfate exposure: owner does not assign the S class (BoD Rev 3 sec. 2); EM 1110-2-2000 Table 2-2 gives the condition (moderate 0.10-0.20 %, severe > 0.20 %) and UFGS 03 30 00 2.5.2.4 the class limits. Governing: CR-P1 S1 (0.14 %), CR-P2 S2 (0.23 %), CR-P3 S0 (0.07 %), CR-P4 S1 (0.11 %), CR-P5 S0 (0.05 %), CR-P6 S2 (0.26 %).
- Concrete: the most restrictive class limit governs each pad (BoD Rev 3 sec. 3) and only the listed strengths are available: CR-P1 4000 psi / 0.50, CR-P2 4500 / 0.45, CR-P3 4000 / 0.50 (W1 governs), CR-P4 4000 / 0.50, CR-P5 5000 / 0.40 (F3 governs), CR-P6 4500 / 0.45.
- Deep foundations: evaluable in the cost comparison (UFC 3-220-01 2-4.8.1) but not accepted by the owner (RFI-015); not selected.

## 6. Campus programme

Spread footings alone cannot meet the 1 in total-settlement limit economically on the soft Stratum I residuum of CR-P1, CR-P2 and CR-P6 (Es 85-110 ksf, 6-14 ft thick): the cheapest spread-only programmes found bear at 8-10 ft (the lighter units in Stratum II, the heavier on Stratum I footings up to 26 ft wide) with up to 6 dewatering days and 1.5H:1V excavations, at $241,639, $261,599 and $209,229 for CR-P1, CR-P2 and CR-P6. Rammed aggregate piers under bearing-sized footings reduce those pads to $77,244, $82,330 and $79,023 including the modulus test. CR-P4 is also improved: its spread-only programme costs $63,106 against $43,715 improved, and because three pads are already improved its share of a rig adds no mobilisation (a rig serves two pads). CR-P3 and CR-P5 stay on spread footings: their stiffer Stratum I (210 and 250 ksf) meets the settlement limits with bearing-sized footings, and improving either would cost more ($51,932 and $38,137 improved versus $31,427 and $18,277 spread) and would force a third rig (+$40,000).

The pads improved are CR-P1, CR-P2, CR-P4, CR-P6. The number of rigs mobilised is 2, because Kettleridge section 4 allows each mobilised rig to serve at most 2 building pads within the Phase 1 milestone window: ceil(4 pads / 2) = 2 rigs, mobilisation $80,000 (lump sum $40,000 per rig, not prorated). Rig assignments: RIG-1 serves CR-P1 and CR-P2; RIG-2 serves CR-P4 and CR-P6. One production modulus test is bought per improved pad (4 tests). Campus total cost at the project budget prices is $412,014 (footings, piers, platform, excavation, backfill, tests and mobilisation; no dewatering is needed because every bearing level (CR-P1 45 in, CR-P2 45 in, CR-P3 45 in, CR-P4 45 in, CR-P5 42 in, CR-P6 45 in) is above the stabilised groundwater and no deeper than the 4.0 ft side-slope threshold).

Bearing elevation: the 42 in frost minimum (AHJ Amendment 3) is the shallowest permitted level and is used at CR-P5. At CR-P1, CR-P2, CR-P3, CR-P4, CR-P6 the bearing level is 45 in, one 3-in step below the frost minimum, because there the 39-42 in thick column footings need soil cover at 42 in, or the deeper level gives a stiffer allowable bearing pressure and smaller footings at lower total cost. Deeper levels were rejected because the 1.5H:1V side slopes required below 4.0 ft more than double the excavation cost and bring dewatering below the 8-9 ft groundwater.

Governing constraint: on every pad BEARING selects the design - footings are sized so that q_net is at or within a few percent of q_allow,net, and removing one 3-in step of width from those footings would exceed the allowable. SETTLEMENT governs CR-P3 F3, CR-P3 F4, CR-P3 W1, CR-P4 F1. SLIDING governs CR-P5 W1.

Shear-wall footings: each W1 footing is as long as the 24 ft (288 in) wall, so it acts as a continuous footing cantilevering across its width B only; B >= 20 in (12 in wall + 8 in, UFC 3-220-01 2-4.7.1). Sliding (0.6D + W) is checked with base friction tan(2/3 phi') on the Stratum I soffit plus one half of the Rankine passive resistance on the embedded end face, with the 0.6D normal force reduced by the exported net wind uplift (conservative): FS >= 2.0. The service D + L + W resultant lies within the middle third (e <= L/6) and the uplift factor of safety 0.6(Wf + Ws + D)/U exceeds 1.5.

Structural design: thickness from two-way shear at d/2 and one-way shear at d (phi = 0.75, Vc per EM 1110-2-2104 paragraph 5.1), d = t - 4 in, minimum 12 in, rounded up to 3 in; reinforcement ratio = max(0.0018, flexural requirement at the column or wall face with phi = 0.9, 1.2D + 1.6L), provided by bars No. 4 to No. 10 at 6 to 12 in. The scheduled ratio is the bottom mat in each direction, priced per BoD Rev 3 sec. 3 (2 x ratio x gross volume x 490 pcf). For the footings thicker than 36 in, UFC 3-301-01 1808.8.2.1 / UFC 3-220-01 2-4.7.7 (0.0015 minimum, between one-half and two-thirds of it in any one face, No. 4 minimum at 12 in maximum) is satisfied in detailing by adding a top mat of No. 5 bars at 12 in each way in the construction documents; the 0.0018 BoD minimum governs the scheduled ratio.

