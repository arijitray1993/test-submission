# Conveyance Study - 13.8 kV Site Distribution, Pacific Crest SFA (FA4610-26-R-0031, PCSFA 24-0117)

Prepared by the design-build contractor (electrical engineer / cost estimator). Study date 2026-09-15. Basis: RFP Section 01 11 00 Amendment 0002; PCSFA-IEDS Rev 3; documents current per Transmittal T-0117-09. Workbook `conveyance_study.xlsx` contains the full take-off, design tables and live roll-up formulas.

## 1. Summary of recommendations

| Item | Circuit | Recommended | Cable | Sets | OH conductor | Design current (A) | Ampacity/set (A) | Route (ft) | Total project cost | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|
| C01 | SS-1 F1 to MB-1 MSG-A (ER-A) | CEDB | 500 | 2 | - | 640 | 331.5 | 834.1 | $262,930 | 315.23 |
| C02 | SS-1 F2 to MB-1 MSG-B (ER-B) | CEDB | 500 | 2 | - | 560 | 331.5 | 1103.4 | $327,406 | 296.72 |
| C03 | SS-1 F3 to CUP-1 SWG-C1 (south entry) | CEDB | 500 | 1 | - | 400 | 461.3 | 344.9 | $70,528 | 204.48 |
| C04 | CUP-1 CF-2 (east entry) to LS-2 TX-LS2 | CEDB | 250 | 1 | - | 60 | 315.9 | 1199.2 | $243,223 | 202.82 |
| C05 | MB-1 MSG-A feeder A-3 to USS-A1 (inside MB-1) | TRAY-EN | 250 | 2 | - | 200 | 160.0 | 400.0 | $153,570 | 383.92 |
| C06 | SS-1 F4 to gate house TX-GH1 | OH | 250 | 1 | 1/0 | 40 | 196.0 | 1838.2 | $110,138 | 59.92 |
| C07 | CUP-1 CF-1 (north entry) to W-3 TX-W3 | CEDB | 250 | 1 | - | 120 | 315.9 | 680.0 | $127,493 | 187.49 |

Total of the seven recommended designs: **$1,295,288** total project cost.

## 2. Estimating basis

* Wage determination CA20260022 **Modification 5** (published 08/06/2026, effective under 29 CFR 1.6(c)(2)(ii)(A) for the 2026-10-08 bid opening); classifications per RFP 2.1.
* Loaded rate = base x (1 + burden) + fringe; burden = FICA 7.65 + FUTA 0.60 + CA SUI 3.40 + workers compensation of the class code (7538 line 8.74; 5190 inside wiring 4.12; 6218 excavation 7.35) %.
* Labor units: PCEC database 2026.1; P-405 units x 67/80; PULL-MV and DBC-LAY x 0.85 (puller); XARM, GUY, STRING x 0.85 (bucket truck). Crew hours = MH / crew size; equipment hours = crew hours x units.
* Equipment: EP 1110-1-8 Vol 7 Region VII Table 2-2 average rates with FUEL and FOG multiplied by jobsite/area fuel price ratios (diesel off-road 4.38/2.26 = 1.9381; gasoline 5.12/2.49 = 2.0562) per EP 1110-1-8 3.9/3.10; rentals per RQ-26-0419.
* Materials: Q-2608-114 price x (1 + waste) x PPI adjustment for (I) items (WPU102603 Aug-2026 494.096 / Jul-2026 482.612 = 1.02380) x 1.095 sales tax. Subcontracts at ADD-26-311 and PJB-8817.
* Roll-up: JOOH 9.5 %; HOOH 4.5 %; profit (weighted guidelines, weights size 0.0614, period 0.0848, subcontracting 0.0862) = **7.9494 %**; bond effective rate **1.3034 %** (Class B schedule on $1,130,157 = $14,731 incl. 3 % surcharge for 15 months); escalation factor **1.019388** (UFS 3-701-01 Table 4-2: 1.061693 at 2027-08-18 / 1.041501 at 2026-09-15); design contingency 5.0 %; SIOH 5.7 % of contract cost + contingency; no area cost factor (UFS 3-701-01 4-1.1).

### Labor rates used

| Class | WD group | Base $/h | Fringe $/h | Burden % | Loaded $/h |
|---|---|---|---|---|---|
| LINEMAN (LINE CONSTRUCTION: (1) LINEMAN; CABLE SPLICER) | ELEC1245-001 | 70.16 | 24.71 | 20.39 | 109.18 |
| EQSPEC (LINE CONSTRUCTION: (2) EQUIPMENT SPECIALIST) | ELEC1245-001 | 53.30 | 22.26 | 20.39 | 86.43 |
| GROUNDMAN (LINE CONSTRUCTION: (3) GROUNDMAN) | ELEC1245-001 | 40.76 | 21.76 | 20.39 | 70.83 |
| LAB1 (LABORER GROUP 1) | LABO0300-003 | 46.48 | 25.95 | 19.00 | 81.26 |
| LAB3 (LABORER GROUP 3) | LABO0300-003 | 47.58 | 25.95 | 19.00 | 82.57 |
| LAB4 (LABORER GROUP 4 (PREFABRICATED MANHOLE INSTALLER)) | LABO0300-003 | 49.13 | 25.95 | 19.00 | 84.41 |
| PUMPOP (OPERATOR: POWER EQUIPMENT, ALL OTHER WORK: GROUP 1 (PUMP OPERATOR)) | ENGI0012-024 | 63.40 | 33.20 | 19.00 | 108.65 |
| ELECTRICIAN (ELECTRICIAN: INSIDE ELECTRICAL WORK: JOURNEYMAN ELECTRICIAN) | ELEC0011-004 | 60.80 | 31.59 | 15.77 | 101.98 |
| SPLICER_IN (ELECTRICIAN: INSIDE ELECTRICAL WORK: CABLE SPLICER (5% ADDITIONAL)) | ELEC0011-004 | 63.84 | 31.59 | 15.77 | 105.50 |

### Crew rates used

| Crew | Size | Avg loaded labor $/MH | Equipment $/crew-hour |
|---|---|---|---|
| CR-EX | 2 | 83.845 | 58.68 |
| CR-TM | 2 | 82.570 | 14.61 |
| CR-BF | 3 | 83.856 | 33.88 |
| CR-DU | 6 | 83.613 | 0.00 |
| CR-CO | 4 | 81.261 | 0.00 |
| CR-CP | 6 | 86.212 | 154.50 |
| CR-SP | 2 | 90.003 | 0.00 |
| CR-MH | 4 | 84.918 | 61.06 |
| CR-DW | 1 | 108.646 | 3.85 |
| CR-OH | 4 | 90.003 | 96.00 |
| CR-OH2 | 2 | 90.003 | 96.00 |
| CR-OH3 | 3 | 96.394 | 96.00 |
| CR-STR | 10 | 86.169 | 192.00 |
| CR-IN | 2 | 101.978 | 11.80 |
| CR-IS | 2 | 103.738 | 0.00 |

### Equipment rates used

| ID | Description | Source | $/h |
|---|---|---|---|
| H25CA040 | HYDRAULIC EXCAVATOR, CRAWLER, 40,600 LBS, 1.00 CY BUCKET, 22.50' MAX DIGGING DEPTH | EP 1110-1-8 Vol 7 Region VII (2016) Table 2-2 avg; FUEL+FOG x 1.9381 (D-off $4.38/$2.26 per EP 1110-1-8 3.9/3.10) | 58.6770 |
| T30DW022 | TRENCHER, CHAIN TYPE CUTTER, 48" MAX DEPTH X 3.5"-6" WIDTH, WALK BEHIND, CRAWLER | EP 1110-1-8 Vol 7 Region VII (2016) Table 2-2 avg; FUEL+FOG x 2.0562 (G $5.12/$2.49 per EP 1110-1-8 3.9/3.10) | 14.6101 |
| L50CA001 | LOADER / BACKHOE, WHEEL, 1.00 CY FRONT END BUCKET, 24" DIP, 14.5' DIGGING DEPTH, 4X2 | EP 1110-1-8 Vol 7 Region VII (2016) Table 2-2 avg; FUEL+FOG x 1.9381 (D-off $4.38/$2.26 per EP 1110-1-8 3.9/3.10) | 30.9820 |
| C10BO003 | COMPACTOR, VIBROPLATE, 14.2" X 22" PLATE, 2,250 LBS IMPACT | EP 1110-1-8 Vol 7 Region VII (2016) Table 2-2 avg; FUEL+FOG x 2.0562 (G $5.12/$2.49 per EP 1110-1-8 3.9/3.10) | 2.9006 |
| C80TE008 | CRANES, HYDRAULIC, TRUCK MTD, ROUGH TERRAIN, 25 TON, 72' BOOM, 4X4 | EP 1110-1-8 Vol 7 Region VII (2016) Table 2-2 avg; FUEL+FOG x 1.9381 (D-off $4.38/$2.26 per EP 1110-1-8 3.9/3.10) | 61.0584 |
| P50WC002 | PUMP, WATER, CENTRIFUGAL, TRASH, ENGINE DRIVE, 3" DIA, 425 GPM @ 95' HEAD | EP 1110-1-8 Vol 7 Region VII (2016) Table 2-2 avg; FUEL+FOG x 1.9381 (D-off $4.38/$2.26 per EP 1110-1-8 3.9/3.10) | 3.8528 |
| RQ-BDT | Bucket / digger-derrick line truck, 47 ft, 4x4 | Rental quote RQ-26-0419 | 96.0000 |
| RQ-PUL | Cable puller, hydraulic capstan/bullwheel, 10,000 lb with dynamometer | Rental quote RQ-26-0419 | 58.5000 |
| RQ-LFT | Scissor lift, 26 ft, electric (indoor) | Rental quote RQ-26-0419 | 11.8000 |

### Material unit rates used (installed price incl. waste, index, tax)

| Code | Unit | Quote price | Waste | Index | Rate used |
|---|---|---|---|---|---|
| ACSR-1/0 | LF | 0.62 | 2 % | PPI | 0.7090 |
| ACSR-336.4 | LF | 1.72 | 2 % | PPI | 1.9668 |
| ASPHALT | SY | 38.00 | 0 % | - | 41.6100 |
| BOND-2 | LF | 2.10 | 3 % | PPI | 2.4248 |
| CBL-250 | LF | 6.20 | 3 % | PPI | 7.1591 |
| CBL-350 | LF | 7.45 | 3 % | PPI | 8.6024 |
| CBL-500 | LF | 9.10 | 3 % | PPI | 10.5077 |
| CONC-3000 | CY | 212.00 | 8 % | - | 250.7112 |
| EB20-5 | LF | 4.15 | 5 % | - | 4.7715 |
| ELBOW-RGS5 | EA | 640.00 | 0 % | - | 700.8000 |
| EMT-4IN | LF | 14.80 | 5 % | - | 17.0163 |
| FIRE-SLV-4 | EA | 310.00 | 0 % | - | 339.4500 |
| FIRESTOP-RMC5 | EA | 145.00 | 0 % | - | 158.7750 |
| FIRETAPE | LF | 3.40 | 5 % | - | 3.9091 |
| GND-4/0 | LF | 7.90 | 3 % | PPI | 9.1220 |
| GUY-ASSY | EA | 420.00 | 0 % | - | 459.9000 |
| MH-PRECAST | EA | 16,850.00 | 0 % | - | 18,450.7500 |
| PBOX-36 | EA | 1,180.00 | 0 % | - | 1,292.1000 |
| POLE-45 | EA | 1,480.00 | 0 % | - | 1,620.6000 |
| POLE-50 | EA | 1,760.00 | 0 % | - | 1,927.2000 |
| REBAR-4 | LB | 1.18 | 5 % | - | 1.3567 |
| RGS-5 | LF | 61.00 | 5 % | - | 70.1347 |
| RISER-ASSY | EA | 3,950.00 | 0 % | - | 4,325.2500 |
| ROCK-BASE | CY | 62.00 | 10 % | - | 74.6790 |
| SAND | CY | 48.00 | 10 % | - | 57.8160 |
| SCH40-5 | LF | 8.90 | 5 % | - | 10.2328 |
| SCH40-6 | LF | 11.75 | 5 % | - | 13.5096 |
| SEISMIC-BR | EA | 165.00 | 0 % | - | 180.6750 |
| SPACER | EA | 3.10 | 0 % | - | 3.3945 |
| TAPE-DET | LF | 0.28 | 5 % | - | 0.3219 |
| TERM-KIT | EA | 265.00 | 0 % | - | 290.1750 |
| TRAY-24-LD | LF | 29.00 | 5 % | - | 33.3428 |
| TRAY-24-SB | LF | 38.00 | 5 % | - | 43.6905 |
| TRAY-COV-24 | LF | 12.50 | 5 % | - | 14.3719 |
| XARM-ASSY | EA | 385.00 | 0 % | - | 421.5750 |

### Labor units used (MH per unit after conversions)

| Code | Unit | Database MH | Factor | MH used | Crew |
|---|---|---|---|---|---|
| EX-MACH | BCY | 0.0182 | 0.8375 | 0.01524 | CR-EX |
| EX-TRCH | LF | 0.011 | 0.8375 | 0.00921 | CR-TM |
| BF-COMP | BCY | 0.06 | 1.0000 | 0.06000 | CR-BF |
| SAND-BED | CY | 0.45 | 1.0000 | 0.45000 | CR-BF |
| DUCT-CE | LF | 0.04 | 0.8375 | 0.03350 | CR-DU |
| DUCT-UE | LF | 0.0255 | 0.8375 | 0.02136 | CR-DU |
| CONC-PL | CY | 0.8 | 1.0000 | 0.80000 | CR-CO |
| REBAR | LB | 0.012 | 1.0000 | 0.01200 | CR-CO |
| GND-DB | LF | 0.01 | 1.0000 | 0.01000 | CR-DU |
| TAPE | LF | 0.002 | 1.0000 | 0.00200 | CR-BF |
| PAVE-CUT | SY | 0.55 | 1.0000 | 0.55000 | CR-BF |
| MH-SET | EA | 22 | 1.0000 | 22.00000 | CR-MH |
| MH-BASE | CY | 0.5 | 1.0000 | 0.50000 | CR-BF |
| PULL-MV | LF | 0.178 | 0.7119 | 0.12671 | CR-CP |
| PULL-MV-L | LF | 0.214 | 1.0000 | 0.21400 | CR-CP |
| DBC-LAY | LF | 0.179 | 0.7119 | 0.12743 | CR-CP |
| TERM-MV | EA | 3.2 | 1.0000 | 3.20000 | CR-SP |
| SPLICE-MV | EA | 4.8 | 1.0000 | 4.80000 | CR-SP |
| FIREPROOF | LF | 0.08 | 1.0000 | 0.08000 | CR-SP |
| DEWATER | LF | 0.05 | 1.0000 | 0.05000 | CR-DW |
| TBOX | LF | 0.03 | 1.0000 | 0.03000 | CR-EX |
| POLE-SET | EA | 4 | 0.8375 | 3.35000 | CR-OH |
| POLE-HOLE | EA | 0.6 | 0.8375 | 0.50250 | CR-OH |
| XARM | EA | 4 | 0.7119 | 2.84750 | CR-OH2 |
| GUY | EA | 4 | 0.7119 | 2.84750 | CR-OH3 |
| STRING | LF | 0.0232 | 0.7119 | 0.01652 | CR-STR |
| RISER | EA | 16 | 1.0000 | 16.00000 | CR-OH |
| RMC-5 | LF | 0.352 | 0.8375 | 0.29480 | CR-IN |
| EMT-4 | LF | 0.192 | 0.8375 | 0.16080 | CR-IN |
| ELBOW-5 | EA | 1.6 | 1.0000 | 1.60000 | CR-IN |
| PBOX | EA | 6 | 1.0000 | 6.00000 | CR-IN |
| TRAY-24 | LF | 0.32 | 0.8375 | 0.26800 | CR-IN |
| TRAY-COV | LF | 0.06 | 1.0000 | 0.06000 | CR-IN |
| TRAY-BOND | LF | 0.012 | 1.0000 | 0.01200 | CR-IN |
| PULL-IN | LF | 0.214 | 1.0000 | 0.21400 | CR-IN |
| FIRE-SLV | EA | 3.5 | 1.0000 | 3.50000 | CR-IN |
| FIRE-RMC | EA | 1.5 | 1.0000 | 1.50000 | CR-IN |
| SEISMIC | EA | 2.5 | 1.0000 | 2.50000 | CR-IN |
| TERM-IN | EA | 3.2 | 1.0000 | 3.20000 | CR-IS |

## 3. Item studies

### C01 - SS-1 F1 to MB-1 MSG-A (ER-A)

Route leaves the F1 stub-out (280,640) and rises at 20 deg north of the T-201 protection zone (20 ft), then runs due east at y=720 to the ER-A wall, entering perpendicular within the MSG-A entry zone (x=1100, y 700-760) 18 ft clear of the T-207 zone. Mission Drive is crossed by a 50 ft directional bore (3 HDPE SDR 11 6 in conduits, top of conduit 81 in, below W-12 at 56 in per SUE); bores are 6 % of the run and are excluded from the governing condition. The run passes through the B-3 resistivity area (131 C-cm/W -> 150 column): 2 sets of 500 kcmil in a 3-duct bank (2 occupied + 1 spare) give 2 x 331.5 = 663 A >= 640 A (2 x 350 kcmil = 560 A fails; 1000 kcmil exceeds 40 % fill in 5 in and jams in 6 in). Manhole C01-MH1 at (690,720) is 64 ft from P-1 paving and 70 ft from Mission Drive (>= 50 ft), 235 ft from FP-1; both pulls < 600 ft with calculation. SD-30 is crossed above (envelope bottom 46.7 in vs top of pipe 60 in - 12 in).

**Recommendation: CEDB** - total project cost $262,930, 315.23 $/LF over 834.1 ft. Cable 2 set(s) of 3-1/C 500 kcmil Al 15 kV 133 %; governing ampacity 331.5 A per set (bores excluded (<=25%)); design current 640 A.

| Type | Permitted | Route ft | Labor MH | Labor $ | Equipment $ | Material $ | Subcontract $ | Direct cost | Total project cost | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|
| CEDB (rec.) | Y | 834.1 | 588.9 | $50,432 | $10,298 | $110,991 | $14,000 | $185,721 | $262,930 | 315.23 |
| UEDB | N | 834.1 | 555.9 | $47,779 | $10,716 | $124,055 | $14,000 | $196,549 | $278,259 | 333.61 |
| DBC | N | 834.1 | 293.4 | $25,384 | $6,272 | $59,480 | $14,000 | $105,136 | $148,843 | 178.45 |
| HDD | N | 834.1 | 654.8 | $56,660 | $14,888 | $80,753 | $133,579 | $285,880 | $404,727 | 485.23 |
| OH | N | 834.1 | 324.3 | $28,505 | $6,846 | $58,104 | $0 | $93,455 | $132,307 | 158.62 |

Deciding clauses:

* CEDB: PCSFA-IEDS Rev 3 4.2 (concrete-encased ductbank required; UFC 3-550-01 3-11.2.1, UFGS 33 71 02 3.7.9) with crossings per 4.3
* UEDB: PCSFA-IEDS Rev 3 4.2: conduit without concrete encasement not permitted for primary distribution (UFC 3-550-01 3-11.2.1)
* DBC: PCSFA-IEDS Rev 3 4.2: direct-buried cable not permitted; UFC 3-550-01 3-11.3.1 not authorized for base core distribution
* HDD: PCSFA-IEDS Rev 3 4.3 / UFC 3-550-01 3-11.4.1: directional bores only for crossings (max 50 ft beyond pavement edge/channel bank); not as the method of the entire run
* OH: PCSFA-IEDS Rev 3 4.1: overhead not permitted inside the industrial area (ADP 2024) on C-101 (UFC 3-550-01 3-11.1.1 congested industrial areas)

Design of the recommended conveyance:

| Seg | Method | Route (x,y ft) | Cover in | Ducts r x c | Duct in | Spares | Reinf. | Soil | Protection | Dewater | Length ft |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | CE | 280.0,640.0; 500.0,720.0; 595.0,720.0; 690.0,720.0 | 18 | 3x1 | EB20-5 | 1 | N | B | none | N | 424.1 |
| 2 | CE | 690.0,720.0; 697.5,720.0; 750.0,720.0 | 18 | 3x1 | EB20-5 | 1 | N | B | none | N | 60.0 |
| 3 | HDD | 750.0,720.0; 800.0,720.0 | 81 | 3 conduits | HDPE-6 | - | N | - | - | N | 50.0 |
| 4 | CE | 800.0,720.0; 1100.0,720.0 | 18 | 3x1 | EB20-5 | 1 | N | B | none | N | 300.0 |

Structures: C01-MH1 (MH) at 690.0,720.0

Pulling calculations (feed-in 100 lb, pull from the end giving lower tension):

| Pull | From | To | Length ft | Max tension lb | Allowable lb | Max SWBP lb/ft (limit 600) | Jam ratio | Fill % |
|---|---|---|---|---|---|---|---|---|
| C01-P1 | START | C01-MH1 | 424.1 | 1,152 | 6,000 | 40.7 | 3.209 | 29.1 |
| C01-P2 | C01-MH1 | END | 410.0 | 997 | 6,000 | 40.7 | 3.209 | 29.1 |

Labor hours of the recommended take-off by code:

| Code | Qty | Unit | MH | Labor $ | Equip $ | Material $ | Sub $ |
|---|---|---|---|---|---|---|---|
| EX-MACH | 280.87 | BCY | 4.28 | 359 | 126 | 0 | 0 |
| CONC-PL | 52.20 | CY | 41.76 | 3,393 | 0 | 0 | 0 |
| CONC-3000 | 52.20 | CY | 0.00 | 0 | 0 | 13,086 | 0 |
| DUCT-CE | 2,352.28 | LF | 78.80 | 6,589 | 0 | 0 | 0 |
| EB20-5 | 2,352.28 | LF | 0.00 | 0 | 0 | 11,224 | 0 |
| BF-COMP | 192.18 | BCY | 11.53 | 967 | 130 | 0 | 0 |
| SPACER | 477.00 | EA | 0.00 | 0 | 0 | 1,619 | 0 |
| GND-DB | 784.09 | LF | 7.84 | 656 | 0 | 0 | 0 |
| GND-4/0 | 784.09 | LF | 0.00 | 0 | 0 | 7,153 | 0 |
| TAPE | 784.09 | LF | 1.57 | 132 | 18 | 0 | 0 |
| TAPE-DET | 784.09 | LF | 0.00 | 0 | 0 | 252 | 0 |
| SUB-HDD | 50.00 | LF | 0.00 | 0 | 0 | 0 | 14,000 |
| MH-SET | 1.00 | EA | 22.00 | 1,868 | 336 | 0 | 0 |
| MH-PRECAST | 1.00 | EA | 0.00 | 0 | 0 | 18,451 | 0 |
| MH-BASE | 2.80 | CY | 1.40 | 117 | 16 | 0 | 0 |
| ROCK-BASE | 2.80 | CY | 0.00 | 0 | 0 | 209 | 0 |
| TBOX | 20.00 | LF | 0.60 | 50 | 18 | 0 | 0 |
| PULL-MV-L | 1,752.19 | LF | 374.97 | 32,327 | 9,655 | 0 | 0 |
| CBL-500 | 5,256.56 | LF | 0.00 | 0 | 0 | 55,234 | 0 |
| TERM-MV | 12.00 | EA | 38.40 | 3,456 | 0 | 0 | 0 |
| TERM-KIT | 12.00 | EA | 0.00 | 0 | 0 | 3,482 | 0 |
| FIREPROOF | 72.00 | LF | 5.76 | 518 | 0 | 0 | 0 |
| FIRETAPE | 72.00 | LF | 0.00 | 0 | 0 | 281 | 0 |

### C02 - SS-1 F2 to MB-1 MSG-B (ER-B)

Straight run from the F2 stub-out (280,520) to C02-MH1 at (870,455) east of Mission Drive (bore under the road and W-12), 35 ft clear of T-206, then a 45 deg long sweep under telecom T-2 (cover 60 in = T-2 bottom 48 in + 12 in, trench shield), east along y=395 over SD-30 and north into the MSG-B entry zone on the south wall (x=1330) perpendicular to the wall. The B-3 area (150 column) governs: 2 x 500 kcmil = 663 A >= 560 A (2 x 350 kcmil gives 559.7 A and fails). One manhole only: pulls 593.6 ft and 509.9 ft (<= 600 ft with pulling calculation). Separation from C01 (bus A) >= 143 ft.

**Recommendation: CEDB** - total project cost $327,406, 296.72 $/LF over 1103.4 ft. Cable 2 set(s) of 3-1/C 500 kcmil Al 15 kV 133 %; governing ampacity 331.5 A per set (bores excluded (<=25%)); design current 560 A.

| Type | Permitted | Route ft | Labor MH | Labor $ | Equipment $ | Material $ | Subcontract $ | Direct cost | Total project cost | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|
| CEDB (rec.) | Y | 1103.4 | 754.0 | $64,502 | $13,360 | $139,403 | $14,000 | $231,264 | $327,406 | 296.72 |
| UEDB | N | 1103.4 | 709.4 | $60,916 | $13,915 | $156,942 | $14,000 | $245,772 | $347,946 | 315.33 |
| DBC | N | 1103.4 | 368.1 | $31,809 | $8,099 | $63,789 | $14,000 | $117,696 | $166,625 | 151.01 |
| HDD | N | 1103.4 | 560.5 | $48,448 | $13,028 | $94,637 | $127,542 | $283,656 | $401,578 | 363.94 |
| OH | N | 1103.4 | 366.4 | $32,239 | $7,992 | $66,303 | $0 | $106,534 | $150,823 | 136.69 |

Deciding clauses:

* CEDB: PCSFA-IEDS Rev 3 4.2 (concrete-encased ductbank required; UFC 3-550-01 3-11.2.1, UFGS 33 71 02 3.7.9) with crossings per 4.3
* UEDB: PCSFA-IEDS Rev 3 4.2: conduit without concrete encasement not permitted for primary distribution (UFC 3-550-01 3-11.2.1)
* DBC: PCSFA-IEDS Rev 3 4.2: direct-buried cable not permitted; UFC 3-550-01 3-11.3.1 not authorized for base core distribution
* HDD: PCSFA-IEDS Rev 3 4.3 / UFC 3-550-01 3-11.4.1: directional bores only for crossings (max 50 ft beyond pavement edge/channel bank); not as the method of the entire run
* OH: PCSFA-IEDS Rev 3 4.1: overhead not permitted inside the industrial area (ADP 2024) on C-101 (UFC 3-550-01 3-11.1.1 congested industrial areas)

Design of the recommended conveyance:

| Seg | Method | Route (x,y ft) | Cover in | Ducts r x c | Duct in | Spares | Reinf. | Soil | Protection | Dewater | Length ft |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | CE | 280.0,520.0; 483.7,497.6; 750.0,468.2 | 18 | 3x1 | EB20-5 | 1 | N | B | none | N | 472.8 |
| 2 | HDD | 750.0,468.2; 800.0,462.7 | 81 | 3 conduits | HDPE-6 | - | N | - | - | N | 50.3 |
| 3 | CE | 800.0,462.7; 817.9,460.7; 870.0,455.0 | 18 | 3x1 | EB20-5 | 1 | N | B | none | N | 70.4 |
| 4 | CE | 870.0,455.0; 872.1,452.9; 891.5,433.5 | 18 | 3x1 | EB20-5 | 1 | N | B | none | N | 30.4 |
| 5 | CE | 891.5,433.5; 898.6,426.4 | 60 | 3x1 | EB20-5 | 1 | N | B | box | N | 10.0 |
| 6 | CE | 898.6,426.4; 930.0,395.0; 1262.0,395.0; 1330.0,395.0; 1330.0,420.0 | 18 | 3x1 | EB20-5 | 1 | N | B | none | N | 469.4 |

Structures: C02-MH1 (MH) at 870.0,455.0

Pulling calculations (feed-in 100 lb, pull from the end giving lower tension):

| Pull | From | To | Length ft | Max tension lb | Allowable lb | Max SWBP lb/ft (limit 600) | Jam ratio | Fill % |
|---|---|---|---|---|---|---|---|---|
| C02-P1 | START | C02-MH1 | 593.6 | 1,360 | 6,000 | 40.7 | 3.209 | 29.1 |
| C02-P2 | C02-MH1 | END | 509.9 | 2,008 | 6,000 | 44.6 | 3.209 | 29.1 |

Labor hours of the recommended take-off by code:

| Code | Qty | Unit | MH | Labor $ | Equip $ | Material $ | Sub $ |
|---|---|---|---|---|---|---|---|
| EX-MACH | 364.42 | BCY | 5.55 | 466 | 163 | 0 | 0 |
| CONC-PL | 70.10 | CY | 56.08 | 4,557 | 0 | 0 | 0 |
| CONC-3000 | 70.10 | CY | 0.00 | 0 | 0 | 17,576 | 0 |
| DUCT-CE | 3,159.36 | LF | 105.84 | 8,849 | 0 | 0 | 0 |
| EB20-5 | 3,159.36 | LF | 0.00 | 0 | 0 | 15,075 | 0 |
| BF-COMP | 252.78 | BCY | 15.17 | 1,272 | 171 | 0 | 0 |
| SPACER | 639.00 | EA | 0.00 | 0 | 0 | 2,169 | 0 |
| GND-DB | 1,053.12 | LF | 10.53 | 881 | 0 | 0 | 0 |
| GND-4/0 | 1,053.12 | LF | 0.00 | 0 | 0 | 9,607 | 0 |
| TAPE | 1,053.12 | LF | 2.11 | 177 | 24 | 0 | 0 |
| TAPE-DET | 1,053.12 | LF | 0.00 | 0 | 0 | 339 | 0 |
| SUB-HDD | 50.30 | LF | 0.00 | 0 | 0 | 0 | 14,000 |
| TBOX | 29.98 | LF | 0.90 | 75 | 26 | 0 | 0 |
| MH-SET | 1.00 | EA | 22.00 | 1,868 | 336 | 0 | 0 |
| MH-PRECAST | 1.00 | EA | 0.00 | 0 | 0 | 18,451 | 0 |
| MH-BASE | 2.80 | CY | 1.40 | 117 | 16 | 0 | 0 |
| ROCK-BASE | 2.80 | CY | 0.00 | 0 | 0 | 209 | 0 |
| PULL-MV-L | 2,290.85 | LF | 490.24 | 42,265 | 12,624 | 0 | 0 |
| CBL-500 | 6,872.54 | LF | 0.00 | 0 | 0 | 72,214 | 0 |
| TERM-MV | 12.00 | EA | 38.40 | 3,456 | 0 | 0 | 0 |
| TERM-KIT | 12.00 | EA | 0.00 | 0 | 0 | 3,482 | 0 |
| FIREPROOF | 72.00 | LF | 5.76 | 518 | 0 | 0 | 0 |
| FIRETAPE | 72.00 | LF | 0.00 | 0 | 0 | 281 | 0 |

### C03 - SS-1 F3 to CUP-1 SWG-C1 (south entry)

Diagonal run from the F3 stub-out (240,700) across parking lot P-1 (saw-cut, reinforced envelope, 24 in cover, encasement extended 5 ft beyond the paving) to a 45 deg sweep at (445,905), then north into the CUP-1 south entry zone (x=445) perpendicular to the wall. G-4 gas (top 36 in, 4.5 in OD) is crossed below at 53 in cover (trench shield). The deep crossing (72 in column) and the B-2 area (120 column) make 350 kcmil insufficient (386 A < 400 A); one set of 500 kcmil (461.3 A) is used. Single 345 ft pull (2,041 lb < 6,000 lb, SWBP 413 lb/ft < 600 lb/ft); no manhole is required. An HDD under P-1 was also priced and is more expensive.

**Recommendation: CEDB** - total project cost $70,528, 204.48 $/LF over 344.9 ft. Cable 1 set(s) of 3-1/C 500 kcmil Al 15 kV 133 %; governing ampacity 461.3 A per set (bores excluded (<=25%)); design current 400 A.

| Type | Permitted | Route ft | Labor MH | Labor $ | Equipment $ | Material $ | Subcontract $ | Direct cost | Total project cost | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|
| CEDB (rec.) | Y | 344.9 | 205.5 | $17,479 | $2,773 | $29,565 | $0 | $49,818 | $70,528 | 204.48 |
| UEDB | N | 344.9 | 200.6 | $17,082 | $2,822 | $30,895 | $0 | $50,799 | $71,918 | 208.51 |
| DBC | N | 344.9 | 177.1 | $15,085 | $2,440 | $25,326 | $0 | $42,850 | $60,664 | 175.88 |
| HDD | N | 344.9 | 201.4 | $17,511 | $4,198 | $19,844 | $41,892 | $83,445 | $118,135 | 342.51 |
| OH | N | 344.9 | 159.2 | $13,999 | $3,336 | $28,948 | $0 | $46,283 | $65,524 | 189.97 |

Deciding clauses:

* CEDB: PCSFA-IEDS Rev 3 4.2 (concrete-encased ductbank required; UFC 3-550-01 3-11.2.1, UFGS 33 71 02 3.7.9) with crossings per 4.3
* UEDB: PCSFA-IEDS Rev 3 4.2: conduit without concrete encasement not permitted for primary distribution (UFC 3-550-01 3-11.2.1)
* DBC: PCSFA-IEDS Rev 3 4.2: direct-buried cable not permitted; UFC 3-550-01 3-11.3.1 not authorized for base core distribution
* HDD: PCSFA-IEDS Rev 3 4.3 / UFC 3-550-01 3-11.4.1: directional bores only for crossings (max 50 ft beyond pavement edge/channel bank); not as the method of the entire run
* OH: PCSFA-IEDS Rev 3 4.1: overhead not permitted inside the industrial area (ADP 2024) on C-101 (UFC 3-550-01 3-11.1.1 congested industrial areas)

Design of the recommended conveyance:

| Seg | Method | Route (x,y ft) | Cover in | Ducts r x c | Duct in | Spares | Reinf. | Soil | Protection | Dewater | Length ft |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | CE | 240.0,700.0; 295.1,755.1 | 18 | 2x1 | EB20-5 | 1 | N | B | none | N | 78.0 |
| 2 | CE | 295.1,755.1; 344.3,804.3; 345.3,805.3; 445.0,905.0 | 24 | 2x1 | EB20-5 | 1 | Y | B | none | N | 211.9 |
| 3 | CE | 445.0,905.0; 445.0,935.0 | 53 | 2x1 | EB20-5 | 1 | Y | B | box | N | 30.0 |
| 4 | CE | 445.0,935.0; 445.0,960.0 | 18 | 2x1 | EB20-5 | 1 | N | B | none | N | 25.0 |

Pulling calculations (feed-in 100 lb, pull from the end giving lower tension):

| Pull | From | To | Length ft | Max tension lb | Allowable lb | Max SWBP lb/ft (limit 600) | Jam ratio | Fill % |
|---|---|---|---|---|---|---|---|---|
| C03-P1 | START | END | 344.9 | 2,041 | 6,000 | 412.7 | 3.209 | 29.1 |

Labor hours of the recommended take-off by code:

| Code | Qty | Unit | MH | Labor $ | Equip $ | Material $ | Sub $ |
|---|---|---|---|---|---|---|---|
| EX-MACH | 100.04 | BCY | 1.52 | 128 | 45 | 0 | 0 |
| CONC-PL | 16.33 | CY | 13.07 | 1,062 | 0 | 0 | 0 |
| CONC-3000 | 16.33 | CY | 0.00 | 0 | 0 | 4,095 | 0 |
| DUCT-CE | 689.83 | LF | 23.11 | 1,932 | 0 | 0 | 0 |
| EB20-5 | 689.83 | LF | 0.00 | 0 | 0 | 3,291 | 0 |
| BF-COMP | 79.39 | BCY | 4.76 | 399 | 54 | 0 | 0 |
| SPACER | 144.00 | EA | 0.00 | 0 | 0 | 489 | 0 |
| GND-DB | 344.91 | LF | 3.45 | 288 | 0 | 0 | 0 |
| GND-4/0 | 344.91 | LF | 0.00 | 0 | 0 | 3,146 | 0 |
| TAPE | 344.91 | LF | 0.69 | 58 | 8 | 0 | 0 |
| TAPE-DET | 344.91 | LF | 0.00 | 0 | 0 | 111 | 0 |
| REBAR | 778.45 | LB | 9.34 | 759 | 0 | 0 | 0 |
| REBAR-4 | 778.45 | LB | 0.00 | 0 | 0 | 1,056 | 0 |
| PAVE-CUT | 87.19 | SY | 47.96 | 4,021 | 542 | 0 | 0 |
| ASPHALT | 87.19 | SY | 0.00 | 0 | 0 | 3,628 | 0 |
| TBOX | 30.00 | LF | 0.90 | 75 | 26 | 0 | 0 |
| PULL-MV-L | 380.91 | LF | 81.52 | 7,028 | 2,099 | 0 | 0 |
| CBL-500 | 1,142.74 | LF | 0.00 | 0 | 0 | 12,008 | 0 |
| TERM-MV | 6.00 | EA | 19.20 | 1,728 | 0 | 0 | 0 |
| TERM-KIT | 6.00 | EA | 0.00 | 0 | 0 | 1,741 | 0 |

### C04 - CUP-1 CF-2 (east entry) to LS-2 TX-LS2

Leaves the CUP-1 east entry zone (600,1020) perpendicular to the wall through the CUP-1 yard (reinforced, 24 in cover, encasement 5 ft beyond the paving), joins C07 at (690,1085) in a shared 3-duct bank (C04 + C07 + 1 spare) and a shared Mission Drive bore (allocated 1/2 each), splits at (900,1085), passes 55 ft from T-203 and crosses SD-30 above, to C04-MH1 (1145,1050). DC-1 is crossed by a 101.7 ft directional bore (x 1570-1670, 30 ft beyond each bank, 120 in cover, deep-bore surcharge); C04-MH2 at (1690,1150) east of the channel buffer is 70.7 ft from TX-LS2 (<= 200 ft with calculation). Pulls 574 / 554 / 71 ft. Overhead is excluded because the route lies in the industrial area (only the last ~200 ft are outside it).

**Recommendation: CEDB** - total project cost $243,223, 202.82 $/LF over 1199.2 ft. Cable 1 set(s) of 3-1/C 250 kcmil Al 15 kV 133 %; governing ampacity 315.9 A per set (bores excluded (<=25%)); design current 60 A.

| Type | Permitted | Route ft | Labor MH | Labor $ | Equipment $ | Material $ | Subcontract $ | Direct cost | Total project cost | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|
| CEDB (rec.) | Y | 1199.2 | 499.5 | $42,588 | $8,170 | $100,043 | $21,000 | $171,801 | $243,223 | 202.82 |
| UEDB | N | 1168.6 | 476.2 | $40,708 | $8,419 | $104,147 | $28,000 | $181,275 | $256,635 | 219.61 |
| DBC | N | 1168.6 | 266.2 | $22,828 | $5,168 | $34,923 | $28,000 | $90,918 | $128,715 | 110.14 |
| HDD | N | 1168.6 | 337.4 | $29,109 | $7,514 | $65,471 | $105,606 | $207,700 | $294,046 | 251.62 |
| OH | N | 1199.2 | 285.3 | $25,133 | $6,591 | $49,450 | $0 | $81,175 | $114,921 | 95.83 |

Deciding clauses:

* CEDB: PCSFA-IEDS Rev 3 4.2 (concrete-encased ductbank required; UFC 3-550-01 3-11.2.1, UFGS 33 71 02 3.7.9) with crossings per 4.3
* UEDB: PCSFA-IEDS Rev 3 4.2: conduit without concrete encasement not permitted for primary distribution (UFC 3-550-01 3-11.2.1)
* DBC: PCSFA-IEDS Rev 3 4.2: direct-buried cable not permitted; UFC 3-550-01 3-11.3.1 not authorized for base core distribution
* HDD: PCSFA-IEDS Rev 3 4.3 / UFC 3-550-01 3-11.4.1: directional bores only for crossings (max 50 ft beyond pavement edge/channel bank); not as the method of the entire run
* OH: PCSFA-IEDS Rev 3 4.1: overhead not permitted inside the industrial area (ADP 2024) on C-101 (UFC 3-550-01 3-11.1.1 congested industrial areas)

Design of the recommended conveyance:

| Seg | Method | Route (x,y ft) | Cover in | Ducts r x c | Duct in | Spares | Reinf. | Soil | Protection | Dewater | Length ft |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | CE | 600.0,1020.0; 625.0,1020.0; 669.9,1064.9 | 24 | 2x1 | EB20-5 | 1 | Y | C | none | N | 88.4 |
| 2 | CE | 669.9,1064.9; 690.0,1085.0 | 18 | 2x1 | EB20-5 | 1 | N | C | none | N | 28.5 |
| 3 | CE | 690.0,1085.0; 750.0,1085.0 | 18 | 1x3 | EB20-5 | 1 | N | B | none | N | 60.0 |
| 4 | HDD | 750.0,1085.0; 800.0,1085.0 | 81 | 3 conduits | HDPE-5 | - | N | - | - | N | 50.0 |
| 5 | CE | 800.0,1085.0; 900.0,1085.0 | 18 | 1x3 | EB20-5 | 1 | N | B | none | N | 100.0 |
| 6 | CE | 900.0,1085.0; 950.0,1077.9 | 18 | 2x1 | EB20-5 | 1 | N | C | none | N | 50.5 |
| 7 | CE | 950.0,1077.9; 1145.0,1050.0 | 18 | 2x1 | EB20-5 | 1 | N | B | none | N | 197.0 |
| 8 | CE | 1145.0,1050.0; 1360.7,1089.6; 1570.0,1128.0 | 18 | 2x1 | EB20-5 | 1 | N | B | none | N | 432.1 |
| 9 | HDD | 1570.0,1128.0; 1670.0,1146.3 | 120 | 2 conduits | HDPE-5 | - | N | - | - | N | 101.7 |
| 10 | CE | 1670.0,1146.3; 1690.0,1150.0 | 18 | 2x1 | EB20-5 | 1 | N | B | none | N | 20.3 |
| 11 | CE | 1690.0,1150.0; 1760.0,1160.0 | 18 | 2x1 | EB20-5 | 1 | N | B | none | N | 70.7 |

Structures: C04-MH1 (MH) at 1145.0,1050.0; C04-MH2 (MH) at 1690.0,1150.0

Pulling calculations (feed-in 100 lb, pull from the end giving lower tension):

| Pull | From | To | Length ft | Max tension lb | Allowable lb | Max SWBP lb/ft (limit 600) | Jam ratio | Fill % |
|---|---|---|---|---|---|---|---|---|
| C04-P1 | START | C04-MH1 | 574.4 | 1,145 | 3,000 | 32.1 | 3.274 | 28.0 |
| C04-P2 | C04-MH1 | C04-MH2 | 554.1 | 738 | 3,000 | 0.0 | 3.274 | 28.0 |
| C04-P3 | C04-MH2 | END | 70.7 | 273 | 3,000 | 32.1 | 3.786 | 20.9 |

Labor hours of the recommended take-off by code:

| Code | Qty | Unit | MH | Labor $ | Equip $ | Material $ | Sub $ |
|---|---|---|---|---|---|---|---|
| EX-MACH | 341.19 | BCY | 5.20 | 436 | 153 | 0 | 0 |
| CONC-PL | 47.35 | CY | 37.88 | 3,078 | 0 | 0 | 0 |
| CONC-3000 | 47.35 | CY | 0.00 | 0 | 0 | 11,872 | 0 |
| DUCT-CE | 2,015.10 | LF | 67.51 | 5,644 | 0 | 0 | 0 |
| EB20-5 | 2,015.10 | LF | 0.00 | 0 | 0 | 9,615 | 0 |
| REBAR | 284.61 | LB | 3.42 | 278 | 0 | 0 | 0 |
| REBAR-4 | 284.61 | LB | 0.00 | 0 | 0 | 386 | 0 |
| BF-COMP | 237.65 | BCY | 14.26 | 1,196 | 161 | 0 | 0 |
| SPACER | 415.00 | EA | 0.00 | 0 | 0 | 1,409 | 0 |
| GND-DB | 967.55 | LF | 9.68 | 809 | 0 | 0 | 0 |
| GND-4/0 | 967.55 | LF | 0.00 | 0 | 0 | 8,826 | 0 |
| TAPE | 967.55 | LF | 1.94 | 162 | 22 | 0 | 0 |
| TAPE-DET | 967.55 | LF | 0.00 | 0 | 0 | 311 | 0 |
| PAVE-CUT | 35.92 | SY | 19.76 | 1,657 | 223 | 0 | 0 |
| ASPHALT | 35.92 | SY | 0.00 | 0 | 0 | 1,495 | 0 |
| SUB-HDD | 126.67 | LF | 0.00 | 0 | 0 | 0 | 21,000 |
| MH-SET | 2.00 | EA | 44.00 | 3,736 | 672 | 0 | 0 |
| MH-PRECAST | 2.00 | EA | 0.00 | 0 | 0 | 36,902 | 0 |
| MH-BASE | 5.59 | CY | 2.80 | 235 | 32 | 0 | 0 |
| ROCK-BASE | 5.59 | CY | 0.00 | 0 | 0 | 418 | 0 |
| TBOX | 40.00 | LF | 1.20 | 101 | 35 | 0 | 0 |
| PULL-MV-L | 1,247.22 | LF | 266.91 | 23,010 | 6,873 | 0 | 0 |
| CBL-250 | 3,741.66 | LF | 0.00 | 0 | 0 | 26,787 | 0 |
| TERM-MV | 6.00 | EA | 19.20 | 1,728 | 0 | 0 | 0 |
| TERM-KIT | 6.00 | EA | 0.00 | 0 | 0 | 1,741 | 0 |
| FIREPROOF | 72.00 | LF | 5.76 | 518 | 0 | 0 | 0 |
| FIRETAPE | 72.00 | LF | 0.00 | 0 | 0 | 281 | 0 |

### C05 - MB-1 MSG-A feeder A-3 to USS-A1 (inside MB-1)

Fully enclosed 24 in tray (6 in tray + 12 in access = 18 in) from MSG-A through ER-A (48 in), COR-1 (20 in) and COR-1E (20 in) to MR-1 (44 in) at y=705, 15 ft from the IT-1 SCIF walls; COR-1D (14 in, supply-air main) is crossed in two 5 in RMC (6 in required) so tray remains the predominant method. Tray stops 10 in from the two 2-hour walls (ER-A/COR-1, COR-1E/MR-1) with one 4 in RGS sleeve per set (3 x 250 kcmil = 35.8 % fill); the two 1-hour walls are firestopped per set. The COR-1D conduit governs ampacity (conduit in air, 40 C): one 500 kcmil (245 A) would jam in 5 in RGS (D/d 3.08) and 350 kcmil gives 195 A < 200 A, so 2 sets of 250 kcmil (2 x 160 A = 320 A; 16.6 kA >= 15.8 kA at 0.5 s). Pull box C05-PB1 in the COR-1D conduit section keeps bends between pull points at 180 deg (<= 270 deg). RMC (via MR-2) is permitted but costs more; EMT and ladder tray are not permitted.

**Recommendation: TRAY-EN** - total project cost $153,570, 383.92 $/LF over 400.0 ft. Cable 2 set(s) of 3-1/C 250 kcmil Al 15 kV 133 %; governing ampacity 160.0 A per set (air 40 C); design current 200 A.

| Type | Permitted | Route ft | Labor MH | Labor $ | Equipment $ | Material $ | Subcontract $ | Direct cost | Total project cost | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|
| RMC | Y | 400.0 | 527.3 | $53,845 | $2,885 | $89,038 | $0 | $145,768 | $206,367 | 515.92 |
| EMT | N | 400.0 | 416.4 | $42,531 | $2,230 | $45,056 | $0 | $89,817 | $127,156 | 317.89 |
| TRAY-EN (rec.) | Y | 400.0 | 448.3 | $45,783 | $2,418 | $60,273 | $0 | $108,474 | $153,570 | 383.92 |
| TRAY-LD | N | 400.0 | 426.7 | $43,581 | $2,291 | $51,374 | $0 | $97,245 | $137,672 | 344.18 |

Deciding clauses:

* RMC: UFGS 26 20 00 3.1.6.7 (conduit > 600 V: RMC/IMC) and UFC 3-520-01 Table 3-1; PCSFA-IEDS Rev 3 5.1 (6 in space available on route via MR-2)
* EMT: UFGS 26 20 00 3.1.6.7: conduit for circuits rated > 600 V shall be rigid metal conduit or IMC only (EMT also excluded in equipment rooms, 3.1.6.2c)
* TRAY-EN: UFC 3-520-01 Table 3-1 (MV cable in fully enclosed cable tray) and PCSFA-IEDS Rev 3 5.1: tray route via COR-1/COR-1E (20 in >= 18 in) with RMC through COR-1D (14 in); tray predominant (RFP 1.4)
* TRAY-LD: UFC 3-520-01 Table 3-1: interior MV cable must be in raceway or a fully enclosed cable tray; ladder tray not permitted

Design of the recommended conveyance:

| Seg | Method | Route (x,y ft) | Cover in | Ducts r x c | Duct in | Spares | Reinf. | Soil | Protection | Dewater | Length ft |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | TRAY-EN | 1130.0,730.0; 1130.0,705.0; 1280.0,705.0 | - | - | - | - | - | - | - | - | 175.0 |
| 2 | RMC | 1280.0,705.0; 1300.0,705.0; 1320.0,705.0 | - | - | - | - | - | - | - | - | 40.0 |
| 3 | TRAY-EN | 1320.0,705.0; 1440.0,705.0; 1440.0,640.0 | - | - | - | - | - | - | - | - | 185.0 |

Structures: C05-PB1 (PULLBOX) at 1300.0,705.0

Pulling calculations (feed-in 100 lb, pull from the end giving lower tension):

| Pull | From | To | Length ft | Max tension lb | Allowable lb | Max SWBP lb/ft (limit 600) | Jam ratio | Fill % |
|---|---|---|---|---|---|---|---|---|
| C05-P1 | START | C05-PB1 | 202.0 | 398 | 3,000 | 153.4 | 3.631 | 22.8 |
| C05-P2 | C05-PB1 | END | 212.0 | 407 | 3,000 | 164.2 | 3.631 | 22.8 |

Labor hours of the recommended take-off by code:

| Code | Qty | Unit | MH | Labor $ | Equip $ | Material $ | Sub $ |
|---|---|---|---|---|---|---|---|
| TRAY-24 | 360.00 | LF | 96.48 | 9,839 | 569 | 0 | 0 |
| TRAY-24-SB | 360.00 | LF | 0.00 | 0 | 0 | 15,729 | 0 |
| TRAY-COV | 360.00 | LF | 21.60 | 2,203 | 127 | 0 | 0 |
| TRAY-COV-24 | 360.00 | LF | 0.00 | 0 | 0 | 5,174 | 0 |
| TRAY-BOND | 360.00 | LF | 4.32 | 441 | 25 | 0 | 0 |
| BOND-2 | 360.00 | LF | 0.00 | 0 | 0 | 873 | 0 |
| RMC-5 | 108.00 | LF | 31.84 | 3,247 | 188 | 0 | 0 |
| RGS-5 | 108.00 | LF | 0.00 | 0 | 0 | 7,575 | 0 |
| ELBOW-5 | 4.00 | EA | 6.40 | 653 | 38 | 0 | 0 |
| ELBOW-RGS5 | 4.00 | EA | 0.00 | 0 | 0 | 2,803 | 0 |
| FIRE-SLV | 4.00 | EA | 14.00 | 1,428 | 83 | 0 | 0 |
| FIRE-SLV-4 | 4.00 | EA | 0.00 | 0 | 0 | 1,358 | 0 |
| FIRE-RMC | 4.00 | EA | 6.00 | 612 | 35 | 0 | 0 |
| FIRESTOP-RMC5 | 4.00 | EA | 0.00 | 0 | 0 | 635 | 0 |
| PBOX | 1.00 | EA | 6.00 | 612 | 35 | 0 | 0 |
| PBOX-36 | 1.00 | EA | 0.00 | 0 | 0 | 1,292 | 0 |
| SEISMIC | 15.00 | EA | 37.50 | 3,824 | 221 | 0 | 0 |
| SEISMIC-BR | 15.00 | EA | 0.00 | 0 | 0 | 2,710 | 0 |
| PULL-IN | 868.00 | LF | 185.75 | 18,943 | 1,096 | 0 | 0 |
| CBL-250 | 2,604.00 | LF | 0.00 | 0 | 0 | 18,642 | 0 |
| TERM-IN | 12.00 | EA | 38.40 | 3,984 | 0 | 0 | 0 |
| TERM-KIT | 12.00 | EA | 0.00 | 0 | 0 | 3,482 | 0 |

### C06 - SS-1 F4 to gate house TX-GH1

Concrete-encased risers from the F4 stub-out (south, per RFI-01) around the T-208 zone (14 ft, survey tree not on C-101) to riser pole C06-RP1 at (200,295) just outside the industrial area (193 ft pull <= 200 ft), a straight tangent pole line of six 267.5 ft spans (1/0 ACSR Raven, 300 ft maximum) along Perimeter Road to riser pole C06-RP2 at (1800,170), and a 40 ft riser to TX-GH1. Both poles of the Mission Drive crossing span are 50 ft; all poles are outside the channel buffer, >= 6 ft from road edges and >= 25 ft from buildings. Cable 250 kcmil (short-circuit 16.6 kA >= 16.5 kA); governing rating 196 A (ACSR, 40 C) >= 40 A. Underground CEDB is permitted but costs about 3.6 times more.

**Recommendation: OH** - total project cost $110,138, 59.92 $/LF over 1838.2 ft. Cable 1 set(s) of 3-1/C 250 kcmil Al 15 kV 133 %; governing ampacity 196.0 A per set (bores excluded (<=25%)); design current 40 A; overhead conductor ACSR 1/0 (40 C rating).

| Type | Permitted | Route ft | Labor MH | Labor $ | Equipment $ | Material $ | Subcontract $ | Direct cost | Total project cost | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|
| CEDB | Y | 1958.3 | 821.7 | $69,980 | $13,284 | $181,804 | $14,000 | $279,068 | $395,083 | 201.75 |
| UEDB | N | 1958.3 | 758.2 | $64,852 | $13,880 | $188,559 | $14,000 | $281,291 | $398,231 | 203.36 |
| DBC | N | 1958.3 | 324.4 | $27,916 | $7,158 | $47,229 | $14,000 | $96,304 | $136,339 | 69.62 |
| HDD | N | 1958.3 | 566.9 | $48,835 | $12,741 | $120,290 | $174,578 | $356,443 | $504,625 | 257.69 |
| OH (rec.) | Y | 1838.2 | 296.1 | $25,874 | $6,368 | $45,554 | $0 | $77,797 | $110,138 | 59.92 |

Deciding clauses:

* CEDB: PCSFA-IEDS Rev 3 4.2 (concrete-encased ductbank required; UFC 3-550-01 3-11.2.1, UFGS 33 71 02 3.7.9) with crossings per 4.3
* UEDB: PCSFA-IEDS Rev 3 4.2: conduit without concrete encasement not permitted for primary distribution (UFC 3-550-01 3-11.2.1)
* DBC: PCSFA-IEDS Rev 3 4.2: direct-buried cable not permitted; UFC 3-550-01 3-11.3.1 not authorized for base core distribution
* HDD: PCSFA-IEDS Rev 3 4.3 / UFC 3-550-01 3-11.4.1: directional bores only for crossings (max 50 ft beyond pavement edge/channel bank); not as the method of the entire run
* OH: PCSFA-IEDS Rev 3 4.1: overhead permitted outside the industrial area with underground risers; spans/poles per 4.9

Design of the recommended conveyance:

| Seg | Method | Route (x,y ft) | Cover in | Ducts r x c | Duct in | Spares | Reinf. | Soil | Protection | Dewater | Length ft |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | CE | 180.0,480.0; 180.0,465.0; 200.0,445.0; 200.0,420.0; 200.0,295.0 | 18 | 1x2 | EB20-5 | 1 | N | B | none | N | 193.3 |
| 2 | OH | 200.0,295.0; 1800.0,170.0 | - | - | - | - | - | - | - | - | 1604.9 |
| 3 | CE | 1800.0,170.0; 1800.0,130.0 | 18 | 1x2 | EB20-5 | 1 | N | B | none | N | 40.0 |

Structures: C06-RP1 (RISER_POLE, 45 ft, guys 1, dead-end Y) at 200.0,295.0; C06-P1 (POLE, 45 ft, guys 0, dead-end N) at 466.7,274.2; C06-P2 (POLE, 50 ft, guys 0, dead-end N) at 733.3,253.3; C06-P3 (POLE, 50 ft, guys 0, dead-end N) at 1000.0,232.5; C06-P4 (POLE, 45 ft, guys 0, dead-end N) at 1266.7,211.7; C06-P5 (POLE, 45 ft, guys 0, dead-end N) at 1533.3,190.8; C06-RP2 (RISER_POLE, 45 ft, guys 1, dead-end Y) at 1800.0,170.0

Pulling calculations (feed-in 100 lb, pull from the end giving lower tension):

| Pull | From | To | Length ft | Max tension lb | Allowable lb | Max SWBP lb/ft (limit 600) | Jam ratio | Fill % |
|---|---|---|---|---|---|---|---|---|
| C06-P1 | START | C06-RP1 | 193.3 | 1,175 | 3,000 | 197.8 | 3.786 | 20.9 |
| C06-P2 | C06-RP2 | END | 40.0 | 452 | 3,000 | 76.1 | 3.786 | 20.9 |

Labor hours of the recommended take-off by code:

| Code | Qty | Unit | MH | Labor $ | Equip $ | Material $ | Sub $ |
|---|---|---|---|---|---|---|---|
| EX-MACH | 62.77 | BCY | 0.96 | 80 | 28 | 0 | 0 |
| CONC-PL | 11.05 | CY | 8.84 | 718 | 0 | 0 | 0 |
| CONC-3000 | 11.05 | CY | 0.00 | 0 | 0 | 2,769 | 0 |
| DUCT-CE | 466.57 | LF | 15.63 | 1,307 | 0 | 0 | 0 |
| EB20-5 | 466.57 | LF | 0.00 | 0 | 0 | 2,226 | 0 |
| BF-COMP | 48.81 | BCY | 2.93 | 246 | 33 | 0 | 0 |
| SPACER | 96.00 | EA | 0.00 | 0 | 0 | 326 | 0 |
| GND-DB | 233.28 | LF | 2.33 | 195 | 0 | 0 | 0 |
| GND-4/0 | 233.28 | LF | 0.00 | 0 | 0 | 2,128 | 0 |
| TAPE | 233.28 | LF | 0.47 | 39 | 5 | 0 | 0 |
| TAPE-DET | 233.28 | LF | 0.00 | 0 | 0 | 75 | 0 |
| PULL-MV-L | 349.28 | LF | 74.75 | 6,444 | 1,925 | 0 | 0 |
| CBL-250 | 1,047.85 | LF | 0.00 | 0 | 0 | 7,502 | 0 |
| TERM-MV | 6.00 | EA | 19.20 | 1,728 | 0 | 0 | 0 |
| TERM-KIT | 6.00 | EA | 0.00 | 0 | 0 | 1,741 | 0 |
| POLE-SET | 7.00 | EA | 23.45 | 2,111 | 563 | 0 | 0 |
| POLE-45 | 5.00 | EA | 0.00 | 0 | 0 | 8,103 | 0 |
| POLE-HOLE | 7.00 | EA | 3.52 | 317 | 84 | 0 | 0 |
| XARM | 9.00 | EA | 25.63 | 2,307 | 1,230 | 0 | 0 |
| XARM-ASSY | 9.00 | EA | 0.00 | 0 | 0 | 3,794 | 0 |
| GUY | 2.00 | EA | 5.70 | 549 | 182 | 0 | 0 |
| GUY-ASSY | 2.00 | EA | 0.00 | 0 | 0 | 920 | 0 |
| RISER | 2.00 | EA | 32.00 | 2,880 | 768 | 0 | 0 |
| RISER-ASSY | 2.00 | EA | 0.00 | 0 | 0 | 8,650 | 0 |
| POLE-50 | 2.00 | EA | 0.00 | 0 | 0 | 3,854 | 0 |
| STRING | 4,886.85 | LF | 80.71 | 6,955 | 1,550 | 0 | 0 |
| ACSR-1/0 | 4,886.85 | LF | 0.00 | 0 | 0 | 3,465 | 0 |

### C07 - CUP-1 CF-1 (north entry) to W-3 TX-W3

Leaves the CUP-1 north entry zone (470,1060) perpendicular to the wall, turns east at y=1085 (25 ft sweep) between the CUP-1 yard and RR-SPUR-2, shares the C04 bank and Mission Drive bore from (690,1085) to (900,1085), passes 28 ft east of the bumper post (no rail crossing, so no jack-and-bore or jack-and-sleeve is needed) and reaches C07-MH1 at (1030,1085), 95 ft from TX-W3. Pulls 585 ft and 95 ft. In the B-7 area (sand from 3 ft, groundwater 4.0 ft) the trench is 3.4 ft deep: no dewatering, no protective system.

**Recommendation: CEDB** - total project cost $127,493, 187.49 $/LF over 680.0 ft. Cable 1 set(s) of 3-1/C 250 kcmil Al 15 kV 133 %; governing ampacity 315.9 A per set (bores excluded (<=25%)); design current 120 A.

| Type | Permitted | Route ft | Labor MH | Labor $ | Equipment $ | Material $ | Subcontract $ | Direct cost | Total project cost | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|
| CEDB (rec.) | Y | 680.0 | 279.6 | $23,902 | $4,535 | $54,619 | $7,000 | $90,055 | $127,493 | 187.49 |
| UEDB | N | 680.0 | 265.8 | $22,804 | $4,759 | $58,595 | $14,000 | $100,158 | $141,797 | 208.52 |
| DBC | N | 680.0 | 132.3 | $11,437 | $2,681 | $17,996 | $14,000 | $46,113 | $65,283 | 96.00 |
| HDD | N | 680.0 | 202.6 | $17,516 | $4,383 | $36,048 | $62,456 | $120,403 | $170,458 | 250.67 |
| OH | N | 680.0 | 212.7 | $18,807 | $5,022 | $38,561 | $0 | $62,390 | $88,327 | 129.89 |

Deciding clauses:

* CEDB: PCSFA-IEDS Rev 3 4.2 (concrete-encased ductbank required; UFC 3-550-01 3-11.2.1, UFGS 33 71 02 3.7.9) with crossings per 4.3
* UEDB: PCSFA-IEDS Rev 3 4.2: conduit without concrete encasement not permitted for primary distribution (UFC 3-550-01 3-11.2.1)
* DBC: PCSFA-IEDS Rev 3 4.2: direct-buried cable not permitted; UFC 3-550-01 3-11.3.1 not authorized for base core distribution
* HDD: PCSFA-IEDS Rev 3 4.3 / UFC 3-550-01 3-11.4.1: directional bores only for crossings (max 50 ft beyond pavement edge/channel bank); not as the method of the entire run
* OH: PCSFA-IEDS Rev 3 4.1: overhead not permitted inside the industrial area (ADP 2024) or the W-3 dock crane operating area

Design of the recommended conveyance:

| Seg | Method | Route (x,y ft) | Cover in | Ducts r x c | Duct in | Spares | Reinf. | Soil | Protection | Dewater | Length ft |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | CE | 470.0,1060.0; 470.0,1085.0; 690.0,1085.0 | 18 | 2x1 | EB20-5 | 1 | N | C | none | N | 245.0 |
| 2 | CE | 690.0,1085.0; 750.0,1085.0 | 18 | 1x3 | EB20-5 | 1 | N | B | none | N | 60.0 |
| 3 | HDD | 750.0,1085.0; 800.0,1085.0 | 81 | 3 conduits | HDPE-5 | - | N | - | - | N | 50.0 |
| 4 | CE | 800.0,1085.0; 900.0,1085.0 | 18 | 1x3 | EB20-5 | 1 | N | B | none | N | 100.0 |
| 5 | CE | 900.0,1085.0; 951.0,1085.0 | 18 | 2x1 | EB20-5 | 1 | N | C | none | N | 51.0 |
| 6 | CE | 951.0,1085.0; 1030.0,1085.0 | 18 | 2x1 | EB20-5 | 1 | N | B | none | N | 79.0 |
| 7 | CE | 1030.0,1085.0; 1030.0,1180.0 | 18 | 2x1 | EB20-5 | 1 | N | B | none | N | 95.0 |

Structures: C07-MH1 (MH) at 1030.0,1085.0

Pulling calculations (feed-in 100 lb, pull from the end giving lower tension):

| Pull | From | To | Length ft | Max tension lb | Allowable lb | Max SWBP lb/ft (limit 600) | Jam ratio | Fill % |
|---|---|---|---|---|---|---|---|---|
| C07-P1 | START | C07-MH1 | 585.0 | 1,068 | 3,000 | 32.1 | 3.274 | 28.0 |
| C07-P2 | C07-MH1 | END | 95.0 | 301 | 3,000 | 32.1 | 3.786 | 20.9 |

Labor hours of the recommended take-off by code:

| Code | Qty | Unit | MH | Labor $ | Equip $ | Material $ | Sub $ |
|---|---|---|---|---|---|---|---|
| EX-MACH | 189.16 | BCY | 2.88 | 242 | 85 | 0 | 0 |
| CONC-PL | 27.58 | CY | 22.06 | 1,793 | 0 | 0 | 0 |
| CONC-3000 | 27.58 | CY | 0.00 | 0 | 0 | 6,915 | 0 |
| DUCT-CE | 1,180.00 | LF | 39.53 | 3,305 | 0 | 0 | 0 |
| EB20-5 | 1,180.00 | LF | 0.00 | 0 | 0 | 5,630 | 0 |
| BF-COMP | 132.40 | BCY | 7.94 | 666 | 90 | 0 | 0 |
| SPACER | 245.00 | EA | 0.00 | 0 | 0 | 832 | 0 |
| GND-DB | 550.00 | LF | 5.50 | 460 | 0 | 0 | 0 |
| GND-4/0 | 550.00 | LF | 0.00 | 0 | 0 | 5,017 | 0 |
| TAPE | 550.00 | LF | 1.10 | 92 | 12 | 0 | 0 |
| TAPE-DET | 550.00 | LF | 0.00 | 0 | 0 | 177 | 0 |
| SUB-HDD | 25.00 | LF | 0.00 | 0 | 0 | 0 | 7,000 |
| MH-SET | 1.00 | EA | 22.00 | 1,868 | 336 | 0 | 0 |
| MH-PRECAST | 1.00 | EA | 0.00 | 0 | 0 | 18,451 | 0 |
| MH-BASE | 2.80 | CY | 1.40 | 117 | 16 | 0 | 0 |
| ROCK-BASE | 2.80 | CY | 0.00 | 0 | 0 | 209 | 0 |
| TBOX | 20.00 | LF | 0.60 | 50 | 18 | 0 | 0 |
| PULL-MV-L | 722.00 | LF | 154.51 | 13,320 | 3,979 | 0 | 0 |
| CBL-250 | 2,166.00 | LF | 0.00 | 0 | 0 | 15,507 | 0 |
| TERM-MV | 6.00 | EA | 19.20 | 1,728 | 0 | 0 | 0 |
| TERM-KIT | 6.00 | EA | 0.00 | 0 | 0 | 1,741 | 0 |
| FIREPROOF | 36.00 | LF | 2.88 | 259 | 0 | 0 | 0 |
| FIRETAPE | 36.00 | LF | 0.00 | 0 | 0 | 141 | 0 |

## 4. Errors and inconsistencies found in Government-furnished documents

| ID | Document | Location | Defect | Correction used |
|---|---|---|---|---|
| F01 | E-001 One-Line Diagram Rev B | Feeder F1 breaker, 51P pickup | One-line shows F1 51P pickup 560 A (Rev C value); current Protective Device Settings Schedule Rev D (2026-06-30) sets F1 phase pickup 640 A (increased for MB-1 Phase 2 load) | Used 640 A as C01 design current (IEDS 1.3(4)) |
| F02 | C-101 Site Utility Plan Rev 4 | W-12 water main labels | Record depth "top of pipe approx 72 in"; SUE-24-0117 test holes TH-1 and TH-2 measured 56 in (16 in shallower) | Used 56 in; bores under Mission Drive keep top of conduit at 81 in (56 + 12.75 OD + 12 in) (IEDS 1.3(5), 4.13) |
| F03 | C-101 Site Utility Plan Rev 4 | Trees layer | Retained tree T-208 (14 in jacaranda at x=170, y=395) in arborist survey TS-24-0117 is not shown on C-101 | Protected T-208 with a 14 ft TPZ; C06 risers routed at x=200 (IEDS 1.3(7), 4.14) |
| F04 | C-101 Site Utility Plan Rev 4 | Trees layer (protection circles) | Protection circles drawn at 0.8 ft per inch DBH (e.g. T-201 r=16 ft, T-209 r=17.6 ft) whereas IEDS 4.14 requires 1 ft per inch (T-201 20 ft, T-209 22 ft) | Used 1 ft per inch of the survey DBH |
| F05 | GEO-24-0117 Geotechnical Report | Table 2 (OSHA soil type), borings B-7 and B-10 | Table 2 lists Type B for B-7 and B-10, but the logs show granular SP (3-9 ft) with groundwater at 4.0 ft at B-7 and granular SM (2-12 ft) with groundwater at 3.0 ft at B-10 -> Type C where an excavation reaches those layers or groundwater | Classified per the logs: Type C (slope 1.5:1 or shield) for excavations reaching the sand / groundwater (IEDS 1.3(6), 4.12) |
| F06 | Attachment J-3 Wage Determination CA20260022 Mod 2 | Solicitation attachment | Attachment J-3 is Mod 2 (01/30/2026); Mod 5 was published 08/06/2026, more than 10 days before the 2026-10-08 bid opening, and is therefore effective. Rates differ for ELEC0011-004 (Mod 2: $65.00 + 3%+$35.62; Mod 5: $60.80 + $31.59) | Used CA20260022 Mod 5 (29 CFR 1.6(c)(2)(ii)(A)); ELEC1245-001, LABO0300-003 and ENGI0012-024 rates are unchanged |
| F07 | Government Estimate Template PCSFA FY26 | Summary lines 2-3 | Template applies Area Cost Factor 1.16 (LOS ANGELES AFB) to the bottom-up direct cost; UFS 3-701-01 4-1.1 prohibits ACFs on detailed take-offs and RFP 3.1 prices with local wages/quotes | ACF not applied (1.00) |
| F08 | Government Estimate Template PCSFA FY26 | Summary lines 4-12 | Template omits the escalation basis (factor ratio) and applies JOOH/HOOH to the location-adjusted cost; SIOH base not stated | Roll-up per RFP 3.6 and UFC 3-740-05 13-3.2 (SIOH on contract cost + contingency) |
| F09 | TD-15AL-133 Rev 3 Cable Data Sheet | 4.2 Maximum sidewall bearing pressure | Catalogue SWBP 1,000 lb/ft; approved submittal SUB-33 71 02-07 (manufacturer letter 2026-08-14) limits SWBP to 600 lb/ft for the copper-tape-shielded construction | Used 600 lb/ft (IEDS 1.3(3), 4.11) |
| F10 | Transmittal T-0117-09 | Document list dates | Transmittal lists GEO-24-0117 dated 2026-03-27 and SUE-24-0117 dated 2026-04-18; the furnished reports are dated 2025-05-16 and 2025-03-28 | Used the furnished reports (only editions provided) |
| F11 | TD-15AL-133 Ampacity Tables | Sheet Earth_Ambient_Correction | Sheet note limits the 25 C correction to ductbank values; IEDS 4.6 applies the earth ambient correction to every underground table (ductbank, single conduit in earth, direct burial) | Applied the 25 C factors to all underground tables |
| F12 | UFC 3-550-01 (2016, Change 3) Appendix B | B-1 conduit type | Appendix B calls for HDPE minimum Schedule 80 while IEDS 4.7 and the HDD quote specify HDPE SDR 11 | Used HDPE SDR 11 per IEDS 4.7 (project-specific; quote basis); fill limited to 30 % |
| F13 | RFP FA4610-26-R-0031 Section 01 11 00, Amendment 0002 (2026-08-28) | 1.1 Schedule | Midpoint of construction stated 2027-08-18; 15 months from 2027-01-04 ends 2028-04-04, whose midpoint is 2027-08-20 | Used the stated 2027-08-18 (effect on escalation < 0.01 %) |
| F14 | UFS 3-701-01 Data Tables (Table 4-2) | FY2030 escalation factor cell (row 29, column G) | Formula =G27*(1+E29) compounds from the FY2028 factor instead of the FY2029 factor (G28), understating the FY2030 factor | Not used by this study (study date and midpoint fall in FY2026-FY2027); factors 2025-2028 recomputed as cumulative 2.1 %/2.1 %/2.1 %/2.0 % |

## 5. Requirements register

| ID | Document | Clause | Requirement | Value | Applies to |
|---|---|---|---|---|---|
| R01 | RFP FA4610-26-R-0031 Section 01 11 00, Amendment 0002 (2026-08-28) | 1.2 / 1.3 | Items C01-C07 and terminals: SS-1 stub-outs, MB-1 and CUP-1 entry zones perpendicular to the wall (C03 CUP1-S, C04 CUP1-E, C07 CUP1-N), pads served at the pad, C05 between MSG-A and USS-A1 on E-101 | Terminal points per C-101 / E-101 | All |
| R02 | RFP FA4610-26-R-0031 Section 01 11 00, Amendment 0002 (2026-08-28) | 1.4 | Types evaluated: CEDB, UEDB, DBC, HDD, OH (site); RMC, EMT, TRAY-EN, TRAY-LD (C05). A type is permitted when a route exists on which every segment complies and the type is the predominant (longest) method; every type priced | All types priced | All |
| R03 | RFP FA4610-26-R-0031 Section 01 11 00, Amendment 0002 (2026-08-28) | 1.5 | Recommended conveyance = permitted type with the lowest total project cost, designed to the 10 % level | Lowest TPC among admissible | All |
| R04 | RFP FA4610-26-R-0031 Section 01 11 00, Amendment 0002 (2026-08-28) | 2.1 / 2.2 | Wage determination Attachment J-3 and its modifications per 29 CFR 1.6; classifications per the labor classification plan; no military-base premium | CA20260022 Mod 5 | All |
| R05 | 29 CFR 1.6 | (c)(2)(ii)(A) | Sealed bidding: a revised wage determination issued at least 10 calendar days before bid opening is effective | Mod 5 published 2026-08-06; bid opening 2026-10-08 -> Mod 5 effective | All |
| R06 | RFP FA4610-26-R-0031 Section 01 11 00, Amendment 0002 (2026-08-28) | 3.2 | Labor hours = quantity x unit (database conversions); cost = hours x average loaded crew rate; loaded rate = base x (1+burden) + fringe; burden = FICA+FUTA+SUI+WC of class code on base wages | FICA 7.65 + FUTA 0.6 + SUI 3.4 + WC (7538: 8.74; 5190: 4.12; 6218: 7.35) % | All |
| R07 | PCEC Labor Unit Database 2026.1 | Notes 1-4, 7 | P-405 units x 67/80; mechanical puller x 0.85 on PULL-MV and DBC-LAY; bucket truck x 0.85 on XARM, GUY, STRING; >4/0 ACSR stringing 0.0328 MH/ft; equipment hours = MH / crew size x units | 0.8375 / 0.85 / 0.85 | All |
| R08 | RFP FA4610-26-R-0031 Section 01 11 00, Amendment 0002 (2026-08-28) | 3.3 | Equipment: EP 1110-1-8 Region VII total hourly rates with FUEL and FOG adjusted per EP 1110-1-8 3.9/3.10 to jobsite fuel prices; rentals at RQ-26-0419 | Diesel off-road $4.38 vs $2.26 (x1.9381); gasoline $5.12 vs $2.49 (x2.0562) | All |
| R09 | EP 1110-1-8 (2021) | 3.9, 3.10 | Fuel and FOG elements multiplied by the ratio of jobsite fuel price to the Area Factors price when the difference exceeds 10 % | Ratios applied | All |
| R10 | RFP FA4610-26-R-0031 Section 01 11 00, Amendment 0002 (2026-08-28) | 3.4 | Material = quoted price x (1+waste) x PPI adjustment (indexed items) x 1.095 sales tax | WPU102603 Aug-2026 494.096 / Jul-2026 482.612 = 1.02380 | All |
| R11 | RFP FA4610-26-R-0031 Section 01 11 00, Amendment 0002 (2026-08-28) | 3.5 | Subcontracts at quotes ADD-26-311 (HDD) and PJB-8817 (jack-and-bore / jack-and-sleeve), no waste, tax or adjustment | HDD $64/$92/$128 per LF (2/4/6 conduits), pits $5,400, minimum $14,000, +15 % footage if deeper than 96 in | All |
| R12 | RFP FA4610-26-R-0031 Section 01 11 00, Amendment 0002 (2026-08-28) | 3.6 | JOOH 9.5 % of DC; HOOH 4.5 % of DC+JOOH; profit by weighted guidelines; bond from surety letter on the seven recommended designs; escalation; design contingency 5.0 %; SIOH 5.7 % | See Markups | All |
| R13 | UFC 3-740-05 (2022, Change 1) | 11-2.1, 11-2.2 | Weighted guidelines: size of job prorated 0.12 ($100k) to 0.05 ($5M); period prorated 0.03 (30 days) to 0.12 (24 months); subcontracting 0.12 (own forces) to 0.03 (80 %) | Weights 0.0614 / 0.0848 / 0.0863; profit 7.949 % | All |
| R14 | Sierra Surety bond rate letter 2026 | Class B schedule | Graduated premium on contract amount excluding bond; +1 % of premium per month beyond 12 months | 15-month performance: +3 % | All |
| R15 | UFC 3-740-05 (2022, Change 1) | 13-4, 13-3.2 | Escalation as a separate element to the midpoint of construction; SIOH applied to contract cost including contingency | SIOH 5.7 % x (contract + contingency) | All |
| R16 | UFS 3-701-01 (2026) and data tables | Table 4-2; 4-1.1 | Escalation factor from Table 4-2 interpolated by day; ACFs not applied to detailed quantity take-offs | Factor 2026-09-15 = 1.041501, 2027-08-18 = 1.061693; ratio 1.019387; ACF 1.0 | All |
| R17 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) | 1.3 | Order of precedence: IEDS project requirements, UFC (stricter of UFC/UFGS), approved submittals over catalogue data, current protective device settings over one-line, SUE over record drawings, boring logs over report summaries, arborist survey over drawings | Applied | All |
| R18 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) | 2.1 | MV cable: 1/C MV-105 XLPE 133 % Al, copper tape shield; min 1/0 AWG; three conductors of a set in one duct/raceway | TD-15AL-133 | All |
| R19 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) | 2.2 / Protective Device Settings Schedule Rev D | Feeder ampacity (sets x ampacity per set at governing condition) >= phase pickup | F1 640, F2 560, F3 400, F4 40, CF-1 120, CF-2 60, A-3 200 A | All |
| R20 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) | 2.3 | Load factor 100 % for F1/F2, 75 % for all other feeders | 100 / 75 % | All |
| R21 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) / TD-15AL-133 Rev 3 cable data sheet / SUB-33 71 02-07 approved submittal (2026-08-21) | 2.4 / TD-15AL-133 4.10 | Short-circuit capability for the tabulated duration >= clearing time (0.5 s) not less than bus fault current | SS-1 16.5 kA, SWG-C1 14.2 kA, MSG-A 15.8 kA -> minimum 250 kcmil (16.6 kA @ 0.5 s) | All |
| R22 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) | 4.1 | Overhead not permitted inside the industrial area (ADP 2024) or the W-3 dock crane operating area; outside permitted with underground risers | C-101 AREA-CONGESTED polygon | Site items |
| R23 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) / UFC 3-550-01 (2016, Change 3) | 4.2 / 3-11.2.1, 3-11.3.1 | Primary circuits in concrete-encased ductbank; direct-buried cable and unencased conduit not permitted; direct burial not authorized for base core distribution | CEDB required | Site items |
| R24 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) | 4.3 | Perimeter Road, Mission Drive, MB-1 drive not open-cut (bore or jack-and-bore); P-1 and CUP-1 yard may be saw-cut: reinforced ductbank, encasement 5 ft beyond paving; bores only for crossings of roads/parking/water and not more than 50 ft beyond pavement edge or channel bank; DC-1 not open-cut | Mission Dr crossings by HDD; CUP yard reinforced CE | Site items |
| R25 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) | 4.4 | Bus A (F1, F3) and bus B (F2, F4) conveyances do not share ductbanks/structures and are >= 20 ft apart except within 50 ft of the SS-1 fence or MB-1 walls | 20 ft | C01, C02, C03, C06 |
| R26 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) / UFGS 33 71 02 | 4.5 / 3.7.4 | RR-SPUR-2 crossings: jacked RGS when crossing length (within 12 ft of outer rails) <= 50 ft, else jack-and-sleeve; top of conduit >= 50 in below top of rail | Not crossed by the recommended designs (C07 passes east of the bumper post) | C07 |
| R27 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) / UFC 3-550-01 (2016, Change 3) | 4.6 / B-2.1 | Manufacturer ampacity tables and selection rules (next higher rho, depth, circuits; no interpolation); rho of nearest boring (3 ft test); earth ambient 25 C correction on every underground table; circuits = occupied ducts; governing = lowest along route; bores/jacks excluded when <= 25 % of the underground run; ACSR at 40 C; building 40 C | TD-15AL-133 ampacity workbook | All |
| R28 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) / UFC 3-550-01 (2016, Change 3) App. B / UFGS 33 71 02 | 4.7 / B-1.1 / 3.7.8.2 | Directional bore: HDPE SDR 11, min 5 in, fill <= 30 %, cover 48 in under pavement and 120 in elsewhere except within 10 ft of the bore ends | HDPE-5 for 250 kcmil, HDPE-6 for 350/500 kcmil | Site items |
| R29 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) / UFC 3-550-01 (2016, Change 3) | 4.8 / 3-11.2.2 | EB-20 PVC in concrete, 5 in min duct, 3 in spacing, 3 in concrete cover; spares >= 1/3 of ducts (min 1), rounded up; one 4/0 bare Cu ground per ductbank | Spares = max(1, ceil(n/2)) | Site items |
| R30 | UFC 3-550-01 (2016, Change 3) / UFGS 33 71 02 | 3-11.2.2 / 3.7.9 | Minimum cover: stricter of UFC (conduit 18 in, 24 in under pavement) and UFGS (envelope 18 in, 24 in under roads/pavement) | 18 in (24 in under pavement) to top of envelope | Site items |
| R31 | UFGS 33 71 02 | 3.7.9 note, 3.7.8.1 | Reinforcement: 4 No. 4 bars (6 if envelope > 30 in wide) with No. 3 ties at 3 ft; under paved areas, encasement and reinforcement extend 5 ft beyond the edges | Reinforced segments in P-1 / CUP yard + 5 ft | Site items |
| R32 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) / UFC 3-550-01 (2016, Change 3) | 4.9 / 3-10 | Overhead: max span 1/0 300 ft, 3/0 280, 336.4 250, 477 220; Class 3 wood 45 ft, 50 ft both poles of a road-crossing span; guy > 5 deg; dead-end 2 guys > 60 deg; riser poles dead-end with one guy; pole clearances (25 ft buildings, 6 ft road edges, not in pavement, 12 ft from rail, not in channel buffer); tension <= 50 % RBS and <= 4,750 lb | C06: 6 spans of 267.5 ft, 1/0 ACSR Raven | C06 |
| R33 | UFGS 33 71 01 | 3.1.3.1 | Pole setting depth in soil: 45 ft pole 1.98 m (6.5 ft); 50 ft pole 2.13 m (7.0 ft) | 6.5 / 7.0 ft | C06 |
| R34 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) / UFC 3-550-01 (2016, Change 3) | 4.10 / 3-11.5.5, 3-11.6 | Manholes not in pavement and (Air Force) >= 50 ft from paving edges and >= 200 ft from fueling point FP-1; structures where splices are required and where direction changes without 25 ft long-sweep bends; within 100 ft (200 ft with pulling calculation) of riser poles and pad-mounted transformers; <= 400 ft (600 ft with pulling calculation) between structures; bend tangent lengths accommodated | Pulling calculations submitted for every pull | Site items |
| R35 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) / TD-15AL-133 Rev 3 cable data sheet / SUB-33 71 02-07 approved submittal (2026-08-21) | 4.11 / TD-15AL-133 4.1-4.9 / letter 2026-08-14 | Max pulling tension 0.006 lb/cmil on two conductors, <= 10,000 lb; SWBP <= 600 lb/ft (submittal supersedes 1,000); friction PVC 0.35, HDPE 0.30, RGS/EMT 0.40, tray 0.15; cradled when D/d >= 2.8 else triangular; jam range 2.8-3.2 avoided; fill <= 40 %; feed-in 100 lb; pull from the end giving lower tension; riser elbows 90 deg 36 in radius; tray fittings 24 in | Pulls sheet | All |
| R36 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) / 29 CFR 1926 Subpart P | 4.12 / App. A, App. B | Soil type from nearest boring log, least stable layer within excavation depth; granular or below groundwater = Type C; >= 5 ft deep requires sloping (A 3/4:1, B 1:1, C 1.5:1) or shield; manhole excavations 8 ft; dewater below groundwater | Trench shield (box) where >= 5 ft | Site items |
| R37 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) | 4.13 | Existing utilities: 5 ft horizontal edge-to-edge where parallel; 12 in vertical at crossings (SUE-24-0117 depths) | G-4 crossed under (cover 53 in); T-2 crossed under (cover 60 in); bores under W-12 (top of conduit 81 in) | Site items |
| R38 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) | 4.14 | Tree protection zone radius 1 ft per inch DBH (arborist survey TS-24-0117); no excavation within; bores/jack-and-bore under a TPZ with >= 48 in cover only | All TPZs avoided | Site items |
| R39 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) / UFC 3-520-01 (2025) / UFGS 26 20 00 | 5.1 / Table 3-1 / 3.1.6.7, 3.1.8 | MV cable inside buildings in raceway or fully enclosed cable tray; conduit for circuits > 600 V: RMC or IMC only; vertical space tray 6+12 in, RMC 6 in (A-501); no conveyance within 10 ft of SCIF walls; rises 7 ft with 90 deg elbows | TRAY-EN with RMC through COR-1D (14 in) | C05 |
| R40 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) | 5.2 | RMC firestopped at every rated wall; tray stops 10 in from 2-hour walls, cables in 4 in RGS sleeves (<= 40 % fill); tray crossing 1-hour walls firestopped per set | 2-hour: ER-A/COR-1, COR-1E/MR-1; 1-hour: COR-1/COR-1D, COR-1D/COR-1E | C05 |
| R41 | PCSFA-IEDS Installation Electrical Design Standard, Revision 3 (2026-05-01) / UFC 3-501-01 (2024) | 5.3 / 3-2.11 | Tray supports 6 ft, RMC 10 ft; seismic braces every 40 ft transverse and 80 ft longitudinal; pull boxes so bends between pull points <= 270 deg; pulling tension and sidewall calculations for MV cable in conduit | ceil(L/40)+ceil(L/80) braces | C05 |
| R42 | RFP FA4610-26-R-0031 Section 01 11 00, Amendment 0002 (2026-08-28) | 3.7 / 3.8 | Take-off conventions and pairing of labor and material codes | Takeoff sheet | All |
| R43 | UFC 3-550-01 (2016, Change 3) | 3-11.4.1 | Directional boring authorized only for crossings (roads, parking lots, water, environmentally sensitive areas); not selected in lieu of concrete encasement based solely on cost | HDD type not permitted as method of entire run | Site items |
| R44 | UFGS 33 71 02 | 3.6.1, 3.6.2, 3.7.8 | Direct-burial cable cover 30 in (> 600 V); conduit without encasement cover 24 in; ducts under paving extend 5 ft beyond edges (used to price DBC/UEDB alternatives) | 30 / 24 in | Site items (pricing) |
| R45 | A-501 MB-1 Ceiling Space Schedule Rev 1 / E-101 Rev 2 | Schedule | Available space and wall ratings (walls take the higher rating of the adjoining rooms) | ER-A 48, COR-1 20, COR-1D 14, COR-1E 20, MR-2 16, MR-1 44 in | C05 |
