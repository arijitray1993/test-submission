# Design basis - condenser water heat rejection replacement, Papago Federal Center (95 % CD)

Prepared for the EOR (Sandoval Klee Mechanical Engineers, PC). Deliverables: CT_SCHEDULE_{CUP,ANNEX,LAB}.dxf, CT_CALC_{CUP,ANNEX,LAB}.xlsx, constraint_register.csv.

## Governing constraints (DC-02 paragraph 9)

GOVERNING CONSTRAINT CUP: structural capacity (relative margin 0.025)
GOVERNING CONSTRAINT ANNEX: water allocation (relative margin 0.001)
GOVERNING CONSTRAINT LAB: electrical capacity (relative margin 0.011)

## Documented conflicts (DC-02 paragraph 9.1)

CONFLICT 1: ADOPTED UFC 3-410-01 2-4.2.4 | SET ASIDE PBS-P100 5.3.1
CONFLICT 2: ADOPTED UFM 3-230-13 (5 February 2026) | SET ASIDE UFC 3-230-13 (1 March 2023)
CONFLICT 3: ADOPTED M-401 Revision C | SET ASIDE M-401 Revision B

Notes on the three resolutions. (1) P100 5.3.1 (0.4 % dew point with MCDB for cooling tower selection) is set aside for tower sizing because DC-02 paragraph 2 allocates outdoor design conditions for equipment sizing to UFC 3-410-01, whose 2-4.2.4 sizes open towers at the 1.0 % annual wet bulb + 5 F (DC-02 5.2, RFI-031 Response 1). P100 5.1.3 still governs the separate cooling robustness (failure) case at the 0.4 % evaporation design wet bulb with the same 5 F adder. (2) DC-02 paragraph 2 and RFI-031 Response 3 - the 2026 UFM supersedes the 2023 UFC; the technical content used (Eq. 5-4, 5-3.2.5, Appendix A, Table A-2, pHeq = 1.485 log TA + 4.54) was cited from the 2026 manual only. (3) M-401 Rev C fixes the equipment zones and the intake positions; Rev B (larger zones, intakes at (64,2), (66,204), (70,406)) is superseded and was not used.

Other library disagreements resolved: PBS-P100 5.3.5.3 TDS cap of 1,500 ppm does not govern the reclaimed supply (DC-02 2; supply TDS 1,720 mg/L); cancelled UFC 3-400-02 not used for design values; NIST IR 85-3273-39 (2024) used for method text only, all factors from the 2025 data release; M-601 reference capacity treated as a normalising constant (capacity from CAPFT); MCC-R3 spare reduced per RFI-034; ANNEX allocation per PW-LTR-019 (12,600 kgal/yr); calcium hardness from dissolved Ca x 2.497 (not total hardness); TDS of record = ROE 1,720 mg/L (not the computed 1,610).

## Governing documents

DC-02 Rev 3 (criteria, conventions, formats); EC-01 Rev 0 (LCC); UFC 3-410-01 Change 1 (design WB, IMC 908.5 blowdown/chemical feed); GSA PBS-P100 2024 (robustness basis 5.1.3, 5.3.2.3 matching cells/equalizing/VFD/4 ft basin clearance, 5.3.3.2 Table 5.2 25 ft intake separation, 5.3.3.11 no galvanized water-contact surfaces); UFM 3-230-13 (2026) and WT-01 Rev 1 (water chemistry, COC, PSI); 10 CFR 431 Subpart B (motor efficiency); 10 CFR 436 Subpart A and the 2025 Annual Supplement data release (discount rate 3.0 %, FEMP UPV*); EnergyPlus source and data sets in vendor_data (simulation basis); VD-01..VD-05 submittals; M-401 Rev C, S-401 Rev C, E-501/E-601 Rev C, M-601 Rev C, M-603; PW-LTR-014 with PW-LTR-019; UT-01; RFI-031; RFI-034; spec 23 65 00.

## Climatic basis

POR: NCEI LCD Phoenix Sky Harbor (72278023183) 2022, 2023, 2024; FM-15 and FM-16 rows only (SOD/SOM/FM-12 excluded); Tucson record excluded. Observations with blank wet bulb (885, mostly Dec 2024, no station pressure) cannot be binned and are excluded from the WB statistics and bins; values carrying the "s" (suspect) indicator are retained at their reported value. 26,527 observations with WB and DB.

- 1.0 % annual WB = 75 F (0.59 % of observations exceed 75 F, 2.01 % exceed 74 F). Design WB = 75 + 5 = **80.0 F** per UFC 3-410-01 2-4.2.4 (weather basis for the design point, scheduled approach and capacity check). It lands on the YorkCalc maximum inlet WB (26.6667 C) per DC-02 6.8.
- 0.4 % annual (evaporation) WB = 76 F. Failure-case WB = 76 + 5 = **81.0 F** per PBS-P100 5.1.3 and RFI-031 Response 1 (evaluated at the clamped 80 F by the YorkCalc object).
- 99.6 % annual DB = **41 F** (0.37 % of observations below 41 F). 41 F > 32 F, so DC-02 5.4 does not require a basin heater or heat-traced makeup: BASINHEATER NO.
- Barometric pressure = mean station pressure of the POR = 28.722 inHg (97,264 Pa).
- Scenario bins per DC-02 5.3: 180 occupied 2 F WB x 5 F DB bins, edges at multiples of the width from 0 F, mid-points, counts scaled to 8,760 h; DB raised to the WB mid-point where lower; block load from M-603 at the bin DB (linear, end values held).

## Calculation methods

- Tower: EnergyPlus CoolingTower:VariableSpeed with the YorkCalc default coefficients (counterflow cells; the object carrying the liquid-to-gas limit named in DC-02 6.8). WFRR = cell flow / VD-01 nominal flow. Outlet temperature by the range balance of calculateVariableTowerOutletTemp; fan control by calculateVariableSpeedTower: full speed when the setpoint cannot be met (supply floats), modulation (air flow ratio root), minimum speed 0.3 with cycling, free convection at 0.125. Bypass holds the setpoint (DC-02 6.7). Inlet WB clamped at 26.6667 C; WFRR never clamped.
- Fan power: per-cell design electric power = VD-02 design shaft bhp x 0.7457 / (premium motor efficiency x VFD 0.97), scaled by AFR^3 (VD-02 cube law) and by the cycling ratio; cells in service only.
- Chillers: Chiller:Electric:EIR (ChillerElectricEIR.cc) with the M-601 named data sets; curves clamped (CurveManager.cc); staging by available capacity RefCap x CAPFT at the operating ECWT (DC-02 6.5), load shared equally; QCond = power + QEvap. Heat rejection = 500 x gpm x range.
- Pumps: DC-02 6.4 per running chiller at the fixed per-pump flow GPMTOTAL/N.
- Cells: DC-02 6.6 staging with effective minimum = max(VD-01 min, 0.75 x nominal).
- Water: evaporation formulation declared per plant on the schedule and used throughout that workbook - CUP **LOSS-FACTOR**, ANNEX **SATURATED-EXIT**, LAB **LOSS-FACTOR**. LOSS-FACTOR = UFM 3-230-13 5-2.1.3 rule of thumb, 1 % of recirculation per 10 F of range (E = 0.001 x gpm x range F, Example 4-2). SATURATED-EXIT = calculateWaterUsage moist-air method (inlet enthalpy saturated at WB, outlet saturated at inlet enthalpy + Q/m_air, density per DC-02 7 at mean of DB and outlet saturation temperature, >= 4 C). Drift = certified DE-2 rate (0.002 %) x design flow of cells in service x AFR; blowdown = E/(COC-1) - drift; makeup = E + drift + blowdown. The LCC prices SATURATED-EXIT quantities for every design (EC-01 6); the allocation, peak-day and discharge checks use the declared formulation.
- COC: WT-01 4 with the 2022-07-26 analysis of record (Ca 109 mg/L -> 272.2 ppm CaCO3, TDS 1,720 mg/L ROE, SiO2 16.0 mg/L); alkalinity held at 120 ppm by acid; PSI = 2 pHs - pHeq with A, C, D closed forms, B from Table A-2 interpolated at the achieved design-point CWR, pHeq = 1.485 log 120 + 4.54 = 7.628; PSI >= 5.60 governs (silica limit 9.38). Scheduled COC = allowable COC truncated to two decimals.
- Design point: 80 F WB, design load, all chillers at design flow, staged cells at full speed; reported values are achieved; CWSDESIGN scheduled with a conservative allowance (approx. 0.5 F, rounded up to 0.1 F) over the achieved supply temperature. Redundancy: largest cell out, design flow carried by the remaining cells at full speed, 81 F WB; capacity = N x RefCap x CAPFT at the achieved ECWT.
- LCC: EC-01 / 10 CFR 436: base date 1 Oct 2025, 1-yr construction, study period 26 yr (25-yr life of the longest-lived admitted alternative, SS-304/SS-316; G-235 inadmissible per P100 5.3.3.11), DOE real discount rate 3.0 %; UPV*elec = 16.3061 - 0.9709 = 15.3352 (West/Mountain, commercial, electricity); UPV nonfuel = 16.9060; water/sewer real escalation (1.035/1.015) - 1 = 1.9704 % -> UPV*water = 21.7770; energy cost = kWh x $0.0712 + peak kW x $17.80 x 12; water = makeup x $1.94 + blowdown x $3.20 per kgal; O&M = makeup x $0.42/kgal + $3,200/cell-yr; investment from VD-05 (base, SS-304 +22 %, DE-2 $2,100, premium motor adder, $0.85/lb rigging, $14,000/cell, $60,000/plant). SS-304 cells outlive the 25-yr service period exactly: no replacement, zero salvage.

## Selected designs

| Plant | Cells x model | GPMTOTAL | CWSMIN / offset (F) | COC | Evap method | Peak kW / spare | Annual makeup (declared) kgal / allocation | NS vs basic |
|---|---|---|---|---|---|---|---|---|
| CUP | 4 x CTX-0600-S | 1802 | 65.5 / 11.4 | 4.14 | LOSS-FACTOR | 514.7 / 528.0 | 8405 / 10300 | $245209 |
| ANNEX | 4 x CTX-0600-S | 1801 | 79.35 / 11.6 | 4.00 | SATURATED-EXIT | 571.1 / 590.0 | 12585 / 12600 | $261395 |
| LAB | 3 x CTX-0900-H | 2027 | 57.5 / 8.75 | 3.88 | LOSS-FACTOR | 634.1 / 641.1 | 14490 / 17400 | $296411 |

Common selections: SS-304 casing/basin (lowest LCC compliant material: FRP-PV saves 10 % of base price but its 20-yr life forces a year-21 replacement and costs $400/cell-yr more maintenance; G-235 prohibited), DE-2 eliminator (meets the 0.002 % limit; DE-3 costs more and, because blowdown = E/(C-1) - drift, raises billed blowdown), premium 6-pole TEFC motors (economy offerings fall below 10 CFR 431.25 Table 5), VFD on every fan, equalizing lines and automatic isolation valves (EQUALIZING YES), conductivity-controlled automatic blowdown and chemical feed (BLOWDOWNCTRL YES), no basin heater (BASINHEATER NO), basin 4.5 ft above roof (P100 minimum 4 ft).

Why these configurations: the LCC is dominated by chiller energy and the ratcheted demand charge, so the optimum keeps condenser flow at the lowest value that keeps every operating cell at or above the WFRR floor of 0.75 in one-chiller operation (1,802 gpm CUP and 1,801 gpm ANNEX for 4 x CTX-0600-S: about 450 gpm/cell; 2,027 gpm for 3 x CTX-0900-H: 675.7 gpm/cell), which minimises pump energy and demand. 4 x CTX-0900-S costs $202k more for little benefit; 2 x CTX-1350-S cannot serve one-chiller operation inside the WFRR floor; larger cells do not fit the Rev C zones with the VD-01 clearances, and CTX-1800-S exceeds 102 dBA. At LAB, 3 x CTX-0900-S exceeds the 641 kW MCC-R3 spare; the CTX-0900-H (18.4 bhp, 124.0 psf placed on LAB-S1 126 psf) is required. The reset floor/offset were optimised on the full bin set against the priced SATURATED-EXIT water, fan, chiller, pump and demand costs.

## Margins and judgement calls

- CUP margins: water allocation 0.184; electrical capacity 0.025; roof area 0.135; structural capacity 0.025; condenser flow limit 0.201; tower capability 0.092. Design point achieved CWS 85.36 F (scheduled 85.9 F), CWR 98.01 F, COC 4.14 (allowable 4.143). Redundancy CWS 87.86 F, capacity 918 tons. Peak day makeup 43819 gal, blowdown 10555 gal.
- ANNEX margins: water allocation 0.001; electrical capacity 0.032; roof area 0.135; structural capacity 0.056; condenser flow limit 0.201; tower capability 0.081. Design point achieved CWS 85.70 F (scheduled 86.2 F), CWR 99.37 F, COC 4.00 (allowable 4.002). Redundancy CWS 88.34 F, capacity 946 tons. Peak day makeup 52847 gal, blowdown 13182 gal.
- LAB margins: water allocation 0.167; electrical capacity 0.011; roof area 0.069; structural capacity 0.016; condenser flow limit 0.270; tower capability 0.078. Design point achieved CWS 85.99 F (scheduled 86.5 F), CWR 100.57 F, COC 3.88 (allowable 3.880). Redundancy CWS 90.18 F, capacity 1234 tons. Peak day makeup 57753 gal, blowdown 14841 gal.
- Roof-area margin computed conservatively with each cell support enlarged by its full VD-01 clearance on every face (no sharing between cells); actual layouts hold the clearance to the zone boundary and between cells, keep each frame inside one S-401 framing zone and more than 25 ft from every Rev C intake.
- One-chiller operation sits just above the WFRR floor (0.7504-0.7508), a deliberate 1-2 gpm allowance above 0.75; every other state is at the same or a higher ratio, and the redundancy state (one cell out) runs at WFRR 1.00 (CUP, ANNEX) and 1.13 (LAB).
- ANNEX is the only plant on which a water limit governs: the SATURATED-EXIT allocation check binds the reset (lower floors/offsets save chiller energy but raise evaporation). The floor/offset pair was set on that boundary with a deliberately small allowance (about 0.1 % of the 12,600 kgal allocation); LOSS-FACTOR was not declared for ANNEX because no cost-effective design meets the allocation under it.
- CUP and LAB declare LOSS-FACTOR; their optima are interior (no binding limit) and both also satisfy the allocation under SATURATED-EXIT (CUP 9591 kgal, LAB 16943 kgal saturated-exit makeup vs 10300 / 17400 kgal allocations).
- The fan electrical input includes the VD-02 drive efficiency (0.97), consistent with RFI-034.
- MCC-R3 spare = 660 - 3 x 7.5 x 0.7457/(0.917 x 0.97) = 641.14 kW (RFI-034).
- Water quantities in the LCC are SATURATED-EXIT for both the design and the basic design; the basic design is evaluated with the same bins, staging and controls.
