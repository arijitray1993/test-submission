# Building B - seismic diaphragm and shear wall design basis

Design format: LRFD

All loads in this package are strength-level seismic load effects (1.0E, rho = 1.0 where noted) and all capacities are LRFD design strengths (phi x nominal) of the referenced standard. No ASD values are used anywhere (SDC-02 s.9). Units are ft, kips, plf.

## 1. Seismic basis

* Code: 2024 IBC as adopted by Montana (ARM 24.301.131); ASCE/SEI 7-22; ACI 318-19; AISI S310 (SDC-02 s.1).
* Risk Category III, Ie = 1.25 - Building B houses the county 911 emergency communications tenant (OBD-CDDC-B s.1.4, SDC-02 s.2, ASCE 7-22 s.11.5.1 / Table 1.5-2). The Risk Category II block on the architectural cover sheet is superseded by SDC-02.
* Site Class D from the measured Vs,100 = 905 ft/s of boring B-204 (GEO-2026-071 s.4, SDC-02 s.3).
* SDS = 0.44 g, SD1 = 0.24 g from the USGS ASCE7-22 web-service output for Risk Category III, Site Class D, 46.6832 / -111.9756 (project/30_seismic). Ts = 0.545 s.
* SDC from SDS = C, from SD1 = D; the more severe governs -> **SDC D** (ASCE 7-22 s.11.6, SDC-02 s.3). The s.11.6 exception that allows Table 11.6-1 alone is not available because the diaphragm is flexible with spans > 40 ft.
* Ta = Ct hn^x = 0.02 x 28^0.75 = 0.243 s (Eq. 12.8-7). Cs = SDS/(R/Ie) = 0.44/(4/1.25) = 0.1375 (Eq. 12.8-2); Eq. 12.8-3 limit 0.308 does not govern; Eq. 12.8-5 minimum 0.0242.
* Effective seismic weight W = roof 20 psf x 39200 sf net = 784.0 k + phase 1 RTUs 45.0 k + walls 1441.5 k = **2270.5 kips** (future mass case 2286.5 k). Base shear **V = 312.2 kips** (future 314.4 k). Single storey: Fx = V at the roof.
* Wall weight tributary to the roof uses the lever action of the 3 ft parapet cantilever (SDC-02 s.6, FEMA P-2192-V1 s.7.6.1 Step 1): w = 100 psf x 31 ft x (31/2) ft / 28 ft = 1716.1 plf, i.e. a tributary height of 17.16 ft (not 28/2 + 3 = 17.0 ft).
* Diaphragm force (ASCE 7-22 s.12.10.1.1): Fpx/wpx = sum Fi / sum wi = Cs = 0.1375, between 0.2 SDS Ie = 0.110 and 0.4 SDS Ie = 0.220. wpx(X) = 1446.8 k -> Fpx = 198.9 k, w_px = 1105 plf over the 180 ft span; wpx(Y) = 1652.7 k -> Fpx = 227.2 k, w_px = 947 plf over the 240 ft span. The wall lines parallel to the loading carry their own inertia directly (DAP-2 s.5).
* Construction stage (S11, S12): 0.5 x the permanent seismic load, Ie, R and accidental torsion unchanged (ERC-07 s.3, ASCE/SEI 37-14), deck fastened west of X = 180 ft only (ERC-07 s.4).
* Redundancy: rho = 1.0 for the diaphragm, collectors (Omega0 effects) and wall anchorage (ASCE 7-22 s.12.3.4.1); for the walls rho = 1.0 per s.12.3.4.2(b) (regular plan, at least two 28 ft bays of perimeter wall on each side).

## 2. Seismic force-resisting system

**Selected: intermediate precast shear walls, bearing wall system (UFC 3-301-01 Table 3-1 row A.6 = ASCE/SEI 7-22 Table 12.2-1 row A.5): R = 4, Omega0 = 2.5 (2.0 for collectors - footnote b, flexible diaphragm, SDC-02 s.4), Cd = 4.** The row permits the system in SDC D up to hn = 40 ft (footnote i); Building B has hn = 28 ft (A-101 note 2). Detailing to ACI 318-19 s.18.5 (18.2.1.6 reference).

Why it is the cost-efficient choice (PROC-114 rates, 79 erected panels):

* Ordinary precast shear walls are NP in SDC D (Table 3-1 row A.7) - not permitted.
* Special RC (special precast) walls (row A.1, R = 5, Cd = 5) carry a detailing premium of USD 4,120/panel = USD 325,480 for 79 panels, against USD 1,850/panel = USD 146,150 for intermediate walls; the premium difference (USD 179,330) alone exceeds every saving the 20 % force reduction can buy (the whole deck, connector and tie-down scope of the intermediate design is USD 152,405) and the special option exceeds the USD 395,000 cap. Any joint connector in a special wall would also have to be the JC3 RPC-60D (RPC-CAT-2026 s.2).
* Within intermediate walls the panels are detailed as isolated panel piers (JC0, no vertical joint connectors). Under the DAP-2 Stage A model the coupling force adds to the tie-down of the panels it is delivered to and stiffens the segment (VP-1: k_seg 1,279 vs 769 kip/in, interior-panel tie-down 1.32 vs 0.875 kip per kip), so connectors would cost money and increase tie-down demand. Each panel resists its share of the segment force as a 28 ft cantilever; tie-downs carry the base couple on a 0.8 L lever arm (DAP-2 s.3).

## 3. As-built geometry

The scan CDDC-SV-2026-041 was registered to the building grid on the four high-intensity spheres (rigid transform, rotation -1.742 deg, residuals < 0.0003 ft); the inside faces of the panels fall at X = 0 / 240 and Y = 0 / 180 and the roof openings at RO-1 96-156 x 108-148 and RO-2 36-116 x 36-56. The erected geometry governs (RFI-041, PR-07). Conflicts found and the reading taken:

| item | record documents | reading taken | basis |
|---|---|---|---|
| Dock door D-3 | PC-101 Rev 2 / A-101 Rev 3: 78-92 ft (14 ft) | **78.0-93.5 ft (15 ft 6 in)** | RFI-041, ERL-2026-08, scan |
| Dock door D-4 and the band east of D-3 | PC-101: 108-122 ft | **109.5-123.5 ft** (shifted 1 ft 6 in east) | RFI-041, ERL, scan |
| Pier between D-4 and D-5 | PC-101: 16 ft | **14 ft 6 in (123.5-138.0 ft)** | RFI-041, scan |
| Louver L-2 (north) | PC-101/A-101: 156-168 ft (12 ft) | **154.0-170.0 ft (16 ft), sill 14 ft / head 24 ft** | PCS-014 ticket Rev B, ERL, RFI-041, scan |
| Electrical yard EY-1 (west) | PC-101/A-101: 66-106 ft (40 ft) | **66.0-110.0 ft (44 ft)** | FC-018 in ERL (2026-06-24), RFI-041, scan |
| Panel layout / count | PCS-014: 81 cast panels | **79 erected panels**: nominal 10 ft panels from each segment start with the closer at the segment end; N-28 and W-15 do not fit the erected wall lines | scan joints (all 46 visible joints lie on this module), PC-101 note 1 |
| Footprint | A-101 note 1 says 240 x 180 out-to-out | 240 x 180 ft between inside faces (grid origin at inside face) | scan control report s.3, registered scan |
| Risk category | A-101 cover code block: RC II | RC III | SDC-02 s.2, OBD s.1.4 |
| Site class / spectra | GEO-2019-118 and ASCE7-16 Parcel 4B JSON: Site C, SDS 0.407, SDC C | Site D, SDS 0.44, SD1 0.24, SDC D | GEO-2026-071, SDC-02 s.3 (2019 report is another parcel, ASCE 7-16) |
| Building A summary SM-2019-04 | OCBF R = 3.25, ASCE 7-16 | not used | another building, superseded basis |
| Roof plan A-101 Rev 1 (archive) | superseded | A-101 Rev 3 and M-601 Rev 3 used | T-2026-118 (archive for record only) |
| Wind memorandum WM-2026-09 (archive) | wind loads | not a design source; seismic governs | archive, another load case |
| Omega0 | Table value 2.5 vs flexible-diaphragm footnote | 2.0 for collectors | SDC-02 s.4 + Table 3-1 footnote b; 12.10.4 (which voids footnote b) is not used |
| Diaphragm idealisation | 12.3.1.1 flexible vs PR-07 | flexible classification kept for Omega0/ka; forces = envelope of flexible/rigid/semi-rigid | PR-07, SDC-02 s.10, DAP-2 s.6.3 |

Wall segments used in Stage A (louver portions are spandrel segments with EI and GAv x 18/28):

* S: S1 0-18 ft (pier, panels 10+8); S2 32-48 ft (pier, panels 10+6); S3 62-78 ft (pier, panels 10+6); S4 93.5-109.5 ft (pier, panels 10+6); S5 123.5-138 ft (pier, panels 10+4.5); S6 152-196 ft (pier, panels 10+10+10+10+4); S7 200-240 ft (pier, panels 10+10+10+10)
* N: N1 0-24 ft (pier, panels 10+10+4); N2 28-60 ft (pier, panels 10+10+10+2); N3 60-72 ft (spandrel, panels 10+2); N4 72-154 ft (pier, panels 10+10+10+10+10+10+10+10+2); N5 154-170 ft (spandrel, panels 10+6); N6 170-240 ft (pier, panels 10+10+10+10+10+10+10)
* W: W1 0-12 ft (pier, panels 10+2); W2 16-66 ft (pier, panels 10+10+10+10+10); W3 110-180 ft (pier, panels 10+10+10+10+10+10+10)
* E: E1 0-72 ft (pier, panels 10+10+10+10+10+10+10+2); E2 86-108 ft (pier, panels 10+10+2); E3 108-120 ft (spandrel, panels 10+2); E4 120-150 ft (pier, panels 10+10+10); E5 154-180 ft (pier, panels 10+10+6)

## 4. Analysis

The package was analysed with an independent implementation of DAP-2 Rev 1. Stage A reproduces the VP-1 verification example exactly (k_seg = 1,279.4 kip/in; joint shears 0.2630 / 0.2527 kip/kip; panel 1 base moment 88.91 kip-in/kip; axial 0.2630 kip/kip; isolated 769.2 kip/in). Stage B is a 10 ft plane-stress mesh (24 x 18, elements with centroid inside RO-1/RO-2 removed), D = diag(A', A', G'), A' = 1,740 kip/in, G' of the zone pattern (BDS-2026-DT Table 4), 2x2 Gauss, chord/collector bars with E = 29,000 ksi, wall segments as springs distributed over the nodes they span by tributary length. Loads: Fpx/wpx x (roof DL over the net deck, RTUs at their positions, perpendicular walls); accidental torsion as a mass-proportional rotational field of 5 %% of the perpendicular plan dimension (9 ft / 12 ft) x F, both signs, amplified by Ax from the rigid model (capped at 3.0). Envelope of flexible (simple beam, net depth), rigid (membrane x 10^7) and semi-rigid; zone design shear = largest section mean (DAP-2 s.6.1); 100/30 cases = case + 0.30 x companion with the same mass, sign and stage. Deflections and drift from the semi-rigid model.

The design was checked against the twelve SDC-02 cases and every other permutation of direction, eccentricity sign, mass case (base/future) and 100/30, and the construction stage in both directions, both signs, with and without 100/30 (24 cases). The additional permutations are labelled H01-H12 in this package:

| label | dir | ecc. | mass | orthogonal | stage |
|---|---|---|---|---|---|
| H01 | X | +1 | future | 100/30 | final |
| H02 | X | -1 | base | 100/30 | final |
| H03 | X | -1 | future | - | final |
| H04 | Y | +1 | base | 100/30 | final |
| H05 | Y | +1 | future | 100/30 | final |
| H06 | Y | -1 | future | - | final |
| H07 | X | +1 | erection | 100/30 | erection |
| H08 | X | -1 | erection | - | erection |
| H09 | X | -1 | erection | 100/30 | erection |
| H10 | Y | +1 | erection | - | erection |
| H11 | Y | +1 | erection | 100/30 | erection |
| H12 | Y | -1 | erection | 100/30 | erection |

## 5. Diaphragm and wall forces

Applied shear wall loads F_x (kips, LRFD, envelope of the three idealisations, including the own in-plane inertia of the parallel wall lines) and the maximum zone design unit shear:

| case | dir | S | N | W | E | Ax | max zone v (plf) |
|---|---|---|---|---|---|---|---|
| S01 | X+ base | 159.2 | 164.2 | 12.7 | 12.7 | 1.00 | 478 |
| S02 | X- base | 154.9 | 172.3 | 7.0 | 7.0 | 1.00 | 516 |
| S03 | Y+ base | 9.2 | 9.2 | 155.5 | 166.2 | 1.00 | 801 |
| S04 | Y- base | 10.2 | 10.2 | 162.8 | 156.8 | 1.00 | 858 |
| S05 | X+ base 100/30 | 162.0 | 164.9 | 56.5 | 62.6 | 1.00 | 665 |
| S06 | Y- base 100/30 | 52.1 | 61.9 | 164.9 | 156.8 | 1.00 | 958 |
| S07 | X+ future | 160.0 | 165.5 | 12.7 | 12.7 | 1.00 | 484 |
| S08 | Y+ future | 9.2 | 9.2 | 155.8 | 167.9 | 1.00 | 806 |
| S09 | X- future 100/30 | 156.9 | 176.7 | 56.1 | 52.5 | 1.00 | 683 |
| S10 | Y- future 100/30 | 52.2 | 61.9 | 165.3 | 158.7 | 1.00 | 966 |
| S11 | X+ erection | 63.1 | 60.5 | 0.0 | 0.0 | 1.24 | 230 |
| S12 | Y- erection | 26.2 | 26.2 | 105.4 | 21.2 | 2.78 | 625 |

Deck attachment (zone design shear envelope, all cases, vs phi Sn = 0.60 Sn):

| zone | pattern | phi Sn (plf) | v_u (plf) | util. | governing |
|---|---|---|---|---|---|
| Z1 | P5 | 1101 | 966 | 0.88 | S10 rigid |
| Z2 | P4 | 852 | 525 | 0.62 | H01 semirigid |
| Z3 | P5 | 1101 | 505 | 0.46 | S09 flexible |
| Z4 | P4 | 852 | 803 | 0.94 | H05 rigid |
| Z5 | P4 | 852 | 683 | 0.80 | S10 flexible |
| Z6 | P5 | 1101 | 499 | 0.45 | H11 rigid |
| Z7 | P2 | 474 | 361 | 0.76 | S06 flexible |
| Z8 | P4 | 852 | 799 | 0.94 | H05 rigid |
| Z9 | P5 | 1101 | 829 | 0.75 | S10 rigid |
| Z10 | P4 | 852 | 587 | 0.69 | S09 rigid |
| Z11 | P4 | 852 | 650 | 0.76 | S09 rigid |
| Z12 | P4 | 852 | 773 | 0.91 | S10 flexible |

The construction stage governs the deck stiffness: with the deck east of X = 180 ft unfastened the west wall is the only N-S support of the fastened diaphragm, which cantilevers 180 ft and is restrained in rotation by the S and N walls; Ax from the rigid model = 2.78 (the unattached east wall line contributes no displacement). The 4.0 in limit (SDC-02 s.7) was applied to every construction case at the 0.5 load factor.

Maximum design deflection Cd delta/Ie = 3.88 in <= 4.0 in (governing: construction-stage N-S cantilever of the fastened deck, case H11); final-stage maximum 2.96 in. Maximum storey drift Cd delta/Ie = 0.164 in <= 0.015 hsx = 5.04 in.

Chords, collectors and drag struts: all 20 candidate lines are provided (continuous chords on the four edges and the four sides of both roof openings; drag struts across every wall opening >= 12 ft: D-1..D-6, EY-1, L-1, L-2, L-3 - SDC-02 s.5). Member C1 (L4x4x3/8, phi Pn = 0.9 x 36 x 2.86 = 92.7 k). Governing demands: flexible chord M/d (net depth) 56.1 k on CH-S/CH-N; collector forces x Omega0 = 2.0 up to 38.7 k; highest utilisation 0.61.

## 6. Wall anchorage and the parapet cantilever

* Wp = 1,716 plf per foot of wall (tributary to the roof with the lever action of the parapet). The part delivered by the wall above the top of deck is 100 psf x 3 ft x 29.5/28 = 316.1 plf per foot (parapet transfer).
* Lf per UFC 3-301-01 Figure 3-1 = span of the diaphragm between the walls that support it: 240 ft for the S and N walls, 180 ft for the W and E walls; ka = 1 + Lf/100 capped at 2.0 for all four walls (ASCE 7-22 s.12.11.2.1).
* Fp = 0.4 SDS ka Ie Wp = 755 plf, but not less than 0.2 ka Ie Wp = **858 plf (governs)**.
* Anchors WA2 (embed plate + strap to subdiaphragm tie) at 10 ft on all walls: demand 8.58 k, x 1.4 for steel elements (s.12.11.2.2.2) = 12.01 k <= phi Tn = 0.75 x 18.6 = 13.95 k.
* Continuous cross ties: N-S joist-girder lines at 40 ft for the S/N walls (subdiaphragm 40 ft span x 30 ft deep, L/D 1.33); E-W joist lines on the column lines at 30 ft for the W/E walls (30 ft span x 40 ft deep, L/D 0.75) - both <= 2.5 (s.12.11.2.2.1); the deck is not used as a tie perpendicular to its span (s.12.11.2.2.4). Subdiaphragm shear 572 / 322 plf < phi Sn of the adjacent zones.
* Erection: raking braces 12 kip at 20 ft (ERC-07 s.2, 29 CFR 1926.704(a)); demand 0.5 x 858 plf x 20 ft = 8.6 k; braces removed only after the deck is fastened in that bay.

## 7. Governing constraint per wall line

* **S wall**: governing family = diaphragm_deflection (utilisation 0.97). Other checks: diaphragm_shear 0.94, wall_anchorage 0.86, base_tiedown 0.83, collector_chord 0.61
* **N wall**: governing family = diaphragm_deflection (utilisation 0.97). Other checks: diaphragm_shear 0.91, wall_anchorage 0.86, collector_chord 0.61, base_tiedown 0.50
* **W wall**: governing family = diaphragm_shear (utilisation 0.88). Other checks: wall_anchorage 0.86, base_tiedown 0.75, diaphragm_deflection 0.39, collector_chord 0.36
* **E wall**: governing family = diaphragm_shear (utilisation 0.94). Other checks: wall_anchorage 0.86, base_tiedown 0.65, diaphragm_deflection 0.39, collector_chord 0.26

Tie-downs (BA2, phi Tn = 66 k) per wall: S max 0.83, N max 0.50, W max 0.75, E max 0.65.

## 8. Cost

| item | quantity basis (PROC-114) | USD |
|---|---|---|
| Deck attachment | net zone areas x pattern rate | 80,515 |
| Chords / collectors / drag struts | 20 lines, 2,080 ft of C1 | 23,712 |
| Panel joint connectors | JC0 isolated panel piers | 0 |
| Base tie-downs | 79 erected panels x BA2 | 71,890 |
| Wall anchors | 840 ft / 10 ft = 84 x WA2 | 14,448 |
| SFRS detailing premium | 79 panels x intermediate precast | 146,150 |
| **Total installed cost** | | **336,715** |

Capital cap USD 395,000 (PROC-114 Rev 2, OBD s.5.6): the design is USD 58,285 under the cap (85.2 % of cap).

## 9. Alternatives rejected

* Special precast (special RC) shear walls - premium USD 325,480; even with every other item at its cheapest catalogue option (deck P1 USD 33,712, 20 lines C1 USD 23,712, BA1 USD 41,080, WA1 @ 10 ft USD 8,064) the total would be at least USD 432,048, over the USD 395,000 cap; the R = 5 force reduction cannot offset it.
* Intermediate precast as a building frame system (Table 3-1 B.9, R = 5, Cd = 4.5) - not applicable: the panels are bearing walls carrying the joists (SDC-02 s.4 "bearing-wall shear walls").
* ASCE 7-22 s.12.10.3 (Rs) and s.12.10.4 (RWFD) diaphragm design - excluded by SDC-02 s.5; footnote b would also be void under 12.10.4.
* Ordinary precast shear walls - not permitted in SDC D (Table 3-1 row A.7).
* Joint connectors JC1/JC2 (1-4 per joint, 58 joints) - USD 22,330 to 141,520 extra and, under DAP-2, higher tie-down demand and stiffer segments.
* Uniform deck patterns: uniform P3 fails the zone shears at Z1, Z4, Z8, Z9, Z12 and the construction-stage deflection; uniform P5 costs USD 96,824. Zoned P2-P5 chosen by optimisation (USD 80,515).
* BA1 tie-downs - fail on S, W and E (utilisation up to 1.66) and leave no margin on N; BA3 unnecessary.
* WA1 anchors at 8 ft (USD 10,080) - 6.86 k demand, fails once the 1.4 factor for steel anchorage elements is applied; WA2 at 10 ft adopted.
* Larger chord members (C2-C4) - not required (C1 utilisation <= 0.61).
* ASD format - LRFD gives 7 % more deck capacity per unit demand (0.60/1.0 vs 0.392/0.7) and 5 % more for connectors and anchors.
* Cheaper deck sized for the final stage only (USD 69,410) - rejected: it fails the 4.0 in deflection limit in the construction stage (fastened deck cantilevering east from the west wall, S12 and its sign/100-30 permutations, 4.1-5.0 in); the adopted zoning keeps every final and construction case <= 3.88 in.
