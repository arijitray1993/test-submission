# Design basis - LV wire schedule, sheet E-621, project P-4210 (Building 4210, Consolidated Support Facility)

```json
{
  "project": "P-4210 Building 4210 Consolidated Support Facility, NSA Whitmore Ridge",
  "sheet": "E-621 Wire schedule",
  "codes_of_record": {
    "nfpa70_edition": "2023",
    "ibc_edition": "2024",
    "adopted_by": "UFC 1-200-01 DoD Building Code (1 September 2022, Change 4 of 17 December 2024)",
    "adoption_chain": "UFC 1-200-01 adopts the 2024 IBC and directs every IBC reference to NFPA 70 to UFC 3-501-01, which cites NFPA 70 (2023 edition, the edition in effect at the start of design, 14 July 2025, per G-001); UFC 3-501-01 and UFC 3-520-01 add DoD requirements; EDS-26 Rev 4 adds the installation's",
    "precedence": "Where two documents set different limits for the same thing, the most restrictive requirement governs (G-001; EDS-26 Rev 4 para 1.1); where EDS-26 is silent the UFC governs",
    "other_criteria": [
      "UFC 3-501-01 (27 Nov 2024)",
      "UFC 3-520-01 (16 Jan 2025)",
      "UFC 1-200-02 (energy, cites ASHRAE 90.1)",
      "EDS-26 Rev 4 (12 Jun 2026)"
    ],
    "superseded_not_used": [
      "EDS-26 Rev 2 (3 Mar 2022)",
      "E-601 Rev A (8 Feb 2026)"
    ],
    "code_of_record_sheet": "G-001"
  },
  "environment": {
    "outdoor_design_dry_bulb_c": 42,
    "roof_ambient_c": 46,
    "earth_ambient_c": 27.45,
    "soil_thermal_resistivity_k_m_w": 0.6,
    "soil_thermal_resistivity_rejected_k_m_w": 0.95,
    "encasement_thermal_resistivity_k_m_w": 0.55,
    "solar_irradiance_w_m2": 1030.0,
    "interior_ambients_c": {
      "ceiling_cavity": 40,
      "mechanical_room_121_and_fire_pump_room_105": 45,
      "building_4212_shop": 40,
      "electrical_rooms": 30
    },
    "load_factor": 1.0
  },
  "sources": {
    "outdoor_design_dry_bulb_c": "NOAA daily normals 1991-2020 USW00003145 (site record): highest DLY-TMAX-NORMAL 106.8 F = 41.56 C, rounded up per EDS-26 Rev 4 5.4",
    "roof_ambient_c": "EDS-26 Rev 4 5.4: outdoor design dry-bulb + 4 K (M-501-C roof row 46 C agrees)",
    "earth_ambient_c": "NOAA daily normals 1991-2020 USW00003145: annual mean DLY-TAVG-NORMAL 76.00 F = 24.45 C + 3 K per EDS-26 Rev 4 5.3.2",
    "soil_thermal_resistivity_k_m_w": "GEO-4210-T para 2.2 thermal backfill 0.60 K.m/W (native 0.95 K.m/W of para 2.1 rejected)",
    "encasement_thermal_resistivity_k_m_w": "GEO-4210-T para 2.3",
    "solar_irradiance_w_m2": "EDS-26 Rev 4 para 5.4",
    "interior_ambients_c": "M-501-C table and notes 1 and 3",
    "load_factor": "UFC 3-501-01 3-2.3.3; EDS-26 Rev 4 5.3",
    "cable_data": "Cascadia Wire Engineering Data Section 4 issue 2026-1 (Spec 26 05 19 1.3)"
  },
  "voltage_drop": {
    "start_point": "T-1 secondary lugs - point of government ownership (UFC 3-501-01 3-2.7.4.2; WRPU-2026-0412)",
    "transformer_reset": false,
    "transformer_reset_basis": "UFC 3-501-01 3-2.7.4.5.3: drop through transformers is zero and the percentage at the primary is carried to the secondary; the restart of 3-2.7 applies only where voltage rises above 1000 V, which does not occur",
    "feeder_chain_pct": {
      "MSB-1 (SE-1)": 1.043,
      "MCC-1 (SE-1+F-01)": 2.575,
      "DP-2 (SE-1+F-02)": 1.407,
      "K-13 primary (SE-1+F-02+F-06)": 1.568,
      "LP-1 (SE-1+F-02+F-06+F-07)": 2.769,
      "DP-3 (SE-1+F-05)": 2.581,
      "ATS-1 (SE-1+F-10)": 2.777
    },
    "feeder_limit_pct": 3.0,
    "branch_limit_pct": 3.0,
    "total_limit_pct": 5.0,
    "fire_pump_limits_pct": {
      "locked_rotor": 15.0,
      "running_flc": 5.0
    },
    "fire_pump_result_pct": {
      "locked_rotor": 2.713,
      "running_flc": 1.339
    },
    "service_entrance_vd_load": "1600 A, rating of the MSB-1 main device (UFC 3-501-01 3-2.7.4.3.1 reading, accepted by EDS-26 Rev 4 2.3)",
    "branch_circuits_inheriting_upstream_budget": 24,
    "max_cumulative_at_load_pct": 4.928
  },
  "cost": {
    "conductor_usd": 91442.04,
    "termination_usd": 9609.32,
    "raceway_usd": 47589.6,
    "material_usd": 95156.27,
    "labor_usd": 53484.69,
    "total_usd": 148640.96,
    "campus_quantity_break_applied": true,
    "total_conductor_length_ft": 40888,
    "conductor_usd_before_quantity_break": 97278.75
  },
  "duct_assignment": {
    "SE-1": [
      "D1",
      "D2",
      "D5",
      "D6",
      "D9",
      "D10"
    ],
    "F-10": [
      "D4",
      "D8"
    ],
    "F-05": [
      "E1",
      "E2",
      "E3"
    ]
  },
  "mutual_heating_rise_k": 31.09,
  "mutual_heating_rise_by_circuit_k": {
    "SE-1": 31.09,
    "F-10": 23.53,
    "F-05": 1.54
  },
  "service_duct_bank": {
    "bank": "DB-1",
    "ducts_total": 12,
    "ducts_available": 10,
    "ducts_reserved": [
      "D11 (owner reserve)",
      "D12 (existing site lighting feeder)"
    ],
    "ducts_used": 8,
    "ducts_left_empty": [
      "D3",
      "D7"
    ]
  },
  "distinct_large_sizes": [
    "4/0",
    "300 kcmil",
    "400 kcmil",
    "500 kcmil",
    "600 kcmil"
  ],
  "tray_sum_od_in": 12.206,
  "ampacity_basis": "Engineering supervision, NFPA 70 (2023) 310.14(B): Cascadia heat balance (raceway, free air/tray) and EDS-26 5.3 Neher-McGrath (duct banks)"
}
```

## 1. Codes of record, adopting document and precedence

The codes of record were fixed at the start of design (14 July 2025) and are listed on sheet G-001. **UFC 1-200-01, DoD Building Code (1 Sep 2022 with Change 4 of 17 Dec 2024)** is the adopting document: it adopts the **2024 International Building Code** and directs every IBC reference to NFPA 70 to UFC 3-501-01, which cites **NFPA 70, National Electrical Code, 2023 edition** (the edition in effect at the start of design). UFC 3-501-01 (27 Nov 2024) and UFC 3-520-01 (16 Jan 2025) add the Department's requirements, UFC 1-200-02 (citing ASHRAE 90.1) carries energy criteria, and NSA Whitmore Ridge EDS-26 Rev 4 (12 Jun 2026) adds the installation's requirements. Order of precedence (G-001; EDS-26 1.1): where two of these documents set different limits for the same thing, the **most restrictive requirement governs**; where EDS-26 is silent, the UFC governs. EDS-26 Rev 2 (2022) and E-601 Rev A are superseded and were not used (Rev 2's 2%/3% voltage-drop split, 5 ft allowance, seven-size and four-set limits, 20 C earth and 12 W/m2K film are all void). The Cascadia Wire Section 4 data are the data of record (Spec 26 05 19 1.3); the Meridian datasheet is not the basis of design and was not used.

Conflicts resolved: (a) voltage drop - NFPA 70 treats it only in informational notes; UFC 3-501-01 3-2.7.1 makes 3% feeder / 3% branch / 5% total mandatory and EDS-26 5.6 adopts those limits, so they govern (the superseded Rev 2 split was not used). (b) service entrance - UFC 3-501-01 3-2.3.3 and EDS-26 2.2 size SE-1 to the 2000 A main bus, not the 1600 A device. (c) motor, A/C, drive, elevator, fire-pump and transformer circuits are sized on 125% of the equipment current with the device rating not a floor (EDS-26 2.1.1), while ordinary feeders and branch circuits are sized to max(125% continuous load, device rating) (EDS-26 2.1). (d) termination temperature is the lower of the UFC 3-520-01 3-6.3.1 rule (60 C for devices of 100 A and below, 75 C above) and the listed lug rating (LP-1, WH-1, DW-1, SEC-1 and the lighting/receptacle outlets are 60 C) - the lower governs. (e) spare capacity (EDS-26 2.4): the service demand 1732 A + 15% = 1992 A is within the 2000 A main-bus sizing quantity; panel spare ampacity is provided by the procured bus and device ratings, which are fixed (Spec 26 24 16 2.6).

## 2. Environmental parameters and provenance

* Outdoor design dry-bulb **42 C**: highest daily normal maximum in the filed NOAA 1991-2020 record for USW00003145 (106.8 F = 41.56 C, 17-26 July), rounded up (EDS-26 5.4).
* Roof ambient **46 C** = 42 + 4 K (EDS-26 5.4); it agrees with the M-501-C roof row.
* Earth ambient **27.45 C** = annual mean of the 366 daily average normals (76.00 F = 24.45 C) + 3 K (EDS-26 5.3.2). The GEO-4210-T spring logging (22.1-28.4 C) was not used, per that report.
* Thermal resistivity of the earth and mutual-heating terms **0.6 K.m/W** - the fluidised thermal backfill that surrounds both encasements for the full trench width (GEO-4210-T 2.2, E-619 note). The native SP-SM design value 0.95 K.m/W (GEO 2.1) was considered and rejected. Encasement concrete 0.55 K.m/W (GEO 2.3). Load factor 100% (UFC 3-501-01 3-2.3.3).
* Solar irradiance 1030 W/m2 with absorptivity 0.6 and film coefficient 14 W/m2K on the sun-exposed roof tray CT-R1 (EDS-26 5.4); the solar term adds 14.05 K regardless of cable diameter.
* Interior ambients from M-501-C: 45 C for F-01, F-03 and the MCC-1 motor circuits B-11..B-15; 40 C (ceiling cavity, note 3) for every other circuit on E-611/E-612/E-616 including F-06/F-07 and the drive feeder F-09; 40 C for the Building 4212 shop circuits. The 25 C floor of UFC 3-520-01 3-6.3.2 never governs.

## 3. Ampacity basis

Every ampacity is calculated under engineering supervision as permitted by NFPA 70 (2023) 310.14(B) (EDS-26 5.1): raceway circuits from the Cascadia 90 C raceway column x k_a = sqrt((90-Ta)/60) x k_g = sqrt(3/N) (no circuit has more than three current-carrying conductors per raceway; all single-phase circuits are 208 V two-wire, no neutral is current-carrying); roof-tray circuits from the EDS-26 5.4 heat balance with solar gain and k_t = 1 + 0.06(N-3) for N = 18 current-carrying conductors in CT-R1; duct-bank circuits from the EDS-26 5.3 simplified Neher-McGrath formulation with mutual heating at operating current. Each corrected ampacity is then capped by the Cascadia table value at the termination temperature (raceway table for raceway and duct-bank circuits, free-air table for tray), EDS-26 5.5.

## 4. Voltage-drop budget

Start point: the **T-1 secondary lugs**, the point of government ownership (WRPU-2026-0412; UFC 3-501-01 3-2.7.4.2), at nominal 480 V with taps not credited. Limits (UFC 3-501-01 3-2.7.1, adopted by EDS-26 5.6): 3% cumulative to the end of any feeder chain, 3% on any branch circuit, 5% total at the load. Motor, A/C, drive and elevator feeders are treated as branch circuits for voltage drop (3-2.7.4.3.2 b-e). The count **does not restart at the low-voltage transformers** K-13 and the DP-3 transformer section: transformer drop is taken as zero and the percentage reached at the primary is carried to the secondary (3-2.7.4.5.3); the restart of 3-2.7 applies only to systems raised above 1000 V. Loads: device rating for feeders (3-2.7.4.3.1; SE-1 at the 1600 A main device rating, the EDS-26 2.3 reading stated on the schedule), 225 kVA (624.5 A at 208 V) for F-07 and 225 kVA + 6% (286.9 A at 480 V) for F-06, nameplate FLA/RLA/drive input for motor, A/C, drive and elevator circuits, total connected load for lighting and hard-wired appliance circuits, 80% of the 20 A device (16 A) for receptacle circuits. R is the 75 C a-c resistance; X is the steel-conduit value inside the building and the PVC value in duct and tray.

Feeder chains as spent (cumulative from T-1):

* MSB-1 (SE-1): 1.043%
* MCC-1 (SE-1+F-01): 2.575%
* DP-2 (SE-1+F-02): 1.407%
* K-13 primary (SE-1+F-02+F-06): 1.568%
* LP-1 (SE-1+F-02+F-06+F-07): 2.769%
* DP-3 (SE-1+F-05): 2.581%
* ATS-1 (SE-1+F-10): 2.777%

Allocation: SE-1 (6 x CU 500 kcmil) spends 1.043%. The critical chain is the 208 V lighting/appliance path SE-1 > F-02 > F-06 > K-13 > F-07 > LP-1, which reaches 2.769% at LP-1 and leaves 2.231% for the ten LP-1 branch circuits. Buying that budget back upstream (e.g. copper on F-07, or a larger F-02) costs more than the branch-circuit upsizing it would avoid, so the optimiser spent it on the feeder side and upsized the long LP-1 branches B-01, B-02, B-03, B-04, B-05, B-06, B-07, B-08 for voltage drop, with proportional EGCs (B-09 and B-10 stay at their ampacity size; B-09 is at the #4 terminal limit of DW-1). DP-3 is reached at 2.581%: F-05 is upsized for voltage drop so that the shop compressor circuit B-17, held at #6 by the CMP-1 terminal limit, closes at 4.928% total. MCC-1 is reached at 2.575%, ATS-1 at 2.777%. All 24 circuits that are branch circuits for voltage-drop purposes inherit the drop spent upstream of their panel: 10 at LP-1 (through K-13), 5 at MCC-1, 3 at DP-3 (through its transformer section), 3 at DP-2 (F-08, F-09, F-13) and 3 at MSB-1 (F-04, F-11, F-12); the fire pump F-03 also inherits SE-1. Fire pump (EDS-26 4.6.3): 2.71% at locked rotor (543 A, limit 15%) and 1.34% running at 96 A (limit 5%). Maximum cumulative drop at any load: 4.928%.

## 5. Service-entrance sizing decision

SE-1 is sized for the **2000 A ampacity of the MSB-1 main bus**, not the 1600 A main device (UFC 3-501-01 3-2.3.3; EDS-26 2.2), as an underground service calculated by Neher-McGrath at 100% load factor. With the 600 kcmil terminal limit of T-1 and MSB-1 and six terminals per phase, the cheapest compliant arrangement is **6 x CU 500 kcmil** in six ducts of DB-1, giving 348.1 A per set (>= 2000/6 = 333.3 A; capped by the 75 C raceway-table value 403 A), 2089 A in total. Five sets of 600 kcmil copper also carry 2000 A but force F-10 into copper and cost more overall; aluminium cannot carry the bus rating in this bank. Each SE-1 duct carries a 4/0 copper conductor sized from NFPA 70 Table 250.122 on the 1600 A main device, priced and counted as an EGC (EDS-26 5.7). Voltage drop at 1600 A is 1.043%.

## 6. Duct-bank assignment and thermal consequence

DB-1 (service duct bank, 12 x 5 in EPC-40, 3 x 4 at 9 in centres, centre 44.8 in deep) has **10 ducts available** to this scope: D11 is the owner's reserve and D12 carries the existing site-lighting feeder; both are left alone and carry no load in the calculation (EDS-26 5.3.4; Spec 26 05 33 3.2). SE-1 occupies D1, D2, D5, D6, D9, D10 and F-10 occupies D4, D8; D3, D7 are left empty. The arrangement was chosen by enumerating every assignment of the eight sets and keeping the one that maximises the smallest ampacity margin: SE-1 takes the two west columns, F-10 the east column top and middle, and the empty ducts D3/D7 separate them. Mutual heating at operating current (1732/6 = 288.7 A per SE-1 set, 432/2 = 216 A per F-10 set) raises the hottest SE-1 duct by 31.1 K and the hottest F-10 duct by 23.5 K (maximum in the bank 31.1 K). That is the trade made in the bank: SE-1 copper 500 kcmil keeps its own losses low enough that F-10 can be aluminium 500 kcmil (302.2 A >= 300 A per set), whereas a heavier SE-1 loading or a fuller bank would force F-10 to copper. DB-2 (4 x 4 in EPC-40, E4 reserved for communications) carries F-05 in E1, E2, E3; its own sets raise each other by up to 1.5 K.

## 7. Material and standardisation decisions

Aluminium (EDS-26 3.2, UFC 3-520-01 3-6.3.1) is used where it is #4 or larger and cheaper at equivalent ampacity - F-01, F-05, F-07, F-09, F-10, the roof-tray feeders and B-15 - since every termination is listed AL/CU; copper is kept for #6 and smaller, for EGCs, and where copper is cheaper or the duct bank needs it (SE-1). The project uses **5 distinct phase sizes larger than #1 AWG** (4/0, 300 kcmil, 400 kcmil, 500 kcmil, 600 kcmil), within the limit of five (EDS-26 3.4.2); restricting the set also fixes the 'ampacity-alone' size against which voltage-drop increases of the EGC are measured (EDS-26 5.7). Every conductor is within its terminal size and terminal count (equipment schedule), no circuit has more than six sets, and nothing smaller than 1/0 is paralleled. The roof tray carries 6 sets (N = 18 current-carrying conductors) with a sum of cable diameters of 12.21 in against 16.2 in permitted; two sets per chiller in aluminium 4/0 was cheaper than one copper set despite the larger tray derating. Interior raceway is rigid steel conduit at the Cascadia reference trade size (never smaller), checked for 40% fill and jam ratio. No conductor needed the UFC 3-520-01 3-6.3.2 termination reduction. The ambient correction of every circuit is based on the 90 C XHHW-2 rating, indicated on E-621 as UFC 3-520-01 3-6.3.1 requires, and is capped at the 60/75 C termination ampacity. F-05 is the only cable above 500 kcmil underground (UFC 3-501-01 3-2.10): DB-2 is existing with no manholes or handholes on the E-615 route, and the 7.6 in minimum bending radius of 600 kcmil XHHW-2 (8 x OD) is within standard EPC-40 sweeps.

## 8. Cost ledger

Priced at the Cascadia 2026 installed unit prices and the P-4210 unit price book (EDS-26 8). Total conductor installed (phase + EGC) is 40,888 ft, which reaches the 38,000 ft campus quantity break, so 6% is deducted from the installed conductor price (material and labour). Duct banks and the roof tray are existing at no cost.

| item | material USD | labour USD | installed USD |
|---|---:|---:|---:|
| Conductor incl. EGC, after 6% quantity break | 68,644.93 | 22,797.11 | 91,442.04 |
| Terminations | 5,105.26 | 4,504.06 | 9,609.32 |
| Rigid steel conduit | 21,406.08 | 26,183.52 | 47,589.60 |
| **Total** | **95,156.27** | **53,484.69** | **148,640.96** |

The line-by-line ledger is the cost_ledger sheet of calc_book.xlsx.

## 9. Interpretations and resolutions recorded for the reviewer

* **Service-entrance voltage-drop load** - EDS-26 2.3 accepts either reading of UFC 3-501-01 3-2.7.4.3.1/3-2.7.4.3.2; the 1600 A main-device rating was used and is stated on E-621 (note 1) and in the SE-1 schedule row.
* **Design current** in the schedule is the circuit total the conductors must carry (e.g. 2000 A for SE-1); the corrected ampacity column is per set, so the check is sets x ampacity >= design current. Transformer circuits use 125% of the 225 kVA rated current (338.3 A primary, 780.7 A secondary).
* **Motor currents** for sizing and voltage drop are the motor-schedule FLA/RLA/drive input values (identical to the connected-load column).
* **Ampacity-alone size for EGC scaling** (EDS-26 5.7) is the smallest size admissible on the circuit under 3.2 (material), 3.3 (terminals) and 3.4 (minimum size, the project's five standard large sizes, no parallel below 1/0), with the circuit's own material and number of sets. EGC increases are rounded up to the next standard size using both the engineering-data and the price-list circular-mil values, so no rounding direction can leave an EGC short (this is why B-08 carries a #4 and B-07 a #6 EGC).
* **Tray current-carrying conductors**: the ccc column of the four CT-R1 circuits shows N = 18, the count in the tray used for k_t; raceway circuits show 3 (three-phase) or 2 (208 V two-wire); duct-bank circuits show 3 per duct.
* **Tray fill** counts every single-conductor cable in CT-R1 including the EGCs (front sheet also gives the phase-only figure).
* **Spare capacity** (EDS-26 2.4) is satisfied by the procured, fixed bus and device ratings; it does not raise the conductor design currents above max(125% load, device rating).
* **Fire pump** voltage drop is shown in the schedule at the 96 A running current (vd_load_a); the 543 A locked-rotor check (limit 15%) is stated in the F-03 governing text and in section 4.
* **No termination reductions** (UFC 3-520-01 3-6.3.2) are used; every conductor is within the largest size and terminal count of the equipment at both ends.

## 10. Circuit summary

| circuit | selection | EGC | raceway/duct | design A | ampacity/set A | VD % | cumulative % | governing |
|---|---|---|---|---:|---:|---:|---:|---|
| B-01 | 1 x CU 8 | 8 | 1 in RSC | 20.0 | 40.0 | 1.8855 | 4.6547 | voltage drop: total VD 5% at load (next size 10 gives 5.75% with 2.77% upstream) (UFC 3-501-01 3-2.7.1); ampacity alone gives 12; EGC increased in cmil ratio (EDS-26 5.7; NFPA 70 250.122(B)) |
| B-02 | 1 x CU 6 | 6 | 1.25 in RSC | 20.0 | 54.0 | 1.6468 | 4.416 | voltage drop: total VD 5% at load (next size 8 gives 5.37% with 2.77% upstream) (UFC 3-501-01 3-2.7.1); ampacity alone gives 12; EGC increased in cmil ratio (EDS-26 5.7; NFPA 70 250.122(B)) |
| B-03 | 1 x CU 8 | 8 | 1 in RSC | 20.0 | 40.0 | 2.0025 | 4.7717 | voltage drop: branch-circuit VD 3% (next size 10 gives 3.17%) (UFC 3-501-01 3-2.7.1); ampacity alone gives 12; EGC increased in cmil ratio (EDS-26 5.7; NFPA 70 250.122(B)) |
| B-04 | 1 x CU 8 | 8 | 1 in RSC | 20.0 | 40.0 | 1.6523 | 4.4215 | voltage drop: total VD 5% at load (next size 10 gives 5.38% with 2.77% upstream) (UFC 3-501-01 3-2.7.1); ampacity alone gives 12; EGC increased in cmil ratio (EDS-26 5.7; NFPA 70 250.122(B)) |
| B-05 | 1 x CU 8 | 8 | 1 in RSC | 20.0 | 40.0 | 1.6751 | 4.4443 | voltage drop: total VD 5% at load (next size 10 gives 5.41% with 2.77% upstream) (UFC 3-501-01 3-2.7.1); ampacity alone gives 12; EGC increased in cmil ratio (EDS-26 5.7; NFPA 70 250.122(B)) |
| B-06 | 1 x CU 6 | 6 | 1.25 in RSC | 20.0 | 54.0 | 2.094 | 4.8632 | voltage drop: branch-circuit VD 3% (next size 8 gives 3.29%) (UFC 3-501-01 3-2.7.1); ampacity alone gives 12; EGC increased in cmil ratio (EDS-26 5.7; NFPA 70 250.122(B)) |
| B-07 | 1 x CU 6 | 6 | 1.25 in RSC | 40.0 | 54.0 | 1.9298 | 4.699 | voltage drop: branch-circuit VD 3% (next size 8 gives 3.07%) (UFC 3-501-01 3-2.7.1); ampacity alone gives 8; EGC increased in cmil ratio (EDS-26 5.7; NFPA 70 250.122(B)) |
| B-08 | 1 x CU 8 | 4 | 1 in RSC | 17.75 | 40.0 | 1.6342 | 4.4034 | voltage drop: total VD 5% at load (next size 10 gives 5.33% with 2.77% upstream) (UFC 3-501-01 3-2.7.1); ampacity alone gives 12; EGC increased in cmil ratio (EDS-26 5.7; NFPA 70 250.122(B)) |
| B-09 | 1 x CU 4 | 10 | 1.5 in RSC | 60.0 | 74.0 | 2.0854 | 4.8546 | ampacity: 60C termination limit (EDS-26 5.5, OCPD 60 A / lug 60C) 74 A >= 60.0 A |
| B-10 | 1 x CU 12 | 12 | 0.75 in RSC | 20.0 | 22.0 | 1.6191 | 4.3883 | ampacity: 60C termination limit (EDS-26 5.5, OCPD 20 A / lug 60C) 22 A >= 20.0 A |
| B-11 | 1 x CU 4 | 6 | 1.5 in RSC | 81.25 | 85.7 | 0.5262 | 3.1013 | ampacity: 90C raceway ampacity x k_a(45C) 85.7 A >= 81.2 A (EDS-26 5.2) |
| B-12 | 1 x CU 4 | 6 | 1.5 in RSC | 81.25 | 85.7 | 0.6446 | 3.2197 | ampacity: 90C raceway ampacity x k_a(45C) 85.7 A >= 81.2 A (EDS-26 5.2) |
| B-13 | 1 x CU 6 | 8 | 1.25 in RSC | 50.0 | 54.0 | 0.3027 | 2.8778 | ampacity: 60C termination limit (EDS-26 5.5, OCPD 70 A / lug 75C) 54 A >= 50.0 A |
| B-14 | 1 x CU 6 | 8 | 1.25 in RSC | 50.0 | 54.0 | 0.3657 | 2.9408 | ampacity: 60C termination limit (EDS-26 5.5, OCPD 70 A / lug 75C) 54 A >= 50.0 A |
| B-15 | 1 x AL 3 | 8 | 1.5 in RSC | 65.0 | 65.0 | 1.1995 | 3.7747 | ampacity: 60C termination limit (EDS-26 5.5, OCPD 90 A / lug 75C) 65 A >= 65.0 A |
| B-16 | 1 x CU 2 | 8 | 2 in RSC | 100.0 | 102.0 | 1.6393 | 4.2203 | ampacity: 60C termination limit (EDS-26 5.5, OCPD 100 A / lug 75C) 102 A >= 100.0 A |
| B-17 | 1 x CU 6 | 10 | 1.25 in RSC | 43.25 | 54.0 | 2.3469 | 4.928 | ampacity: 60C termination limit (EDS-26 5.5, OCPD 60 A / lug 75C) 54 A >= 43.2 A |
| B-18 | 1 x CU 8 | 8 | 1 in RSC | 20.0 | 40.0 | 1.966 | 4.547 | voltage drop: branch-circuit VD 3% (next size 10 gives 3.11%) (UFC 3-501-01 3-2.7.1); ampacity alone gives 12; EGC increased in cmil ratio (EDS-26 5.7; NFPA 70 250.122(B)) |
| F-01 | 2 x AL 500 kcmil | 1 | 4 in RSC | 600.0 | 306.6 | 1.5318 | 2.5751 | ampacity: 90C raceway ampacity x k_a(45C) 306.6 A >= 300.0 A (EDS-26 5.2); 2 parallel sets (terminals per phase 2; EDS-26 3.4.4) |
| F-02 | 1 x CU 500 kcmil | 3 | 4 in RSC | 400.0 | 403.0 | 0.3632 | 1.4065 | ampacity: 75C termination limit (EDS-26 5.5, OCPD 400 A / lug 75C) 403 A >= 400.0 A |
| F-03 | 1 x CU 1 | 6 | 2 in RSC | 120.0 | 134.2 | 0.2952 | 1.3386 | ampacity: 90C raceway ampacity x k_a(45C) 134.2 A >= 120.0 A (EDS-26 5.2); fire pump VD checked per EDS-26 4.6.3: 1.34% running, 2.71% locked rotor |
| F-04 | 2 x AL 4/0 | 3 | tray CT-R1 | 310.0 | 171.9 | 1.2471 | 2.2905 | ampacity: sun-exposed tray heat balance (46C, solar, k_t N=18) 171.9 A >= 155.0 A (EDS-26 5.4); 2 parallel sets (terminals per phase 2; EDS-26 3.4.4) |
| F-05 | 3 x AL 600 kcmil | 3/0 | E1;E2;E3 | 400.0 | 336.0 | 1.5377 | 2.5811 | voltage drop: VD budget allocation (5% total at downstream loads): with the next size 500 kcmil (1.73%) B-17 would reach 5.12% total (already at the 6 terminal limit) (UFC 3-501-01 3-2.7.1); ampacity alone gives 4/0; EGC increased in cmil ratio (EDS-26 5.7; NFPA 70 250.122(B)); largest conductor accepted by terminals (600 kcmil) (EDS-26 3.3); 3 parallel sets (terminals per phase 3; EDS-26 3.4.4) |
| F-06 | 1 x CU 400 kcmil | 3 | 3.5 in RSC | 338.29 | 353.0 | 0.1614 | 1.568 | ampacity: 75C termination limit (EDS-26 5.5, OCPD 400 A / lug 75C) 353 A >= 338.3 A |
| F-07 | 3 x AL 500 kcmil | 1/0 | 4 in RSC | 780.67 | 263.0 | 1.2012 | 2.7692 | ampacity: 60C termination limit (EDS-26 5.5, OCPD 800 A / lug 60C) 263 A >= 260.2 A; 3 parallel sets (terminals per phase 3; EDS-26 3.4.4) |
| F-08 | 1 x AL 4/0 | 6 | tray CT-R1 | 151.25 | 171.9 | 0.6606 | 2.0672 | ampacity: sun-exposed tray heat balance (46C, solar, k_t N=18) 171.9 A >= 151.2 A (EDS-26 5.4) |
| F-09 | 1 x AL 300 kcmil | 4 | 3 in RSC | 211.25 | 230.0 | 0.9687 | 2.3753 | ampacity: 75C termination limit (EDS-26 5.5, OCPD 225 A / lug 75C) 230 A >= 211.2 A |
| F-10 | 2 x AL 500 kcmil | 1 | D4;D8 | 600.0 | 302.2 | 1.734 | 2.7774 | ampacity: Neher-McGrath duct-bank ampacity incl. mutual heating 302.2 A >= 300.0 A (EDS-26 5.3); 2 parallel sets (terminals per phase 2; EDS-26 3.4.4) |
| F-11 | 1 x CU 3 | 6 | 1.5 in RSC | 97.5 | 99.0 | 1.1622 | 2.2056 | ampacity: 75C termination limit (EDS-26 5.5, OCPD 125 A / lug 75C) 99 A >= 97.5 A |
| F-12 | 2 x AL 4/0 | 3 | tray CT-R1 | 310.0 | 171.9 | 1.5767 | 2.6201 | ampacity: sun-exposed tray heat balance (46C, solar, k_t N=18) 171.9 A >= 155.0 A (EDS-26 5.4); 2 parallel sets (terminals per phase 2; EDS-26 3.4.4) |
| F-13 | 1 x AL 4/0 | 6 | tray CT-R1 | 151.25 | 171.9 | 1.1126 | 2.5192 | ampacity: sun-exposed tray heat balance (46C, solar, k_t N=18) 171.9 A >= 151.2 A (EDS-26 5.4) |
| SE-1 | 6 x CU 500 kcmil | 4/0 | D1;D2;D5;D6;D9;D10 | 2000.0 | 348.1 | 1.0434 | 1.0434 | service entrance sized to MSB-1 main bus 2000 A (UFC 3-501-01 3-2.3.3; EDS-26 2.2); ampacity: Neher-McGrath duct-bank ampacity incl. mutual heating 348.1 A >= 333.3 A (EDS-26 5.3); VD load = 1600 A main-device rating (EDS-26 2.3 reading of UFC 3-501-01 3-2.7.4.3.1); 6 parallel sets (terminals per phase 6; EDS-26 3.4.4) |
