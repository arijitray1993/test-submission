# BASIS OF ESTIMATE - DATA HALL 1 DEVICE TAKEOFF AND PRICED BILL (ec_0205_d100)

Meridian Data Center Phase 1, Data Hall 1. Drawings issued for construction 2026-07-24, revision 2 (Addendum 1, 2026-07-27) on every sheet; Addendum No. 02 dated 2026-08-07.

## 1. Counting conventions applied

| clause | convention | how applied |
|---|---|---|
| C1 / E-05 (E-001 legend note 8; general sheet note 3 on E-201..E-204) | a device is counted once | Match line A (x = 14.4 m, tile column 24) and match line B (y = 14.4 m, tile row 25) divide E-201 (SW), E-202 (SE), E-203 (NW), E-204 (NE). Each sheet also draws a 1.8 m band on the far side of each match line in grey for reference; the background screen extends 1.8 m onto the near side too, so the match line - not the screen - was used as the boundary. Every symbol was located in hall coordinates (tile grid on each sheet, 600 mm tiles, origin SW internal corner) and counted once, on the sheet whose side of the match line it stands on (those are the symbols drawn in full black; the grey ones are the reference copies). Enlarged-plan frame overlaps (about 0.5 m between consecutive frames) were checked by coordinate: no device is drawn in two frames. |
| C2 (E-001 legend note 1) | the E-001 legend is the only definition of a symbol | Every symbol on every plan was template-matched against the 17 E-001 legend glyphs (legend note 2: same plotted size) and visually confirmed. |
| C3 / E-04 (legend note 5) | non-legend symbol carries no quantity | See section 4. |
| C4 / E-03 (legend note 4) | legend entry with no instance = 0 | R8 and F6 have no instance on any plan: quantity 0. |
| C5 / E-06 (keynotes; T-002 note 3) | keyed notes are part of the drawing | Keynotes <1>-<4> provided by census of geometry on other sheets (section 3). |
| C6 / E-07 (revision blocks; ADD-02) | latest issue governs | ADD-02 (2026-08-07) postdates revision 2 (2026-07-27) of every sheet and governs for item 02-1; the sheets govern for everything else. |
| C7 / E-08 (general sheet note 5; E-231 note 1) | enlarged areas are counted from the enlarged plans | ELECTRICAL / ENTRY (E-231 frames 1-6, E-232 frame 7) and PDU GALLERY (E-232 frames 8-10, E-233 frames 11-14), all at 1:20, counted from the frames. |
| C8 / E-11 | condition from location | Section 5. |
| C9 / E-10 | split by condition | locations.csv and bom.csv carry the same (type mark, condition) counts. |

## 2. Sheets each type mark was counted from, and the takeoff

| type mark | description | quantity | counted from (sheet: count) | source split |
|---|---|---|---|---|
| R1 | RECEPTACLE, DUPLEX, 20 A, 125 V, WALL-MOUNTED | 51 | E-201: 7; E-202: 14; E-203: 4; E-204: 4; E-231: 9; E-232: 7; E-233: 6 | drawn: 51 |
| R2 | RECEPTACLE, QUADRAPLEX, 20 A, 125 V, WALL-MOUNTED | 8 | E-201: 2; E-232: 3; E-233: 3 | ADD-02 item 02-1: 2; drawn: 6 |
| R3 | RECEPTACLE, DUPLEX, GROUND-FAULT CIRCUIT INTERRUPTER, 20 A | 8 | E-231: 3; E-232: 3; E-233: 2 | drawn: 8 |
| R4 | RECEPTACLE, DUPLEX, ISOLATED GROUND, 20 A, 125 V | 6 | E-202: 4; E-233: 2 | drawn: 6 |
| R5 | RECEPTACLE, DUPLEX, WEATHER-RESISTANT, WITH EXTRA-DUTY WHILE-IN-USE COVER | 32 | E-201: 20; E-202: 8; E-203: 2; E-204: 2 | drawn: 4; keynote <2>: 28 |
| R6 | RECEPTACLE, DUPLEX, EMERGENCY BRANCH, 20 A, 125 V | 4 | E-201: 1; E-203: 1; E-231: 1; E-233: 1 | drawn: 4 |
| R7 | BOX, OUTLET, FLOOR, TWO-GANG, IN ACCESS FLOOR | 6 | E-202: 5; E-204: 1 | keynote <3>: 6 |
| R8 | RECEPTACLE, SINGLE, 50 A, 250 V, WALL-MOUNTED | 0 | - | no instance on any plan |
| J1 | BOX, JUNCTION, 100 MM SQUARE, CONCEALED | 38 | E-201: 11; E-202: 7; E-203: 7; E-204: 8; E-231: 4; E-232: 1 | drawn: 38 |
| P1 | BOX, PULL, 300 X 300 X 150 MM, SURFACE | 7 | E-201: 1; E-202: 1; E-203: 1; E-231: 2; E-232: 1; E-233: 1 | drawn: 7 |
| F1 | APPLIANCE, NOTIFICATION, VISIBLE, WALL-MOUNTED | 12 | E-211: 12 | keynote <1>: 8; keynote <4>: 4 |
| F2 | APPLIANCE, NOTIFICATION, AUDIBLE-VISIBLE, WALL-MOUNTED | 4 | E-211: 1; E-231: 2; E-233: 1 | drawn: 4 |
| F3 | STATION, MANUAL, FIRE ALARM, WALL-MOUNTED | 3 | E-211: 2; E-233: 1 | drawn: 3 |
| F4 | DETECTOR, SMOKE, PHOTOELECTRIC, CEILING-MOUNTED | 6 | E-211: 6 | drawn: 6 |
| F5 | DETECTOR, SMOKE, PHOTOELECTRIC, IN ACCESS FLOOR | 30 | E-211: 25; E-232: 2; E-233: 3 | drawn: 30 |
| F6 | DETECTOR, SMOKE, PROJECTED BEAM, WALL-MOUNTED | 0 | - | no instance on any plan |
| D1 | DETECTOR, SMOKE, DUCT, FURNISHED UNDER DIVISION 23 | 27 | E-211: 25; E-231: 1; E-232: 1 | drawn: 27 |

Notes: E-211 general note 3 - ceiling (F4) and under-floor (F5) detectors are shown on E-211 only; the F5 layout continues into the PDU gallery on the enlarged plans (x = 24.75 m, 5 detectors). F5 is drawn on the plans as a dashed circle with a horizontal bar (legend glyph F5, dashed outline); five F5 on E-211 sit under cabinet outlines and were confirmed visually. Keynote devices are listed against the sheet carrying the keynote for their area: F1 (keynotes <1>, <4>) on E-211; R5 (<2>) and R7 (<3>) on the E-20x sheet whose quadrant contains the CRAH unit / PDU.

## 3. Governing issue, addendum and keyed notes

**Governing issue.** All sheets: revision 1 issued for construction 2026-07-24, revision 2 Addendum 1 2026-07-27 (clouds). ADD-02 is dated 2026-08-07, after revision 2, so it governs for what it describes (convention C6).

**ADD-02 item 02-1** - the cloud tagged revision 2 on E-201 (the plan covering grid bay A1; cloud spans x = -0.2 to 5.4 m, y = below the south wall to 8.3 m). The duplex receptacles (R1) inside it are deleted:

- R1 deleted at x = 3.36 m, y = 0.38 m (bay A1)
- R1 deleted at x = 4.33 m, y = 1.78 m (bay A1)
- R1 deleted at x = 4.33 m, y = 4.79 m (bay A1)
- R1 deleted at x = 4.33 m, y = 7.19 m (bay A1)

One quadraplex receptacle (R2) is added at each of the first and second deleted positions measured from the south: x = 3.36, y = 0.38 and x = 4.33, y = 1.78 (both bay A1). Net: R1 -4, R2 +2.

**Keyed notes (provided although not drawn; counted once even where the same keynote appears on several sheets):**

- <1> (E-201..E-204 and E-211): one visible notification appliance (F1) at each structural column bay on the north and south walls. Census: structural grid lines 1, 2, 3 give 4 bay columns (west wall-1, 1-2, 2-3, 3-east wall) on each of the north and south walls = **8 F1**. Condition: the note names the north and south walls, P2 200 mm concrete masonry on A-102 -> DRY-MASONRY.
- <4> (E-211): one visible notification appliance (F1) on the wall at each exit door. Census: A-102 door schedule, EGRESS = YES: D-01, D-02 (in P-R1, drawn in the P3 two-hour partition), D-04 (W-W, west wall P1), D-05 (W-E, east wall P1) = **4 F1**; D-03 (egress NO) excluded. Conditions: D-01, D-02 RATED-2HR; D-04, D-05 DRY-STUD.
- <2> (E-201..E-204): one weather-resistant receptacle with extra-duty while-in-use cover (R5) within 7.6 m of each CRAH unit. Census of CRAH geometry on A-101 / M-101 (and A-102 rev 2 "IN-ROW CRAH UNITS ADDED"): perimeter CRAH-01..04 = 4, in-row CRAH-A01..F04 = 24 (4 in each of rows A-F) = **28 R5**. The A-601 CRAH schedule (4 + 12) and the M-101 consumer table (2 per row) predate the in-row additions and state quantities; the drawn geometry governs. Condition: the note names no wall -> DRY-STUD.
- <3> (E-201..E-204): one floor box in the access floor (R7) at each PDU. Census: PDU-01..06 on A-101 / E-101 (6 drawn on A-102) = **6 R7**. Condition: E-002 mounting IN ACCESS FLOOR -> ACCESS-FLOOR.

## 4. Unresolved symbols (not in the E-001 legend - no quantity carried anywhere)

| sheet | location | grid bay | hall coordinates | description |
|---|---|---|---|---|
| E-232 | PDU GALLERY - E-232 detail 9 (enlarged plan, 1:20) | A4 | x = 25.20 m, y = 5.28 m (tile BQ09, margin convention); stacked directly above/below a drawn R1 | square with an inscribed diamond (rotated square). Not R7 (R7 is a square with an inscribed circle) and not any other legend glyph; not identified, carried as unresolved with no quantity in takeoff.csv, locations.csv or bom.csv. |
| E-233 | PDU GALLERY - E-233 detail 13 (enlarged plan, 1:20) | C4 | x = 25.20 m, y = 18.72 m (tile BQ32, margin convention); stacked directly above/below a drawn R1 | square with an inscribed diamond (rotated square). Not R7 (R7 is a square with an inscribed circle) and not any other legend glyph; not identified, carried as unresolved with no quantity in takeoff.csv, locations.csv or bom.csv. |

No other non-legend symbol was found on E-201, E-202, E-203, E-204, E-211, E-231, E-232 or E-233. The under-floor detectors on E-211 and the PDU-gallery details are drawn as a dashed circle with a horizontal bar - the F5 glyph geometry (same size, same bar) - with a coarser dash than the E-001 swatch; they are carried as F5: E-211 general note 3 says under-floor detectors are shown on that sheet, and their layout (4.5 m x 4.8 m, about 21 m2 per detector) is the UFGS 28 31 76 3.2.5 raised-floor coverage restated in 28 31 76 3.2.

## 5. Condition split and where it came from

Rules (criteria C8 plus the four conventions in the brief): (1) a condition E-002 sets takes precedence - R4 IG (isolated ground), R6 EMERGENCY (BRANCH = EMERGENCY), R7 and F5 ACCESS-FLOOR (mounting IN ACCESS FLOOR), F4 CEILING (mounting CEILING), D1 CEILING by convention; (2) otherwise a device inside an area hatched DAMP on A-102 is DAMP - the entry vestibule (x 0-1.5 m, y 0-8.0 m) and the four perimeter CRAH condensate aprons (CRAH footprint + 0.6 m: x 0-2.4, 8.4-10.8, 16.2-18.6, 24.6-27.0 m; y -0.6 to 1.5 m); boundary treated as inside; (3) otherwise the construction of the nearest A-102 wall measured to its centreline - west wall P1 steel stud (centreline x = 0.075 m) DRY-STUD, P3 two-hour partition (x = 1.65 m) RATED-2HR, east wall P1 (x = 26.925 m) DRY-STUD, north wall P2 masonry (y = 23.85 m) and south wall P2 (y = 0.15 m) DRY-MASONRY; (4) keynote devices drawn nowhere take the wall the note names (door: the wall the door is in) or DRY-STUD.

| type mark | condition | count |
|---|---|---|
| R1 | DAMP | 3 |
| R1 | DRY-MASONRY | 19 |
| R1 | DRY-STUD | 19 |
| R1 | RATED-2HR | 10 |
| R2 | DRY-MASONRY | 2 |
| R2 | DRY-STUD | 6 |
| R3 | DAMP | 1 |
| R3 | DRY-STUD | 7 |
| R4 | IG | 6 |
| R5 | DAMP | 4 |
| R5 | DRY-STUD | 28 |
| R6 | EMERGENCY | 4 |
| R7 | ACCESS-FLOOR | 6 |
| J1 | DAMP | 2 |
| J1 | DRY-MASONRY | 18 |
| J1 | DRY-STUD | 5 |
| J1 | RATED-2HR | 13 |
| P1 | DAMP | 3 |
| P1 | DRY-STUD | 3 |
| P1 | RATED-2HR | 1 |
| F1 | DRY-MASONRY | 8 |
| F1 | DRY-STUD | 2 |
| F1 | RATED-2HR | 2 |
| F2 | DAMP | 1 |
| F2 | DRY-STUD | 1 |
| F2 | RATED-2HR | 2 |
| F3 | DRY-MASONRY | 1 |
| F3 | DRY-STUD | 1 |
| F3 | RATED-2HR | 1 |
| F4 | CEILING | 6 |
| F5 | ACCESS-FLOOR | 30 |
| D1 | CEILING | 27 |

Per-device location, bay, condition and reason are reproduced in locations.csv (aggregated by sheet, type, bay, condition). Boundary note: the E-201 pull box at x = 2.40 m, y = 0.90 m stands on the east edge of the CRAH-01 condensate apron (and is equidistant, 0.75 m, from the P3 and south-wall centrelines); it is carried as DAMP (inside the hatched area, boundary inclusive).

## 6. Assembly chosen for each (type mark, condition) pair and the clause that permits it

| type mark | condition | assembly (catalogue items x per device) | permitting clause |
|---|---|---|---|
| R1 | DAMP | DEV-GFCI-20 x1 | 26 20 00 2.3, 2.5; UFGS 26 20 00 2.12.2 and 2.9 h (wet-listed GFCI receptacle; extra-duty WIU hood, cast box and gasketed plate not in catalogue - no line); extra-duty while-in-use hood required - not in catalogue, no line carried |
| R1 | DRY-MASONRY | BOX-MAS-4KO x1 + DEV-DUP-20 x1 | 26 05 33 2.3 and 3.2 (masonry box, no plaster ring) |
| R1 | DRY-STUD | BOX-4SQ-21 x1 + RING-1G-58 x1 + DEV-DUP-20 x1 | 26 05 33 2.2 and 3.2 (4 in square box + raised plaster ring); UFGS 26 20 00 2.9 |
| R1 | RATED-2HR | BOX-4SQ-21 x1 + ACC-FIRESTOP-PAD x1 + DEV-DUP-20 x1 | 26 05 33 2.4 and 3.2; 07 84 00 2.1, 3.1 (box of the stud assembly + listed intumescent pad); UFC 3-520-01 3-6.1 (300 mm offset) |
| R2 | DRY-MASONRY | BOX-MAS-4KO x1 + DEV-DUP-20 x2 | 26 05 33 2.3 and 3.2 (masonry box, no plaster ring) |
| R2 | DRY-STUD | BOX-4SQ-21 x1 + RING-1G-58 x1 + DEV-DUP-20 x2 | 26 05 33 2.2 and 3.2 (4 in square box + raised plaster ring); UFGS 26 20 00 2.9 |
| R3 | DAMP | DEV-GFCI-20 x1 | 26 20 00 2.3, 2.5; UFGS 26 20 00 2.12.2 and 2.9 h (wet-listed GFCI receptacle; extra-duty WIU hood, cast box and gasketed plate not in catalogue - no line); extra-duty while-in-use hood required - not in catalogue, no line carried |
| R3 | DRY-STUD | BOX-4SQ-21 x1 + RING-1G-58 x1 + DEV-GFCI-20 x1 | 26 05 33 2.2 and 3.2 (4 in square box + raised plaster ring); UFGS 26 20 00 2.9 |
| R4 | IG | BOX-4SQ-21 x1 + RING-1G-58 x1 + ACC-IG-CONDUCTOR x1 + DEV-IG-20 x1 | 26 20 00 2.2; E-002 note 3; NFPA 70 250.146(D) (stud assembly + one insulated EGC per device) |
| R5 | DAMP | DEV-GFCI-20 x1 | 26 20 00 2.3, 2.5; UFGS 26 20 00 2.12.2 and 2.9 h (wet-listed GFCI receptacle; extra-duty WIU hood, cast box and gasketed plate not in catalogue - no line); extra-duty while-in-use hood required - not in catalogue, no line carried |
| R5 | DRY-STUD | BOX-4SQ-21 x1 + RING-1G-58 x1 + DEV-GFCI-20 x1 | 26 05 33 2.2 and 3.2 (4 in square box + raised plaster ring); UFGS 26 20 00 2.9; extra-duty while-in-use hood required - not in catalogue, no line carried |
| R6 | EMERGENCY | BOX-4SQ-21 x1 + DEV-DUP-20 x1 | 26 20 00 3.2; E-002 note 2 (separate box) |
| R7 | ACCESS-FLOOR | BOX-FLOOR-2G x1 | 26 05 33 2.6 (listed recessed floor box, no ring); UFGS 28 31 76 3.2.5 (access-floor detector on 100 mm box) |
| J1 | DAMP | DEV-GFCI-20 x1 | 26 20 00 2.3, 2.5; UFGS 26 20 00 2.12.2 and 2.9 h (wet-listed GFCI receptacle; extra-duty WIU hood, cast box and gasketed plate not in catalogue - no line); 26 05 33 2.8 (junction box: flat blank cover, no plaster ring); extra-duty while-in-use hood required - not in catalogue, no line carried |
| J1 | DRY-MASONRY | BOX-MAS-4KO x1 + CVR-4SQ-BLANK x1 | 26 05 33 2.3 and 3.2 (masonry box, no plaster ring); 26 05 33 2.8 (junction box: flat blank cover, no plaster ring) |
| J1 | DRY-STUD | BOX-4SQ-21 x1 + CVR-4SQ-BLANK x1 | 26 05 33 2.2 and 3.2 (4 in square box + raised plaster ring); UFGS 26 20 00 2.9; 26 05 33 2.8 (junction box: flat blank cover, no plaster ring) |
| J1 | RATED-2HR | BOX-4SQ-21 x1 + ACC-FIRESTOP-PAD x1 + CVR-4SQ-BLANK x1 | 26 05 33 2.4 and 3.2; 07 84 00 2.1, 3.1 (box of the stud assembly + listed intumescent pad); UFC 3-520-01 3-6.1 (300 mm offset); 26 05 33 2.8 (junction box: flat blank cover, no plaster ring) |
| P1 | DAMP | DEV-GFCI-20 x1 | 26 20 00 2.3, 2.5; UFGS 26 20 00 2.12.2 and 2.9 h (wet-listed GFCI receptacle; extra-duty WIU hood, cast box and gasketed plate not in catalogue - no line); 26 05 33 2.7 (pull box is box and cover in one); extra-duty while-in-use hood required - not in catalogue, no line carried |
| P1 | DRY-STUD | BOX-PULL-12 x1 | 26 05 33 2.2 and 3.2 (4 in square box + raised plaster ring); UFGS 26 20 00 2.9; 26 05 33 2.7 (pull box is box and cover in one) |
| P1 | RATED-2HR | BOX-PULL-12 x1 + ACC-FIRESTOP-PAD x1 | 26 05 33 2.4 and 3.2; 07 84 00 2.1, 3.1 (box of the stud assembly + listed intumescent pad); UFC 3-520-01 3-6.1 (300 mm offset); 26 05 33 2.7 (pull box is box and cover in one) |
| F1 | DRY-MASONRY | BOX-MAS-4KO x1 + APP-STROBE-120 x1 | 26 05 33 2.3 and 3.2 (masonry box, no plaster ring) |
| F1 | DRY-STUD | BOX-4SQ-21 x1 + RING-1G-58 x1 + APP-STROBE-120 x1 | 26 05 33 2.2 and 3.2 (4 in square box + raised plaster ring); UFGS 26 20 00 2.9 |
| F1 | RATED-2HR | BOX-4SQ-21 x1 + ACC-FIRESTOP-PAD x1 + APP-STROBE-120 x1 | 26 05 33 2.4 and 3.2; 07 84 00 2.1, 3.1 (box of the stud assembly + listed intumescent pad); UFC 3-520-01 3-6.1 (300 mm offset) |
| F2 | DAMP | APP-HS-24 x1 + DEV-GFCI-20 x1 | 26 20 00 2.3, 2.5; UFGS 26 20 00 2.12.2 and 2.9 h (wet-listed GFCI receptacle; extra-duty WIU hood, cast box and gasketed plate not in catalogue - no line); extra-duty while-in-use hood required - not in catalogue, no line carried |
| F2 | DRY-STUD | BOX-4SQ-21 x1 + RING-1G-58 x1 + APP-HS-24 x1 | 26 05 33 2.2 and 3.2 (4 in square box + raised plaster ring); UFGS 26 20 00 2.9 |
| F2 | RATED-2HR | BOX-4SQ-21 x1 + ACC-FIRESTOP-PAD x1 + APP-HS-24 x1 | 26 05 33 2.4 and 3.2; 07 84 00 2.1, 3.1 (box of the stud assembly + listed intumescent pad); UFC 3-520-01 3-6.1 (300 mm offset) |
| F3 | DRY-MASONRY | BOX-MAS-4KO x1 + APP-PULL x1 | 26 05 33 2.3 and 3.2 (masonry box, no plaster ring) |
| F3 | DRY-STUD | BOX-4SQ-21 x1 + RING-1G-58 x1 + APP-PULL x1 | 26 05 33 2.2 and 3.2 (4 in square box + raised plaster ring); UFGS 26 20 00 2.9 |
| F3 | RATED-2HR | BOX-4SQ-21 x1 + ACC-FIRESTOP-PAD x1 + APP-PULL x1 | 26 05 33 2.4 and 3.2; 07 84 00 2.1, 3.1 (box of the stud assembly + listed intumescent pad); UFC 3-520-01 3-6.1 (300 mm offset) |
| F4 | CEILING | BOX-4SQ-21 x1 + DET-PHOTO x1 | 26 05 33 2.9; UFGS 28 31 76 3.2.5 (100 mm box + ceiling detector, no ring); 28 31 76 1.3 for D1 (installation only) |
| F5 | ACCESS-FLOOR | BOX-4SQ-21 x1 + DET-PHOTO-UF x1 | 26 05 33 2.6 (listed recessed floor box, no ring); UFGS 28 31 76 3.2.5 (access-floor detector on 100 mm box) |
| D1 | CEILING | BOX-4SQ-21 x1 + INS-DUCT-DET x1 | 26 05 33 2.9; UFGS 28 31 76 3.2.5 (100 mm box + ceiling detector, no ring); 28 31 76 1.3 for D1 (installation only) |

Device selections: specification-grade 20 A duplex DEV-DUP-20 (26 20 00 2.1) for R1, R6 and two per R2 quadraplex; DEV-GFCI-20 (UL wet-location listed, integral GFCI, weather-resistant) for R3, R5 and every DAMP receptacle; DEV-IG-20 for R4; APP-STROBE-120 for F1; APP-HS-24 horn-strobe for F2; APP-PULL double action for F3 (28 31 76 2.2); DET-PHOTO for F4; DET-PHOTO-UF for F5 (28 31 76 2.3, listed for the access floor plenum); INS-DUCT-DET for D1 - the duct detector is furnished under Division 23 and is not carried as material (28 31 76 1.3). Not used: RING-1G-ADJ (a mud ring, not a raised plaster ring), BOX-FLOOR-2G-OG (on-grade box; the hall has an access floor), DEV-DUP-20-HD, DEV-TR-20, DEV-GFCI-TR-20, BOX-4SQ-15, BOX-4SQ-BRKT, BOX-MAS-6KO, BOX-PULL-12-HC, APP-BS-120.

**While-in-use hood.** Division 26 20 00 2.3 and UFGS 26 20 00 2.12.2 require, for every R5 and every DAMP device, a cast metal box with a gasketed, hinged, lockable, weather-resistant EXTRA-DUTY rated while-in-use hood, and 2.9 h requires a gasketed wet-location plate. The catalogue carries no while-in-use hood (or cast box / gasketed plate); per the brief this is stated here and no line is carried for it.

**Back-to-back boxes (E-14).** Boxes on opposite faces of the P3 two-hour partition are to be offset at least 300 mm (UFC 3-520-01 3-6.1); every box in the P3 partition carries ACC-FIRESTOP-PAD (07 84 00 3.1).

**Mounting heights (E-15, E-002 note 1, UFGS 26 20 00 3.1.10, measured to the centre of the device):** R1-R6 460 mm AFF; R7 flush in floor; R8 1200 mm; J1, P1 2600 mm; F1, F2, F6 2286 mm; F3 1067 mm (to operating handle, within 1.5 m of the exit door it serves); F4 ceiling; F5 in access floor; D1 at unit.

## 7. Pricing, spare stock and cartons

- Required quantity of each catalogue item = sum over (type mark, condition) pairs of device count x multiplicity in the chosen assembly (attribution rows in bom.csv).
- Unit price = the price list rate for the band the item's own REQUIRED quantity falls in, using each line's printed break quantities (price list "The list"; criteria 4.3). That price applies to the attribution rows and to the purchase row alike, before spare and carton rounding.
- Extended price = quantity x unit price on every row. **Basket total = sum of attribution extended prices = $18168.14.**
- Quantity purchased = required + 5 percent Owner spare stock (OPR 4), rounded UP to the next whole carton at the carton quantity printed on the price list: purchased = ceil(required x 1.05 / carton) x carton. Cartons and spare are constraints on what is bought, not terms in the price of the work. Purchase rows carry (PURCHASE) / (STOCK); their extended value (purchase cost, not the basket) is $21467.05.

| line item | required | band rate | carton | purchased |
|---|---|---|---|---|
| ACC-FIRESTOP-PAD | 29 | 94.06 | 10 | 40 |
| ACC-IG-CONDUCTOR | 6 | 3.36 | 10 | 10 |
| APP-HS-24 | 4 | 74.35 | 1 | 5 |
| APP-PULL | 3 | 81.06 | 1 | 4 |
| APP-STROBE-120 | 12 | 299.44 | 1 | 13 |
| BOX-4SQ-21 | 170 | 3.18 | 25 | 200 |
| BOX-FLOOR-2G | 6 | 104.36 | 1 | 7 |
| BOX-MAS-4KO | 48 | 22.02 | 25 | 75 |
| BOX-PULL-12 | 4 | 34.75 | 1 | 5 |
| CVR-4SQ-BLANK | 36 | 0.81 | 10 | 40 |
| DET-PHOTO | 6 | 116.39 | 1 | 7 |
| DET-PHOTO-UF | 30 | 133.02 | 1 | 32 |
| DEV-DUP-20 | 68 | 5.18 | 10 | 80 |
| DEV-GFCI-20 | 49 | 20.03 | 10 | 60 |
| DEV-IG-20 | 6 | 24.25 | 10 | 10 |
| INS-DUCT-DET | 27 | 98.15 | 1 | 29 |
| RING-1G-58 | 70 | 1.09 | 25 | 75 |

**BASKET TOTAL (attribution rows): $18168.14**

## 8. Grid bays and coordinates

Hall coordinates are metres from the south-west internal corner (x east, y north) on the 600 mm access-floor tile grid printed in every plan margin (AA = 0, AF = 3.0 m ... BT = 27.0 m; row 1 = 0, row 6 = 3.0 m ... row 41 = 24.0 m). Structural grid lines 1, 2, 3 are at x = 7.5, 14.7, 21.9 m and A, B, C at y = 7.5, 14.7, 21.9 m. Grid bay per E-001 note 7: number = 1 + vertical grid lines west of the device, letter = A + horizontal grid lines south of it (bays A1-D4).

## 9. Device register (every counted device)

| # | sheet | type | x (m) | y (m) | bay | condition | basis of condition | source |
|---|---|---|---|---|---|---|---|---|
| 1 | E-201 | R1 | 9.44 | 1.77 | A2 | DRY-MASONRY | A-102 nearest wall S (1.62 m) | drawn |
| 2 | E-201 | R1 | 9.44 | 4.78 | A2 | DRY-MASONRY | A-102 nearest wall S (4.63 m) | drawn |
| 3 | E-201 | R1 | 9.44 | 7.18 | A2 | DRY-MASONRY | A-102 nearest wall S (7.03 m) | drawn |
| 4 | E-201 | R1 | 4.35 | 10.18 | B1 | RATED-2HR | A-102 nearest wall P3 (2.70 m) | drawn |
| 5 | E-201 | R1 | 9.44 | 10.18 | B2 | RATED-2HR | A-102 nearest wall P3 (7.79 m) | drawn |
| 6 | E-201 | R1 | 4.35 | 12.58 | B1 | RATED-2HR | A-102 nearest wall P3 (2.70 m) | drawn |
| 7 | E-201 | R1 | 9.44 | 12.58 | B2 | RATED-2HR | A-102 nearest wall P3 (7.79 m) | drawn |
| 8 | E-201 | R2 | 3.36 | 0.38 | A1 | DRY-MASONRY | A-102 nearest wall S (0.23 m) | ADD-02 item 02-1 quadraplex added at position of deleted R1 |
| 9 | E-201 | R2 | 4.33 | 1.78 | A1 | DRY-MASONRY | A-102 nearest wall S (1.63 m) | ADD-02 item 02-1 quadraplex added at position of deleted R1 |
| 10 | E-201 | R5 | - | - | A1 | DRY-STUD | keynote rule | keynote <2> at CRAH-01 (1.2,0.45) |
| 11 | E-201 | R5 | - | - | A2 | DRY-STUD | keynote rule | keynote <2> at CRAH-02 (9.6,0.45) |
| 12 | E-201 | R5 | - | - | A1 | DRY-STUD | keynote rule | keynote <2> at in-row r1 (3.9,3.0) |
| 13 | E-201 | R5 | - | - | A2 | DRY-STUD | keynote rule | keynote <2> at in-row r1 (8.3,3.0) |
| 14 | E-201 | R5 | - | - | A2 | DRY-STUD | keynote rule | keynote <2> at in-row r1 (14.1,3.0) |
| 15 | E-201 | R5 | - | - | A1 | DRY-STUD | keynote rule | keynote <2> at in-row r2 (3.9,6.0) |
| 16 | E-201 | R5 | - | - | A2 | DRY-STUD | keynote rule | keynote <2> at in-row r2 (8.1,6.0) |
| 17 | E-201 | R5 | - | - | A2 | DRY-STUD | keynote rule | keynote <2> at in-row r2 (14.1,6.0) |
| 18 | E-201 | R5 | - | - | B1 | DRY-STUD | keynote rule | keynote <2> at in-row r3 (3.9,8.4) |
| 19 | E-201 | R5 | - | - | B2 | DRY-STUD | keynote rule | keynote <2> at in-row r3 (8.1,8.4) |
| 20 | E-201 | R5 | - | - | B2 | DRY-STUD | keynote rule | keynote <2> at in-row r3 (10.5,8.4) |
| 21 | E-201 | R5 | - | - | B1 | DRY-STUD | keynote rule | keynote <2> at in-row r4 (4.5,11.4) |
| 22 | E-201 | R5 | - | - | B2 | DRY-STUD | keynote rule | keynote <2> at in-row r4 (9.1,11.4) |
| 23 | E-201 | R5 | - | - | B1 | DRY-STUD | keynote rule | keynote <2> at in-row r5 (3.9,13.8) |
| 24 | E-201 | R5 | - | - | B2 | DRY-STUD | keynote rule | keynote <2> at in-row r5 (8.1,13.8) |
| 25 | E-201 | R5 | - | - | B2 | DRY-STUD | keynote rule | keynote <2> at in-row r5 (14.1,13.8) |
| 26 | E-201 | R5 | 0.90 | 2.05 | A1 | DAMP | A-102 DAMP hatch: entry vestibule | drawn |
| 27 | E-201 | R5 | 0.90 | 3.90 | A1 | DAMP | A-102 DAMP hatch: entry vestibule | drawn |
| 28 | E-201 | R5 | 0.90 | 4.99 | A1 | DAMP | A-102 DAMP hatch: entry vestibule | drawn |
| 29 | E-201 | R5 | 0.90 | 7.90 | B1 | DAMP | A-102 DAMP hatch: entry vestibule | drawn |
| 30 | E-201 | R6 | 3.17 | 4.62 | A1 | EMERGENCY | E-002 | drawn |
| 31 | E-201 | J1 | 3.78 | 4.10 | A1 | RATED-2HR | A-102 nearest wall P3 (2.13 m) | drawn |
| 32 | E-201 | J1 | 7.74 | 4.10 | A2 | DRY-MASONRY | A-102 nearest wall S (3.95 m) | drawn |
| 33 | E-201 | J1 | 11.70 | 4.10 | A2 | DRY-MASONRY | A-102 nearest wall S (3.95 m) | drawn |
| 34 | E-201 | J1 | 3.78 | 7.10 | A1 | RATED-2HR | A-102 nearest wall P3 (2.13 m) | drawn |
| 35 | E-201 | J1 | 11.70 | 7.10 | A2 | DRY-MASONRY | A-102 nearest wall S (6.95 m) | drawn |
| 36 | E-201 | J1 | 3.74 | 9.50 | B1 | RATED-2HR | A-102 nearest wall P3 (2.09 m) | drawn |
| 37 | E-201 | J1 | 7.62 | 9.50 | B2 | RATED-2HR | A-102 nearest wall P3 (5.97 m) | drawn |
| 38 | E-201 | J1 | 11.51 | 9.50 | B2 | DRY-MASONRY | A-102 nearest wall S (9.35 m) | drawn |
| 39 | E-201 | J1 | 3.84 | 12.50 | B1 | RATED-2HR | A-102 nearest wall P3 (2.19 m) | drawn |
| 40 | E-201 | J1 | 7.92 | 12.50 | B2 | RATED-2HR | A-102 nearest wall P3 (6.27 m) | drawn |
| 41 | E-201 | J1 | 12.00 | 12.50 | B2 | RATED-2HR | A-102 nearest wall P3 (10.35 m) | drawn |
| 42 | E-201 | P1 | 2.40 | 0.90 | A1 | DAMP | A-102 DAMP hatch: CRAH-01 apron | drawn |
| 43 | E-202 | R1 | 14.53 | 1.77 | A2 | DRY-MASONRY | A-102 nearest wall S (1.62 m) | drawn |
| 44 | E-202 | R1 | 19.62 | 1.77 | A3 | DRY-MASONRY | A-102 nearest wall S (1.62 m) | drawn |
| 45 | E-202 | R1 | 22.29 | 3.00 | A4 | DRY-MASONRY | A-102 nearest wall S (2.85 m) | drawn |
| 46 | E-202 | R1 | 14.53 | 4.78 | A2 | DRY-MASONRY | A-102 nearest wall S (4.63 m) | drawn |
| 47 | E-202 | R1 | 19.62 | 4.78 | A3 | DRY-MASONRY | A-102 nearest wall S (4.63 m) | drawn |
| 48 | E-202 | R1 | 22.30 | 6.00 | A4 | DRY-STUD | A-102 nearest wall E (4.62 m) | drawn |
| 49 | E-202 | R1 | 19.62 | 7.18 | A3 | DRY-MASONRY | A-102 nearest wall S (7.03 m) | drawn |
| 50 | E-202 | R1 | 21.90 | 8.40 | B3 | DRY-STUD | A-102 nearest wall E (5.03 m) | drawn |
| 51 | E-202 | R1 | 14.53 | 10.18 | B2 | DRY-MASONRY | A-102 nearest wall S (10.03 m) | drawn |
| 52 | E-202 | R1 | 19.62 | 10.18 | B3 | DRY-STUD | A-102 nearest wall E (7.30 m) | drawn |
| 53 | E-202 | R1 | 22.90 | 11.40 | B4 | DRY-STUD | A-102 nearest wall E (4.03 m) | drawn |
| 54 | E-202 | R1 | 14.53 | 12.58 | B2 | DRY-MASONRY | A-102 nearest wall N (11.27 m) | drawn |
| 55 | E-202 | R1 | 19.62 | 12.58 | B3 | DRY-STUD | A-102 nearest wall E (7.30 m) | drawn |
| 56 | E-202 | R1 | 22.30 | 13.80 | B4 | DRY-STUD | A-102 nearest wall E (4.62 m) | drawn |
| 57 | E-202 | R4 | 23.09 | 1.92 | A4 | IG | E-002 | drawn |
| 58 | E-202 | R4 | 23.09 | 4.92 | A4 | IG | E-002 | drawn |
| 59 | E-202 | R4 | 22.69 | 7.33 | A4 | IG | E-002 | drawn |
| 60 | E-202 | R4 | 23.09 | 12.72 | B4 | IG | E-002 | drawn |
| 61 | E-202 | R5 | - | - | A3 | DRY-STUD | keynote rule | keynote <2> at CRAH-03 (17.4,0.45) |
| 62 | E-202 | R5 | - | - | A4 | DRY-STUD | keynote rule | keynote <2> at CRAH-04 (25.8,0.45) |
| 63 | E-202 | R5 | - | - | A3 | DRY-STUD | keynote rule | keynote <2> at in-row r1 (18.9,3.0) |
| 64 | E-202 | R5 | - | - | A3 | DRY-STUD | keynote rule | keynote <2> at in-row r2 (18.9,6.0) |
| 65 | E-202 | R5 | - | - | B3 | DRY-STUD | keynote rule | keynote <2> at in-row r3 (18.5,8.4) |
| 66 | E-202 | R5 | - | - | B2 | DRY-STUD | keynote rule | keynote <2> at in-row r4 (14.7,11.4) |
| 67 | E-202 | R5 | - | - | B3 | DRY-STUD | keynote rule | keynote <2> at in-row r4 (18.9,11.4) |
| 68 | E-202 | R5 | - | - | B3 | DRY-STUD | keynote rule | keynote <2> at in-row r5 (18.9,13.8) |
| 69 | E-202 | R7 | - | - | B4 | ACCESS-FLOOR | keynote rule | keynote <3> at PDU (23.78,13.6) |
| 70 | E-202 | R7 | - | - | B4 | ACCESS-FLOOR | keynote rule | keynote <3> at PDU (24.38,11.59) |
| 71 | E-202 | R7 | - | - | B4 | ACCESS-FLOOR | keynote rule | keynote <3> at PDU (23.38,8.2) |
| 72 | E-202 | R7 | - | - | A4 | ACCESS-FLOOR | keynote rule | keynote <3> at PDU (23.78,6.19) |
| 73 | E-202 | R7 | - | - | A4 | ACCESS-FLOOR | keynote rule | keynote <3> at PDU (23.78,2.8) |
| 74 | E-202 | J1 | 15.66 | 4.10 | A3 | DRY-MASONRY | A-102 nearest wall S (3.95 m) | drawn |
| 75 | E-202 | J1 | 19.62 | 4.10 | A3 | DRY-MASONRY | A-102 nearest wall S (3.95 m) | drawn |
| 76 | E-202 | J1 | 15.66 | 7.10 | A3 | DRY-MASONRY | A-102 nearest wall S (6.95 m) | drawn |
| 77 | E-202 | J1 | 15.38 | 9.50 | B3 | DRY-MASONRY | A-102 nearest wall S (9.35 m) | drawn |
| 78 | E-202 | J1 | 19.26 | 9.50 | B3 | DRY-STUD | A-102 nearest wall E (7.67 m) | drawn |
| 79 | E-202 | J1 | 16.07 | 12.50 | B3 | DRY-STUD | A-102 nearest wall E (10.85 m) | drawn |
| 80 | E-202 | J1 | 20.16 | 12.50 | B3 | DRY-STUD | A-102 nearest wall E (6.77 m) | drawn |
| 81 | E-202 | P1 | 22.80 | 10.49 | B4 | DRY-STUD | A-102 nearest wall E (4.13 m) | drawn |
| 82 | E-203 | R1 | 4.35 | 15.58 | C1 | RATED-2HR | A-102 nearest wall P3 (2.70 m) | drawn |
| 83 | E-203 | R1 | 9.44 | 15.58 | C2 | RATED-2HR | A-102 nearest wall P3 (7.79 m) | drawn |
| 84 | E-203 | R1 | 3.38 | 23.66 | D1 | DRY-MASONRY | A-102 nearest wall N (0.20 m) | drawn |
| 85 | E-203 | R1 | 10.13 | 23.66 | D2 | DRY-MASONRY | A-102 nearest wall N (0.20 m) | drawn |
| 86 | E-203 | R5 | - | - | C1 | DRY-STUD | keynote rule | keynote <2> at in-row r6 (4.5,16.8) |
| 87 | E-203 | R5 | - | - | C2 | DRY-STUD | keynote rule | keynote <2> at in-row r6 (8.1,16.8) |
| 88 | E-203 | R6 | 2.69 | 23.00 | D1 | EMERGENCY | E-002 | drawn |
| 89 | E-203 | J1 | 3.78 | 14.90 | C1 | RATED-2HR | A-102 nearest wall P3 (2.13 m) | drawn |
| 90 | E-203 | J1 | 11.70 | 14.90 | C2 | DRY-MASONRY | A-102 nearest wall N (8.95 m) | drawn |
| 91 | E-203 | J1 | 8.30 | 15.50 | C2 | RATED-2HR | A-102 nearest wall P3 (6.65 m) | drawn |
| 92 | E-203 | J1 | 3.88 | 17.90 | C1 | RATED-2HR | A-102 nearest wall P3 (2.23 m) | drawn |
| 93 | E-203 | J1 | 8.04 | 17.90 | C2 | DRY-MASONRY | A-102 nearest wall N (5.95 m) | drawn |
| 94 | E-203 | J1 | 12.20 | 17.90 | C2 | DRY-MASONRY | A-102 nearest wall N (5.95 m) | drawn |
| 95 | E-203 | J1 | 8.30 | 22.70 | D2 | DRY-MASONRY | A-102 nearest wall N (1.15 m) | drawn |
| 96 | E-203 | P1 | 2.40 | 20.10 | C1 | RATED-2HR | A-102 nearest wall P3 (0.75 m) | drawn |
| 97 | E-204 | R1 | 14.53 | 15.58 | C2 | DRY-MASONRY | A-102 nearest wall N (8.27 m) | drawn |
| 98 | E-204 | R1 | 19.62 | 15.58 | C3 | DRY-STUD | A-102 nearest wall E (7.30 m) | drawn |
| 99 | E-204 | R1 | 23.30 | 16.80 | C4 | DRY-STUD | A-102 nearest wall E (3.62 m) | drawn |
| 100 | E-204 | R1 | 16.88 | 23.65 | D3 | DRY-MASONRY | A-102 nearest wall N (0.20 m) | drawn |
| 101 | E-204 | R5 | - | - | C3 | DRY-STUD | keynote rule | keynote <2> at in-row r6 (15.1,16.8) |
| 102 | E-204 | R5 | - | - | C3 | DRY-STUD | keynote rule | keynote <2> at in-row r6 (19.3,16.8) |
| 103 | E-204 | R7 | - | - | C4 | ACCESS-FLOOR | keynote rule | keynote <3> at PDU (24.78,17.0) |
| 104 | E-204 | J1 | 15.66 | 14.90 | C3 | DRY-MASONRY | A-102 nearest wall N (8.95 m) | drawn |
| 105 | E-204 | J1 | 19.62 | 14.90 | C3 | DRY-STUD | A-102 nearest wall E (7.30 m) | drawn |
| 106 | E-204 | J1 | 15.50 | 15.50 | C3 | DRY-MASONRY | A-102 nearest wall N (8.35 m) | drawn |
| 107 | E-204 | J1 | 22.70 | 15.50 | C4 | DRY-STUD | A-102 nearest wall E (4.22 m) | drawn |
| 108 | E-204 | J1 | 16.36 | 17.90 | C3 | DRY-MASONRY | A-102 nearest wall N (5.95 m) | drawn |
| 109 | E-204 | J1 | 20.52 | 17.90 | C3 | DRY-MASONRY | A-102 nearest wall N (5.95 m) | drawn |
| 110 | E-204 | J1 | 15.50 | 22.70 | D3 | DRY-MASONRY | A-102 nearest wall N (1.15 m) | drawn |
| 111 | E-204 | J1 | 22.70 | 22.70 | D4 | DRY-MASONRY | A-102 nearest wall N (1.15 m) | drawn |
| 112 | E-211 | F1 | - | - | A1 | DRY-MASONRY | keynote rule | keynote <1> south wall bay 1 |
| 113 | E-211 | F1 | - | - | D1 | DRY-MASONRY | keynote rule | keynote <1> north wall bay 1 |
| 114 | E-211 | F1 | - | - | A2 | DRY-MASONRY | keynote rule | keynote <1> south wall bay 2 |
| 115 | E-211 | F1 | - | - | D2 | DRY-MASONRY | keynote rule | keynote <1> north wall bay 2 |
| 116 | E-211 | F1 | - | - | A3 | DRY-MASONRY | keynote rule | keynote <1> south wall bay 3 |
| 117 | E-211 | F1 | - | - | D3 | DRY-MASONRY | keynote rule | keynote <1> north wall bay 3 |
| 118 | E-211 | F1 | - | - | A4 | DRY-MASONRY | keynote rule | keynote <1> south wall bay 4 |
| 119 | E-211 | F1 | - | - | D4 | DRY-MASONRY | keynote rule | keynote <1> north wall bay 4 |
| 120 | E-211 | F1 | - | - | A1 | RATED-2HR | keynote rule | keynote <4> exit door D-01 in P-R1 (P3 two-hour rated partition) |
| 121 | E-211 | F1 | - | - | C1 | RATED-2HR | keynote rule | keynote <4> exit door D-02 in P-R1 (P3 two-hour rated partition) |
| 122 | E-211 | F1 | - | - | A1 | DRY-STUD | keynote rule | keynote <4> exit door D-04 in W-W (west wall, P1 steel stud) |
| 123 | E-211 | F1 | - | - | B4 | DRY-STUD | keynote rule | keynote <4> exit door D-05 in W-E (east wall, P1 steel stud) |
| 124 | E-211 | F2 | 2.90 | 21.60 | C1 | RATED-2HR | A-102 nearest wall P3 (1.25 m) | drawn |
| 125 | E-211 | F3 | 3.19 | 1.50 | A1 | DRY-MASONRY | A-102 nearest wall S (1.35 m) | drawn |
| 126 | E-211 | F3 | 3.19 | 20.71 | C1 | RATED-2HR | A-102 nearest wall P3 (1.54 m) | drawn |
| 127 | E-211 | F4 | 4.50 | 6.01 | A1 | CEILING | E-002 | drawn |
| 128 | E-211 | F4 | 13.50 | 6.01 | A2 | CEILING | E-002 | drawn |
| 129 | E-211 | F4 | 22.49 | 6.01 | A4 | CEILING | E-002 | drawn |
| 130 | E-211 | F4 | 4.50 | 18.02 | C1 | CEILING | E-002 | drawn |
| 131 | E-211 | F4 | 13.50 | 18.02 | C2 | CEILING | E-002 | drawn |
| 132 | E-211 | F4 | 22.49 | 18.02 | C4 | CEILING | E-002 | drawn |
| 133 | E-211 | F5 | 6.74 | 2.41 | A1 | ACCESS-FLOOR | E-002 | drawn |
| 134 | E-211 | F5 | 11.25 | 2.41 | A2 | ACCESS-FLOOR | E-002 | drawn |
| 135 | E-211 | F5 | 15.74 | 2.41 | A3 | ACCESS-FLOOR | E-002 | drawn |
| 136 | E-211 | F5 | 20.25 | 2.41 | A3 | ACCESS-FLOOR | E-002 | drawn |
| 137 | E-211 | F5 | 2.24 | 3.31 | A1 | ACCESS-FLOOR | E-002 | drawn |
| 138 | E-211 | F5 | 2.25 | 7.21 | A1 | ACCESS-FLOOR | E-002 | drawn |
| 139 | E-211 | F5 | 6.74 | 7.21 | A1 | ACCESS-FLOOR | E-002 | drawn |
| 140 | E-211 | F5 | 11.25 | 7.21 | A2 | ACCESS-FLOOR | E-002 | drawn |
| 141 | E-211 | F5 | 15.75 | 7.21 | A3 | ACCESS-FLOOR | E-002 | drawn |
| 142 | E-211 | F5 | 20.25 | 7.21 | A3 | ACCESS-FLOOR | E-002 | drawn |
| 143 | E-211 | F5 | 6.74 | 12.01 | B1 | ACCESS-FLOOR | E-002 | drawn |
| 144 | E-211 | F5 | 11.24 | 12.01 | B2 | ACCESS-FLOOR | E-002 | drawn |
| 145 | E-211 | F5 | 15.74 | 12.01 | B3 | ACCESS-FLOOR | E-002 | drawn |
| 146 | E-211 | F5 | 20.25 | 12.01 | B3 | ACCESS-FLOOR | E-002 | drawn |
| 147 | E-211 | F5 | 2.25 | 12.91 | B1 | ACCESS-FLOOR | E-002 | drawn |
| 148 | E-211 | F5 | 2.24 | 16.82 | C1 | ACCESS-FLOOR | E-002 | drawn |
| 149 | E-211 | F5 | 6.74 | 16.82 | C1 | ACCESS-FLOOR | E-002 | drawn |
| 150 | E-211 | F5 | 11.25 | 16.82 | C2 | ACCESS-FLOOR | E-002 | drawn |
| 151 | E-211 | F5 | 15.75 | 16.82 | C3 | ACCESS-FLOOR | E-002 | drawn |
| 152 | E-211 | F5 | 20.25 | 16.82 | C3 | ACCESS-FLOOR | E-002 | drawn |
| 153 | E-211 | F5 | 2.25 | 21.62 | C1 | ACCESS-FLOOR | E-002 | drawn |
| 154 | E-211 | F5 | 6.74 | 21.62 | C1 | ACCESS-FLOOR | E-002 | drawn |
| 155 | E-211 | F5 | 11.25 | 21.62 | C2 | ACCESS-FLOOR | E-002 | drawn |
| 156 | E-211 | F5 | 15.75 | 21.62 | C3 | ACCESS-FLOOR | E-002 | drawn |
| 157 | E-211 | F5 | 20.25 | 21.62 | C3 | ACCESS-FLOOR | E-002 | drawn |
| 158 | E-211 | D1 | 9.59 | 1.65 | A2 | CEILING | E-002 | drawn |
| 159 | E-211 | D1 | 17.40 | 1.65 | A3 | CEILING | E-002 | drawn |
| 160 | E-211 | D1 | 3.90 | 4.20 | A1 | CEILING | E-002 | drawn |
| 161 | E-211 | D1 | 8.29 | 4.20 | A2 | CEILING | E-002 | drawn |
| 162 | E-211 | D1 | 14.09 | 4.20 | A2 | CEILING | E-002 | drawn |
| 163 | E-211 | D1 | 18.89 | 4.20 | A3 | CEILING | E-002 | drawn |
| 164 | E-211 | D1 | 3.90 | 7.20 | A1 | CEILING | E-002 | drawn |
| 165 | E-211 | D1 | 8.09 | 7.20 | A2 | CEILING | E-002 | drawn |
| 166 | E-211 | D1 | 14.09 | 7.20 | A2 | CEILING | E-002 | drawn |
| 167 | E-211 | D1 | 18.89 | 7.20 | A3 | CEILING | E-002 | drawn |
| 168 | E-211 | D1 | 3.90 | 9.60 | B1 | CEILING | E-002 | drawn |
| 169 | E-211 | D1 | 8.09 | 9.60 | B2 | CEILING | E-002 | drawn |
| 170 | E-211 | D1 | 10.49 | 9.60 | B2 | CEILING | E-002 | drawn |
| 171 | E-211 | D1 | 18.49 | 9.60 | B3 | CEILING | E-002 | drawn |
| 172 | E-211 | D1 | 4.50 | 12.60 | B1 | CEILING | E-002 | drawn |
| 173 | E-211 | D1 | 9.09 | 12.60 | B2 | CEILING | E-002 | drawn |
| 174 | E-211 | D1 | 14.69 | 12.60 | B2 | CEILING | E-002 | drawn |
| 175 | E-211 | D1 | 18.89 | 12.60 | B3 | CEILING | E-002 | drawn |
| 176 | E-211 | D1 | 3.90 | 15.01 | C1 | CEILING | E-002 | drawn |
| 177 | E-211 | D1 | 8.09 | 15.01 | C2 | CEILING | E-002 | drawn |
| 178 | E-211 | D1 | 14.09 | 15.01 | C2 | CEILING | E-002 | drawn |
| 179 | E-211 | D1 | 18.89 | 15.01 | C3 | CEILING | E-002 | drawn |
| 180 | E-211 | D1 | 8.09 | 18.01 | C2 | CEILING | E-002 | drawn |
| 181 | E-211 | D1 | 15.09 | 18.01 | C3 | CEILING | E-002 | drawn |
| 182 | E-211 | D1 | 19.29 | 18.01 | C3 | CEILING | E-002 | drawn |
| 183 | E-231 | R1 | 0.35 | 3.90 | A1 | DAMP | A-102 DAMP hatch: entry vestibule | drawn frame 2 |
| 184 | E-231 | R1 | 1.10 | 3.90 | A1 | DAMP | A-102 DAMP hatch: entry vestibule | drawn frame 2 |
| 185 | E-231 | R1 | 1.10 | 6.00 | A1 | DAMP | A-102 DAMP hatch: entry vestibule | drawn frame 2 |
| 186 | E-231 | R1 | 1.10 | 8.40 | B1 | RATED-2HR | A-102 nearest wall P3 (0.55 m) | drawn frame 3 |
| 187 | E-231 | R1 | 0.35 | 9.00 | B1 | DRY-STUD | A-102 nearest wall W (0.28 m) | drawn frame 3 |
| 188 | E-231 | R1 | 1.10 | 11.40 | B1 | RATED-2HR | A-102 nearest wall P3 (0.55 m) | drawn frame 4 |
| 189 | E-231 | R1 | 1.10 | 13.80 | B1 | RATED-2HR | A-102 nearest wall P3 (0.55 m) | drawn frame 5 |
| 190 | E-231 | R1 | 0.35 | 15.00 | C1 | DRY-STUD | A-102 nearest wall W (0.28 m) | drawn frame 5 |
| 191 | E-231 | R1 | 1.10 | 17.25 | C1 | RATED-2HR | A-102 nearest wall P3 (0.55 m) | drawn frame 5 |
| 192 | E-231 | R3 | 0.65 | 3.90 | A1 | DAMP | A-102 DAMP hatch: entry vestibule | drawn frame 2 |
| 193 | E-231 | R3 | 0.65 | 9.00 | B1 | DRY-STUD | A-102 nearest wall W (0.58 m) | drawn frame 3 |
| 194 | E-231 | R3 | 0.65 | 15.00 | C1 | DRY-STUD | A-102 nearest wall W (0.58 m) | drawn frame 5 |
| 195 | E-231 | R6 | 0.90 | 5.40 | A1 | EMERGENCY | E-002 | drawn frame 2 |
| 196 | E-231 | J1 | 1.20 | 2.88 | A1 | DAMP | A-102 DAMP hatch: entry vestibule | drawn frame 1 |
| 197 | E-231 | J1 | 1.20 | 7.68 | B1 | DAMP | A-102 DAMP hatch: entry vestibule | drawn frame 3 |
| 198 | E-231 | J1 | 1.20 | 12.48 | B1 | RATED-2HR | A-102 nearest wall P3 (0.45 m) | drawn frame 4 |
| 199 | E-231 | J1 | 1.20 | 17.28 | C1 | RATED-2HR | A-102 nearest wall P3 (0.45 m) | drawn frame 6 |
| 200 | E-231 | P1 | 1.20 | 2.50 | A1 | DAMP | A-102 DAMP hatch: entry vestibule | drawn frame 1 |
| 201 | E-231 | P1 | 0.60 | 3.85 | A1 | DAMP | A-102 DAMP hatch: entry vestibule | drawn frame 2 |
| 202 | E-231 | F2 | 1.10 | 4.00 | A1 | DAMP | A-102 DAMP hatch: entry vestibule | drawn frame 2 |
| 203 | E-231 | F2 | 1.00 | 13.35 | B1 | RATED-2HR | A-102 nearest wall P3 (0.65 m) | drawn frame 4 |
| 204 | E-231 | D1 | 1.20 | 1.65 | A1 | CEILING | E-002 | drawn frame 1 |
| 205 | E-232 | R1 | 23.62 | 0.35 | A4 | DRY-MASONRY | A-102 nearest wall S (0.20 m) | drawn frame 8 |
| 206 | E-232 | R1 | 25.20 | 1.71 | A4 | DRY-MASONRY | A-102 nearest wall S (1.56 m) | drawn frame 8 |
| 207 | E-232 | R1 | 26.65 | 3.00 | A4 | DRY-STUD | A-102 nearest wall E (0.28 m) | drawn frame 8 |
| 208 | E-232 | R1 | 25.20 | 5.14 | A4 | DRY-STUD | A-102 nearest wall E (1.73 m) | drawn frame 9 |
| 209 | E-232 | R1 | 25.20 | 8.57 | B4 | DRY-STUD | A-102 nearest wall E (1.73 m) | drawn frame 10 |
| 210 | E-232 | R1 | 26.65 | 9.00 | B4 | DRY-STUD | A-102 nearest wall E (0.28 m) | drawn frame 10 |
| 211 | E-232 | R1 | 0.35 | 21.00 | C1 | DRY-STUD | A-102 nearest wall W (0.28 m) | drawn frame 7 |
| 212 | E-232 | R2 | 24.86 | 2.81 | A4 | DRY-STUD | A-102 nearest wall E (2.06 m) | drawn frame 8 |
| 213 | E-232 | R2 | 24.86 | 6.20 | A4 | DRY-STUD | A-102 nearest wall E (2.06 m) | drawn frame 9 |
| 214 | E-232 | R2 | 24.46 | 8.21 | B4 | DRY-STUD | A-102 nearest wall E (2.46 m) | drawn frame 10 |
| 215 | E-232 | R3 | 24.95 | 3.00 | A4 | DRY-STUD | A-102 nearest wall E (1.98 m) | drawn frame 8 |
| 216 | E-232 | R3 | 24.95 | 9.00 | B4 | DRY-STUD | A-102 nearest wall E (1.98 m) | drawn frame 10 |
| 217 | E-232 | R3 | 0.65 | 21.00 | C1 | DRY-STUD | A-102 nearest wall W (0.58 m) | drawn frame 7 |
| 218 | E-232 | J1 | 1.20 | 22.08 | D1 | RATED-2HR | A-102 nearest wall P3 (0.45 m) | drawn frame 7 |
| 219 | E-232 | P1 | 25.80 | 2.50 | A4 | DRY-STUD | A-102 nearest wall E (1.13 m) | drawn frame 8 |
| 220 | E-232 | F5 | 24.75 | 2.40 | A4 | ACCESS-FLOOR | E-002 | drawn frame 8 |
| 221 | E-232 | F5 | 24.75 | 7.20 | A4 | ACCESS-FLOOR | E-002 | drawn frame 10 |
| 222 | E-232 | D1 | 25.80 | 1.65 | A4 | CEILING | E-002 | drawn frame 8 |
| 223 | E-233 | R1 | 26.65 | 15.00 | C4 | DRY-STUD | A-102 nearest wall E (0.28 m) | drawn frame 12 |
| 224 | E-233 | R1 | 25.20 | 15.43 | C4 | DRY-STUD | A-102 nearest wall E (1.73 m) | drawn frame 12 |
| 225 | E-233 | R1 | 25.20 | 18.86 | C4 | DRY-STUD | A-102 nearest wall E (1.73 m) | drawn frame 13 |
| 226 | E-233 | R1 | 26.65 | 21.00 | C4 | DRY-STUD | A-102 nearest wall E (0.28 m) | drawn frame 14 |
| 227 | E-233 | R1 | 25.20 | 22.29 | D4 | DRY-MASONRY | A-102 nearest wall N (1.56 m) | drawn frame 14 |
| 228 | E-233 | R1 | 23.62 | 23.65 | D4 | DRY-MASONRY | A-102 nearest wall N (0.20 m) | drawn frame 14 |
| 229 | E-233 | R2 | 25.46 | 11.60 | B4 | DRY-STUD | A-102 nearest wall E (1.46 m) | drawn frame 11 |
| 230 | E-233 | R2 | 24.86 | 13.61 | B4 | DRY-STUD | A-102 nearest wall E (2.06 m) | drawn frame 11 |
| 231 | E-233 | R2 | 25.86 | 16.99 | C4 | DRY-STUD | A-102 nearest wall E (1.06 m) | drawn frame 12 |
| 232 | E-233 | R3 | 24.95 | 15.00 | C4 | DRY-STUD | A-102 nearest wall E (1.98 m) | drawn frame 12 |
| 233 | E-233 | R3 | 24.95 | 21.00 | C4 | DRY-STUD | A-102 nearest wall E (1.98 m) | drawn frame 14 |
| 234 | E-233 | R4 | 23.70 | 10.31 | B4 | IG | E-002 | drawn frame 11 |
| 235 | E-233 | R4 | 24.10 | 15.71 | C4 | IG | E-002 | drawn frame 12 |
| 236 | E-233 | R6 | 26.10 | 13.40 | B4 | EMERGENCY | E-002 | drawn frame 11 |
| 237 | E-233 | P1 | 26.40 | 10.50 | B4 | DRY-STUD | A-102 nearest wall E (0.52 m) | drawn frame 11 |
| 238 | E-233 | F2 | 25.90 | 12.00 | B4 | DRY-STUD | A-102 nearest wall E (1.03 m) | drawn frame 11 |
| 239 | E-233 | F3 | 25.60 | 11.10 | B4 | DRY-STUD | A-102 nearest wall E (1.33 m) | drawn frame 11 |
| 240 | E-233 | F5 | 24.75 | 12.00 | B4 | ACCESS-FLOOR | E-002 | drawn frame 11 |
| 241 | E-233 | F5 | 24.75 | 16.80 | C4 | ACCESS-FLOOR | E-002 | drawn frame 12 |
| 242 | E-233 | F5 | 24.75 | 21.60 | C4 | ACCESS-FLOOR | E-002 | drawn frame 14 |
