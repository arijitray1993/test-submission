# Change documentation for the Contracting Officer - Work Order 74213

Both bid packages are delivered in one submission (CO memorandum of 26 August 2026, para 6). BP-2 is issued as an amendment to its advertised solicitation and is documented below on the Continuation Sheet laid out after the sample in FC 1-300-09N Figure 18-1. BP-3 is not issued as a change to a solicitation; see the statement at the end.

---

## BP-2 - Central Utility Plant and Site Utilities - Solicitation N40085-26-R-2041

File name of this document: **74213Amend0003.pdf** (FC 1-300-09N paragraph 12-3.5.6). It is page two of the SF 30 that the Contracting Officer prepares for the amendment (FC 1-300-09N paragraph 18-5). Attached drawing files, combined by type, bookmarked by discipline and by sheet, and split only at discipline boundaries to respect the size limit: **74213Amend0003dwg1of3.pdf**, **74213Amend0003dwg2of3.pdf**, **74213Amend0003dwg3of3.pdf**.

```
CONTINUATION SHEET
AMENDMENT 0003 - SOLICITATION N40085-26-R-2041
WORK ORDER 74213 - FLEET DATA CENTER INCREMENT 2 - BP-2 CENTRAL UTILITY PLANT AND SITE UTILITIES
NAVAL SUPPORT ACTIVITY VENTURA BAY, CALIFORNIA

DRAWINGS:
                On NAVFAC Drawing No. 74213-GI001 (GI-001)
ADD the following drawings to the DRAWING INDEX, each in its discipline group and
drawing number position; they are issued with Amendment 0003:
S-202 74213-S202 BRACED BAY FRAMING ELEVATIONS - ADDED SHEET
M-503 74213-M503 CHILLER PAD ANCHORAGE DETAILS - ADDED SHEET
REPLACE the following drawings on the DRAWING INDEX, each in its discipline group and
drawing number position; the replacement sheets are issued with Amendment 0003:
C-101 74213-C101 SITE UTILITY PLAN - REPLACED SHEET
S-101 74213-S101 CUP FOUNDATION PLAN - REPLACED SHEET
S-102 74213-S102 CUP ROOF FRAMING PLAN - REPLACED SHEET
S-301 74213-S301 CUP BUILDING SECTIONS - REPLACED SHEET
S-502 74213-S502 FRAMING DETAILS - REPLACED SHEET
M-101 74213-M101 CUP CHILLED WATER PLAN - REPLACED SHEET
M-301 74213-M301 CHILLED WATER PLANT SECTIONS - REPLACED SHEET
M-401 74213-M401 CHILLER BAY ENLARGED PLAN - REPLACED SHEET
M-501 74213-M501 PIPING DETAILS - REPLACED SHEET
M-502 74213-M502 EQUIPMENT ANCHORAGE DETAILS - REPLACED SHEET
E-001 74213-E001 ELECTRICAL PANEL SCHEDULES - REPLACED SHEET
E-101 74213-E101 CUP POWER PLAN - REPLACED SHEET
E-501 74213-E501 ELECTRICAL DETAILS - REPLACED SHEET

Each replaced sheet shows its changes inside a revision cloud with a triangle holding
the number 3, and carries the entry 3 / REVISED IN ACCORDANCE WITH AMDT 0003 / SEP 2026
in its Revision (Issue) block. Sheet numbers and designations of revised drawings are
unchanged.

SPECIFICATIONS:
No specification section is added, replaced or deleted by this amendment.

DOCUMENT 00 01 15 LIST OF DRAWINGS
1.2 Contract Drawings
ADD the following drawings. They are issued with Amendment 0003.
DRAWING     REVISION   NAVFAC        TITLE
NO.         NO.        DWG NO.
S-202       3          74213-S202    BRACED BAY FRAMING ELEVATIONS
M-503       3          74213-M503    CHILLER PAD ANCHORAGE DETAILS
DELETE and REPLACE the following drawings as of September 2026. The replacement
drawings are issued with Amendment 0003.
DRAWING     REVISION   NAVFAC        TITLE
NO.         NO.        DWG NO.
C-101       3          74213-C101    SITE UTILITY PLAN
S-101       3          74213-S101    CUP FOUNDATION PLAN
S-102       3          74213-S102    CUP ROOF FRAMING PLAN
S-301       3          74213-S301    CUP BUILDING SECTIONS
S-502       3          74213-S502    FRAMING DETAILS
M-101       3          74213-M101    CUP CHILLED WATER PLAN
M-301       3          74213-M301    CHILLED WATER PLANT SECTIONS
M-401       3          74213-M401    CHILLER BAY ENLARGED PLAN
M-501       3          74213-M501    PIPING DETAILS
M-502       3          74213-M502    EQUIPMENT ANCHORAGE DETAILS
E-001       3          74213-E001    ELECTRICAL PANEL SCHEDULES
E-101       3          74213-E101    CUP POWER PLAN
E-501       3          74213-E501    ELECTRICAL DETAILS

                    --End of Amendment--
```

Summary of the corrections carried by the replaced and added sheets (for the Contracting Officer; the sheets themselves are the change documents):

| Comment | Sheet(s) changed | Sheets re-issued because they call out the changed view |
|---|---|---|
| EOR-2-001 | S-101 | none |
| EOR-2-004 | S-502 | E-101, E-501, M-101, M-401, M-501, M-502, S-102, S-301 |
| EOR-2-006 | M-101 | none |
| EOR-2-009 | C-101 | none |
| EOR-2-013 | E-001 | none |
| EOR-2-023 | M-401, M-503 | E-101, M-101 |
| EOR-2-025 | S-101, S-202 | none |
| EOR-2-029 | E-101 | none |
| EOR-2-031 | M-301 | none |

Comments not producing a drawing change in this amendment: EOR-2-011 (documented non-concurrence), EOR-2-033 (closed as elevated in the 60 percent review, not reopened), and the void markups EOR-2-015, EOR-2-017, EOR-2-019, EOR-2-021 and EOR-2-027 (grounds recorded in the disposition register).

---

## BP-3 - Data Hall 210 Shell and Interiors - Solicitation N40085-26-R-3018

Statement: the BP-3 corrections are not issued as a change to a solicitation. They are incorporated in the design and the corrected package is re-issued before the solicitation is advertised (course a of the CO memorandum of 26 August 2026, para 3), and the advertisement stays on its scheduled date of 9 November 2026 because the corrections finish well inside the 30-day backcheck window. As the memorandum states in para 2, no change number is assigned and no Continuation Sheet is submitted for BP-3. The re-issued and added BP-3 sheets (A-402 and M-502 added) are delivered as 74213dwg1of2.pdf and 74213dwg2of2.pdf and are listed in the regenerated sheet index; they carry no revision cloud, triangle or Revision (Issue) block entry.
