# Design basis - EOR review corrections, Work Order 74213 (BP-2 and BP-3)

Prepared by the Designer of Record document controller. All values below are read from the project documents; the machine-readable summary follows, then the narrative. Clause numbers are cited as authority; requirements are paraphrased, never copied.

```json
{
  "packages": {
    "BP-2": {
      "issue_state": "AMENDMENT",
      "change_number": "0003",
      "overflow_option": 2,
      "revision_layers": [
        "Z-ANNO-REVC",
        "Z-ANNO-REVS"
      ],
      "n_bundles": 3,
      "production_days": 14,
      "delay_days": 1,
      "backcheck_window_days": 15,
      "ledger": {
        "bundles_usd": 14400,
        "sheets_usd": 18528.64,
        "added_sheets_usd": 12800,
        "revision_marks_usd": 3120,
        "overflow_option_usd": 1760,
        "non_concurrence_usd": 2400,
        "delay_usd": 2740,
        "total_usd": 55748.64
      },
      "title_block_defects": [
        {
          "sheet": "S-301",
          "defect": "CHK_EQUALS_DRW"
        },
        {
          "sheet": "E-501",
          "defect": "SEAL_DISCIPLINE_MISMATCH"
        }
      ]
    },
    "BP-3": {
      "issue_state": "PRE_ADVERTISEMENT_REISSUE",
      "change_number": "",
      "overflow_option": "NONE",
      "revision_layers": [],
      "n_bundles": 2,
      "production_days": 11,
      "delay_days": 0,
      "backcheck_window_days": 30,
      "ledger": {
        "bundles_usd": 9600,
        "sheets_usd": 20053.04,
        "added_sheets_usd": 12800,
        "revision_marks_usd": 0,
        "overflow_option_usd": 0,
        "non_concurrence_usd": 2400,
        "delay_usd": 0,
        "total_usd": 44853.04
      },
      "title_block_defects": [
        {
          "sheet": "A-501",
          "defect": "CHK_EQUALS_DES"
        },
        {
          "sheet": "M-101",
          "defect": "SEAL_DISCIPLINE_MISMATCH"
        }
      ]
    }
  },
  "governing_standards": [
    "FC 1-300-09N Navy and Marine Corps Design Procedures, 17 May 2024, with Change 1 of 17 April 2025",
    "A/E/C Computer-Aided Design (CAD) Standard, Release 6.2 (ERDC/ITL SR-24-3, July 2024)",
    "A/E/C Graphics Standard, Release 2.2 (ERDC/ITL SR-23-1, August 2023)",
    "ER 415-1-11 Biddability, Constructability, Operability, Environmental and Sustainability (BCOES) Reviews, 1 January 2013",
    "ER 1165-2-217 Civil Works Review Policy, 1 May 2021 - review comment structure, response and closure only, as adopted by the CO memorandum of 26 August 2026 para 7",
    "ERDC/ITL SR-21-6 Record Package Guidance: Best Practices - markup colour convention only, as adopted by the CO memorandum of 26 August 2026 para 7",
    "ER 1110-1-8159 Engineering and Design DrChecks, 1 January 2015",
    "FAR 52.236-25 Requirements for Registration of Designers (JUN 2003)"
  ],
  "rejected_standards": [
    "A/E/C CAD Standard Release 6.0 (ERDC/ITL TR-12-6) - superseded by Release 6.2, which is the current release in the folder",
    "UFC 1-300-09N Design Procedures, 25 May 2005 with Change 7 - cancelled and replaced; FC 1-300-09N (2024, Change 1) governs",
    "GSA PBS CAD Standards, 10 March 2021 (owner legacy) - another agency's owner standard, not applicable to NAVFAC work",
    "ERDC/ITL SR-21-6 record-package deliverable requirements (including its revision-layer statement) - not adopted; the CO memorandum para 7 adopts only the markup and review conventions",
    "ER 1165-2-217 Civil Works policies other than the review comment, response and closure conventions - not adopted (CO memorandum para 7)"
  ],
  "rate_parameters": {
    "production_start": "2026-08-31",
    "sheets_per_day": 4,
    "days_per_bundle": 3
  },
  "void_markups": [
    {
      "comment_id": "EOR-2-015",
      "reason": "Author M. Delacroix is registered in electrical engineering only, but the markup directs a change to a mechanical sheet (M-301); a design change must come from a professional registered in that field."
    },
    {
      "comment_id": "EOR-2-017",
      "reason": "Author G. Halvorsen is not on the reviewer roster and holds no assigned review responsibility for this work order, so the markup carries no review authority."
    },
    {
      "comment_id": "EOR-2-019",
      "reason": "The markup annotation carries no creation or modification timestamp, so it cannot be traced to this review period and cannot direct a change."
    },
    {
      "comment_id": "EOR-2-021",
      "reason": "The markup sits on the superseded 90 percent print of S-102, not on the current advertised issue against which changes are made."
    },
    {
      "comment_id": "EOR-2-027",
      "reason": "Author K. Aoyama is a construction representative with no professional registration, so the markup cannot direct a change to mechanical design."
    },
    {
      "comment_id": "EOR-3-012",
      "reason": "The markup sits on the superseded 60 percent print of T-501, not on the certified current issue against which changes are made."
    },
    {
      "comment_id": "EOR-3-016",
      "reason": "Author M. Delacroix is registered in electrical engineering only, but the markup directs a change to an architectural sheet (A-501) outside that field."
    },
    {
      "comment_id": "EOR-3-018",
      "reason": "Author P. Okonjo is registered in civil engineering only, but the markup directs a change to an architectural roof detail sheet (A-502) outside that field."
    },
    {
      "comment_id": "EOR-3-020",
      "reason": "The markup annotation carries no creation or modification timestamp, so it cannot be traced to this review period and cannot direct a change."
    },
    {
      "comment_id": "EOR-3-022",
      "reason": "Author C. Ballantyne is not on the reviewer roster and holds no assigned review responsibility for this work order, so the markup carries no review authority."
    }
  ]
}
```

## 1. Documents that govern and documents set aside

- Design procedures criteria: FC 1-300-09N (2024, Change 1) - drawing PDF limits, file names, signing and sealing, amendment numbering, Continuation Sheet format, and (paragraph 12-3.3.4) the order of precedence among CAD standards.
- CAD and graphics: A/E/C CAD Standard Release 6.2 (sheet identification, added sheets, discipline order, layer tables) and A/E/C Graphics Standard Release 2.2 (revision designations, revision graphics, Revision (Issue) block, callout symbols). Release 6.0 of the CAD standard is in the folder but superseded; it lacks the Release 6.2 rule that notes, abbreviations and legend sheets lead their discipline, so it was not used.
- Review process: ER 1165-2-217 (four-part comment, three-part response, elevation closure) and the SR-21-6 markup colour convention, both only to the extent the CO memorandum of 26 August 2026 (para 7) adopts them; ER 415-1-11 for the timing of comment resolution and backcheck; ER 1110-1-8159 for who may enter review comments; FAR 52.236-25 and FC 1-300-09N paragraphs 2-5 and 3-1.5 for registration in the field of the work.
- Set aside: the cancelled UFC 1-300-09N (2005, Change 7), the superseded CAD Release 6.0, the GSA PBS CAD Standards (another agency), the superseded 90 and 60 percent prints and the 90 percent index export (reference only), the FY23 record drawings (reference only, record layer set), and the fire protection comment log (separate A-E task order, outside both packages).

## 2. Markups that cannot direct a change

Each comment was matched to its annotation through the markup reference (NM) and checked for author, timestamp, colour, note, sheet issue and the author's registration. Four grounds came out of the corpus:

1. **Superseded print** - the drawings README says the superseded prints are not the issue any change is made against: EOR-2-021 (90 percent S-102) and EOR-3-012 (60 percent T-501).
2. **Author without assigned review responsibility** - ER 1110-1-8159 paragraph 5 (subparagraph c) limits DrChecks use to personnel given project review responsibility, and ER 1165-2-217 paragraph 5.8.1 ties each comment to its own reviewer for traceability; G. Halvorsen (EOR-2-017) and C. Ballantyne (EOR-3-022) are not on the reviewer roster.
3. **No timestamp** - the markup objects for EOR-2-019 and EOR-3-020 have null creation and modification dates, so they cannot be traced to this review (ER 1165-2-217 paragraphs 4.7.1.5 and 5.8.1 expect checked graphics to be initialled and dated by the reviewer).
4. **Author not registered in the field of the sheet** - FAR 52.236-25 and FC 1-300-09N paragraphs 2-5 and 3-1.5 reserve the preparation, review and approval of each feature to a professional registered in that field: EOR-2-015 and EOR-3-016 (M. Delacroix, electrical, on mechanical M-301 and architectural A-501), EOR-3-018 (P. Okonjo, civil, on architectural A-502) and EOR-2-027 (K. Aoyama, construction representative with no registration, on mechanical M-501).

All ten are closed VOID with the ground stated, carry no cost and generate no sheet. The markup layer (G-ANNO-REDL or G-ANNO-NPLT) was examined and is not a ground: the colour convention and the four attributes the README names are what the review record relies on. The K. Aoyama "CHECKED - NO COMMENT" notes are participation notes, not comments.

## 3. What each surviving comment does

Directive comments are the green (addition) and red (deletion) markups whose basis is criteria, design analysis, a coordination or a dimensional deficiency; they are all incorporated. Blue (clarification) markups based on professional opinion or preference are not directive (ER 1165-2-217 paragraph 5.8.5; SR-21-6 treats blue items as optional). Each was costed both ways (non-concurrence: 2,400 USD plus one calendar day; incorporation: sheet re-issue, markup extent, revision mark in an amendment, and every sheet dragged in by the callout sweep):

| Comment | Incorporation cost | Decision |
|---|---|---|
| EOR-2-011 (C-501 detail A) | 2,956.80 USD - C-501 plus C-301, whose section calls out detail A | Non-concur (cheaper, same 14-day schedule) |
| EOR-2-013 (E-001) | 1,728.00 USD | Incorporate |
| EOR-2-029 (E-101, already re-issued) | 249.60 USD | Incorporate |
| EOR-2-031 (M-301 section B, not referenced) | 1,556.40 USD | Incorporate |
| EOR-3-028 (A-201; A-101 already re-issued) | 1,378.80 USD | Incorporate |
| EOR-3-030 (S-301 section A) | 2,524.64 USD plus S-102 and a third bundle (4,800 USD, 3 days) | Non-concur |
| EOR-3-032 (M-301; M-101 already re-issued) | 1,344.48 USD | Incorporate |
| EOR-3-034 (T-501 detail B, not referenced) | 1,321.60 USD | Incorporate |

EOR-2-033 and EOR-3-036 were closed in the 60 percent review (2026-03-27) as elevated for resolution and the closure was not reopened (review checklists); they are recorded CLOSED_ELEVATED under ER 1165-2-217 paragraph 5.9.1.2 with no new response and no cost.

## 4. The callout sweep

Callout bubbles were read from the sheet geometry and assigned to the drawing block that contains them, giving a block-to-block reference graph for each package. A changed view re-issues every block that calls it out, and those blocks propagate further, across disciplines, until nothing new is reached. Examples: deleting the cast-in anchor in detail A of S-502 (EOR-2-004) reaches E-501, M-501, M-502 and S-301 directly and E-101, M-101, M-401 and S-102 through them, but not M-102 or M-301, whose callouts point at other details of M-501; the base plate change in detail A of S-501 (EOR-3-004) reaches A-501, E-501 and S-101 and then A-101, A-301 and E-102. Every incorporated response lists its changed and re-issued sheets (ER 1165-2-217 paragraph 5.8.7.3).

Re-issued sheets: BP-2 - C-101, E-001, E-101, E-501, M-101, M-301, M-401, M-501, M-502, S-101, S-102, S-301, S-502, plus added S-202 and M-503. BP-3 - A-001, A-101, A-102, A-201, A-301, A-501, A-502, E-102, E-501, M-101, M-301, S-101, S-501, T-501, plus added A-402 and M-502.

## 5. Issue state

**BP-2 - only one lawful answer: AMENDMENT.** The solicitation N40085-26-R-2041 was advertised on 2026-07-06 and opens bids on 2026-09-28. Graphics Standard section 7.1 classes changes during the advertisement period as amendments, and CAD Standard section 2.4.4.1 requires sheet additions after advertisement to be documented as an amendment. Two amendments (0001, 0002) are already issued, so the CO assigns the next number in sequence (CO memorandum para 1); FC 1-300-09N paragraph 18-3 writes amendment numbers with leading zeros to four digits, giving **0003**. Because the solicitation is already advertised, the ER 415-1-11 requirement to start the backcheck 30 days before advertising can no longer be met and the binding timing is the other one: every comment resolved before bid opening, with about 15 calendar days allowed for back-checking (ER 415-1-11 paragraph 6, subparagraphs e(4) and g). Window applied: **15 calendar days**, so the amendment must be complete by 2026-09-13. Production: 15 sheets (13 replaced, 2 added) at 4 per day = 4 days, 3 bundles at 3 days = 9 days, 1 non-concurrence = 1 day, total 14 days from 2026-08-31, finishing 2026-09-14; D = 1 day, extension charge 2,600 x 1 + 140 x 1 squared = 2,740.00 USD. No feasible plan is shorter: the 15 delivered sheets total 116.9 MB (105.0 MB for the directive scope alone), which cannot fit in two 50 MB files, and the fourth non-directive comment (EOR-2-011) costs one day whether it is incorporated (17 sheets, 5 production days) or non-concurred.

**BP-3 - decision (b): PRE_ADVERTISEMENT_REISSUE.** BP-3 is certified but not advertised. The advertisement date is **9 November 2026**: the CO memorandum dated 26 August 2026 (para 3) controls over the earlier schedule export's 12 October 2026. Bid opening is **12 November 2026** (solicitation schedule). ER 415-1-11 paragraph 6 gives two durations: subparagraph g says the backcheck "should be started 30 calendar days prior to advertising" (with every comment resolved before bid opening), while subparagraph e(4) allows "about 15 calendar days" for back checking of comments. Which one binds depends on the course: holding the corrections for re-issue before advertisement makes the advertisement the controlling date and the **30-day window** applies, so the corrected design must be complete by 2026-10-10 (9 November less 30 days). The 15-day window binds only for the amendment course, where the solicitation is already out and the controlling date becomes bid opening (deadline 2026-10-28). Applied: **30 calendar days**, because the chosen course is the pre-advertisement re-issue. Production: 16 sheets (14 re-issued, 2 added) = 4 days, 2 bundles = 6 days, 1 non-concurrence = 1 day, total 11 days, finishing 2026-09-11, 29 days inside the window; D = 0, so neither the advertisement nor the bid opening moves and no extension is charged. The amendment course is also lawful but costs more - revision marks on all 14 replaced sheets (3,360.00 USD), overflow on the three full blocks A-001, A-101 and A-301 (Option 1 at 1,560.00 USD), amendment 0001 numbering and a Continuation Sheet, about 49,773.04 USD in total against 44,853.04 USD - and an amendment issued after the 9 November advertisement would leave only three days to the 12 November bid opening, far short of a 15-day backcheck.

## 6. Identification and graphics

- **Revision marks (BP-2).** Triangle (equilateral) holding the amendment number 3 beside a 0.35 mm cloud (Graphics Standard section 7.2; FC 1-300-09N paragraph 18-5.1). Revision (Issue) block entry: MARK 3, DESCRIPTION REVISED IN ACCORDANCE WITH AMDT 0003, DATE SEP 2026 in the MMM YYYY form of section 7.3, entered on the next line above the existing entries. Added sheets have no prior issue to revise and carry no revision entry; they are listed as added on the drawing index and in Document 00 01 15. BP-3 sheets carry no revision graphics because the corrections are made before advertisement.
- **Sheet identification and added sheets.** Existing sheet numbers are not changed (FC 1-300-09N paragraph 18-5.1). Added sheets take the discipline designator, the sheet type designator of CAD Standard Table 2-4 and the next free two-digit sequence number (section 2.4.4): S-202 (type 2, elevations), M-503 (type 5, details), A-402 (type 4, large-scale views) and M-502 (type 5, details). Free numbers exist after S-201, M-502, A-401 and M-501, so no supplemental letter suffix is needed (section 2.4.4.1), and BP-3 is named in final form before advertisement as that section asks.
- **Callout-to-sheet-type coupling.** The new callouts follow Graphics Standard sections 4.2.4.2 to 4.2.4.4: the elevation callout on S-101 points to an XX2NN sheet (S-202), the detail callouts on M-401 and M-101 point to XX5NN sheets (M-503, M-502) and the enlarged-plan callout on A-101 points to an XX4NN sheet (A-402).
- **Index order.** CAD Standard section 2.4.4.2 with Table 2-3: discipline designators in table order (G-, GI, C-, S-, A-, M-, E-, T-), with general notes, abbreviation and legend sheets ahead of the rest of their designator group (GI-002 before GI-001, M-003 before M-001, E-004 before E-001, A-002 before A-001), then sheet type and sequence. The SORT_ORDER of the export is the authoring tool's alphabetical sort and was not used.
- **(a) Revision-graphics layers.** The two documents appear to disagree: the A/E/C CAD Standard Release 6.2 Appendix A general layer table lists G-ANNO-REVC (revision clouds) and G-ANNO-REVS (revision indicators and text), while FC 1-300-09N paragraph 12-3.6.1 places the revision cloud on Z-ANNO-REVC ("place it on layer Z-ANNO-REVC") and the revision symbols, notes and Revision (Issue) block text on Z-ANNO-REVS. FC 1-300-09N paragraph 12-3.3.4 fixes the order of precedence for CAD standards (it opens: "CAD standards order of precedence are the requirements of this Chapter"): FC Chapter 12 first, then the latest A/E/C CAD and Graphics Standards, then the National CAD Standard. The FC requirement therefore prevails and the layers actually used for the BP-2 amendment graphics are **Z-ANNO-REVC** for the clouds and **Z-ANNO-REVS** for the triangles and the Revision (Issue) block entries. SR-21-6's G-layer statement belongs to its record-package deliverable guidance, which the CO memorandum did not adopt. BP-3 has no revision graphics, so no revision layer is used there.

## 7. (c) Revision (Issue) block overflow decision - BP-2

The Revision (Issue) block of the standard border has a capacity of **eight rows** (Graphics Standard section 7.3: the Center's block "provides eight rows for identifying revisions"). Six BP-2 sheets in this amendment already hold eight entries (modifications A to F and amendments 1 and 2): C-101, M-101, M-501, S-101, S-102, S-502. Section 7.3 offers Option 1, replace the oldest entry (the preferred option, with displaced entries copied outside the plotted area), and Option 2, continue the entries above the eighth row into the drawing area. The note closing section 7.3 ("The option that is chosen shall remain consistent across the entire drawing set") requires one option for the whole set, so the choice is made once for the BP-2 set and applied to every overflowing sheet rather than sheet by sheet. **Option 2 was taken** (row position 9 on the six full sheets). Cost reason: Option 1 would cost 520 USD on each of the six full sheets, 3,120.00 USD; Option 2 costs 880 USD only where the spilled entries run into a drawing area holding three or more drawing blocks - S-502 (four blocks) and M-501 (three blocks), 1,760.00 USD - while C-101, S-101, S-102 and M-101 have a single drawing block and an unoccupied spill area at no charge. Option 1 was rejected because it costs 1,360.00 USD more for the same set.

## 8. Title blocks of the re-issued sheets

Checked against FC 1-300-09N paragraph 12-4.1 (checker initials must differ from designer and drafter initials; the seal must be that of the discipline responsible for the sheet) and paragraph 2-5 (sealing only by the professional registered in that field). Non-compliant sheets in this issue:

- BP-2 S-301: drawn by RCM and checked by RCM - CHK_EQUALS_DRW.
- BP-2 E-501: electrical details sheet under a mechanical seal - SEAL_DISCIPLINE_MISMATCH.
- BP-3 A-501: designed by HGB and checked by HGB - CHK_EQUALS_DES.
- BP-3 M-101: mechanical CRAH plan under an electrical seal - SEAL_DISCIPLINE_MISMATCH.

All other re-issued sheets comply; the general sheets carry the architect's seal as lead discipline. C-102 (checker equals designer) and T-101 (checker equals drafter) are defective but are not re-issued in this issue; they are noted for the next issue. The four added sheets will be drawn, checked and sealed by different individuals of the responsible discipline.

## 9. Packaging and schedule

Each delivered drawing PDF is held to 50 MB (signed) and 50 sheets (FC 1-300-09N paragraph 12-3.5.1), sized from PLOT_PDF_MB in the index exports (5.5 MB for an added sheet), and a discipline set is never split across files (paragraph 12-3.5.2.1). BP-2 disciplines: C 12.5 MB, S 38.3 MB, M 46.0 MB, E 20.1 MB; the only three-file packing is {C, E}, {S}, {M}. BP-3 disciplines: S 12.7, A 43.8, M 19.3, E 10.5, T 3.2 MB; packed as {S, M, E, T} and {A}. File names follow paragraphs 12-3.5.5 and 12-3.5.6 (job number, amendment number for BP-2, dwg, and the x-of-y suffix). Production starts on 2026-08-31 at 4 sheets per day, 3 days per delivered bundle and 1 day per non-concurrence; the finish date is taken as the start date plus the production days, and D is the number of days that finish falls after the deadline (controlling date less the window).

## 10. Cost ledger (published rates)

| Line | BP-2 (USD) | BP-3 (USD) |
|---|---|---|
| bundles_usd | 14,400.00 | 9,600.00 |
| sheets_usd | 18,528.64 | 20,053.04 |
| added_sheets_usd | 12,800.00 | 12,800.00 |
| revision_marks_usd | 3,120.00 | 0.00 |
| overflow_option_usd | 1,760.00 | 0.00 |
| non_concurrence_usd | 2,400.00 | 2,400.00 |
| delay_usd | 2,740.00 | 0.00 |
| total_usd | 55,748.64 | 44,853.04 |

BP-2 sheets line: 13 x 1,150 plus 26 USD x 137.64 square inches of incorporated markup extent. BP-3 sheets line: 14 x 1,150 plus 26 USD x 152.04 square inches. Markup extents are the drawn annotation outlines on each sheet; extents of void, elevated and non-concurred markups are not charged. Combined total for both packages: 100,601.68 USD.
