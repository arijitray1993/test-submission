# Method of Procedure - PCW Cleaning, Flushing and Passivation
Tull Creek Data Hall - Process Cooling Water (PCW) loop, circuits C1 to C8. Prepared by the flushing contractor commissioning engineer under Section 23 25 16 Rev 3 (cl.1.6).

All times are hours from mobilisation (TM-0 = hour 0). Calendar day k = hours [24k, 24k+24); crew shift k = hours [12k, 12k+12).

## 1. Governing constraints (design basis summary)

Margins are relative: (limit - achieved)/limit for an upper limit, (achieved - limit)/limit for a lower limit. The binding family for each circuit is the one with the least margin among the five families, each taken in its tightest permitted form (the rinse is stated in conductivity, the quantity of the UFC 3-230-13 rinse criterion, which is tighter than the displacement form for every circuit).

GOVERNING CONSTRAINT C1: authorised programme discharge volume (margin 0.00743)
GOVERNING CONSTRAINT C2: authorised programme discharge volume (margin 0.00743)
GOVERNING CONSTRAINT C3: authorised programme discharge volume (margin 0.00743)
GOVERNING CONSTRAINT C4: authorised programme discharge volume (margin 0.00743)
GOVERNING CONSTRAINT C5: authorised programme discharge volume (margin 0.00743)
GOVERNING CONSTRAINT C6: authorised programme discharge volume (margin 0.00743)
GOVERNING CONSTRAINT C7: authorised programme discharge volume (margin 0.00743)
GOVERNING CONSTRAINT C8: authorised programme discharge volume (margin 0.00743)

| Circuit | Skid head margin (stage, skid) | Rinse margin, conductivity (C_n vs 676.5 microS/cm) | Rinse margin, displacements (n vs n_min) | Discharge volume margin (sewer vs 500,000 gal) | Daily water margin (worst day drawn) | Power margin (peak kW / available) | Binding |
|---|---|---|---|---|---|---|---|
| C1 | 0.2471 (CHEM_CLEAN, FS-1200-A: 89.1 ft req / 118.4 ft avail) | 0.0198 (C_6 = 663.1) | 0.0707 (6 vs 5.604) | 0.0074 (496,284 gal) | 0.0504 (day 10: 87,360 of 92,000 gal) | 0.5000 (75 of 150 kW at MER-1) | authorised programme discharge volume |
| C2 | 0.6279 (DRAIN_RINSE, FS-600-A+FS-600-B: 59.8 ft req / 160.8 ft avail) | 0.0198 (C_6 = 663.1) | 0.0707 (6 vs 5.604) | 0.0074 (496,284 gal) | 0.1372 (day 9: 79,380 of 92,000 gal) | 0.5000 (75 of 150 kW at MER-1) | authorised programme discharge volume |
| C3 | 0.5389 (DRAIN_RINSE, FS-600-A+FS-600-B: 70.9 ft req / 153.8 ft avail) | 0.0198 (C_6 = 663.1) | 0.0707 (6 vs 5.604) | 0.0074 (496,284 gal) | 0.0504 (day 10: 87,360 of 92,000 gal) | 0.2105 (75 of 95 kW at MER-2) | authorised programme discharge volume |
| C4 | 0.3467 (CHEM_CLEAN, FS-600-B: 100.3 ft req / 153.5 ft avail) | 0.0107 (C_8 = 669.2) | 0.0362 (8 vs 7.721) | 0.0074 (496,284 gal) | 0.4535 (day 13: 50,277 of 92,000 gal) | 0.6667 (30 of 90 kW at L3-N) | authorised programme discharge volume |
| C5 | 0.0336 (CHEM_CLEAN, FS-600-A: 130.2 ft req / 134.7 ft avail) | 0.0107 (C_8 = 669.2) | 0.0362 (8 vs 7.721) | 0.0074 (496,284 gal) | 0.0504 (day 10: 87,360 of 92,000 gal) | 0.6667 (30 of 90 kW at L3-S) | authorised programme discharge volume |
| C6 | 0.3262 (CHEM_CLEAN, FS-600-B: 103.4 ft req / 153.5 ft avail) | 0.0289 (C_8 = 656.9) | 0.1190 (8 vs 7.149) | 0.0074 (496,284 gal) | 0.3010 (day 14: 64,311 of 92,000 gal) | 0.6667 (30 of 90 kW at L3-W) | authorised programme discharge volume |
| C7 | 0.3361 (CHEM_CLEAN, FS-600-A: 108.2 ft req / 163.0 ft avail) | 0.0107 (C_8 = 669.2) | 0.0362 (8 vs 7.721) | 0.0074 (496,284 gal) | 0.3010 (day 14: 64,311 of 92,000 gal) | 0.3333 (30 of 45 kW at ROOF) | authorised programme discharge volume |
| C8 | 0.1405 (CHEM_CLEAN, FS-600-A: 144.6 ft req / 168.2 ft avail) | 0.0359 (C_6 = 652.2) | 0.1563 (6 vs 5.189) | 0.0074 (496,284 gal) | 0.3010 (day 14: 64,311 of 92,000 gal) | 0.7500 (30 of 120 kW at YARD) | authorised programme discharge volume |

The authorised programme discharge volume binds every circuit: with the seven-link rinse cascade the programme sewers 496,284 gal against the 500,000 gal SW-03 Rev B cap (margin 0.0074). Without the cascade chain the sewered total would be 534,550 gal and the cap would be exceeded; under the superseded 540,000 gal figure (quoted in RFI-031) the plan would appear to have 0.0101 margin, which is not the authorised value. The next-tightest constraint is the rinse endpoint (0.0107 for C4, C5, C7; 0.0198 for C1-C3; 0.0289 for C6; 0.0359 for C8), then the C5 skid head (0.0336).

## 2. Documents applied and documents rejected

Applied (current, adopted): Section 23 25 16 Rev 3 (governing), 23 21 16 Rev 3, 01 91 13 Rev 2; UFC 3-230-13 (1 March 2023) as the governing water-treatment criteria; DOE-HDBK-1012/3-92 for hydraulics; 40 CFR 403 for the POTW discharge; 29 CFR 1910.1200 for hazard communication; drawings M-PID-101, 102, 103, 104 Rev C, M-ISO-201 to 204 Rev C, E-701 Rev B, C-101 Rev B; schedules M-601, M-602, M-603 Rev C; SW-01, SI-04, SI-05, SW-02, SW-03 Rev B (with the local limits and general conditions of authorization IWD-2026-0417 that Rev B keeps in force), SW-04 Rev B; VD-01 to VD-07 (VD-06 Rev B); CX-01 Rev B, CX-02 with the pressure charts on file, CX-03 log form; RFI-022 and RFI-031 (rates and route).

Read and rejected (not cited as authority anywhere in the register):
- UFC 3-240-13FN (2005) - cancelled; Section 23 25 16 cl.1.2 forbids its use. Its passivation tables (4-14/4-15) and closed-system text duplicate the 2023 edition, so nothing in this plan depends on it.
- M-PID-103 Rev A (marked SUPERSEDED) - replaced by Rev C (M-601 Note 5). Rev A shows line 4033 as two legs inside C4; Rev C places 4033 (three legs, matching M-601) in C5. Rev C is used.
- SW-03 original issue of IWD-2026-0417 as a source of the authorised volume - its 540,000 gal programme total is superseded by SW-03 Rev B cl.2 (500,000 gal). Its local limits and general conditions are applied only through SW-03 Rev B cl.3, which keeps them in force.
- The 540,000 gal cap stated in RFI-031 (issued 2026-07-06, before SW-03 Rev B of 2026-07-21) - superseded; RFI-031 is used only for the route (MH-14), the tanker rate and tanker standing.
- 40 CFR 122 (NPDES) - not adopted; the discharge is to the POTW under 40 CFR 403 and SW-03 states it is not an NPDES permit.
- Section 22 11 23 (domestic water pumps) - domestic water is not part of the PCW system.
- VD-08 (air-cooled chiller) - comfort cooling, not part of the PCW loop.
- RFI-009 (roof curb flashing) - roofing only, no mechanical content.
- UFC 3-230-13 Table 5-11 and Table 5-8 - written for open recirculating cooling (different duty); the passivation tables 5-14/5-15 and the closed-system Table 6-3 govern (23 25 16 cl.1.1, cl.3.5).

## 3. Circuit definition (from the P&IDs; lines are not tabulated by circuit anywhere)

| Circuit | Tie-ins / location | Lines (legs) | Components (bypass provision) | Static lift | Flush volume V_f (gal) | System volume V_s (gal) | Metallurgy |
|---|---|---|---|---|---|---|---|
| C1 | TI-C1-01/02, MER-1 | 1041(1), 1042(1), 1043(4), 1044(4) | PMP-101 (in path), BT-101 (in path) | 26 ft (M-ISO-201) | 32,983.4 | 32,983.4 | carbon steel |
| C2 | TI-C2-01/02, MER-1 | 2011(1), 2012(1), 2013(3) | HX-201A (bypass) | 22 ft (M-ISO-201) | 5,596.0 | 7,946.0 | carbon steel, stainless/nitrile PHE (bypassed) |
| C3 | TI-C3-01/02, MER-2 | 2021(1), 2022(1), 2023(2) | HX-201B (bypass) | 22 ft (M-ISO-202) | 6,203.2 | 8,553.2 | carbon steel, stainless/nitrile PHE (bypassed) |
| C4 | TI-C4-01/02, L3-N | 4021(1), 4022(1), 4023(2), 4024(4) | CDU-301 (bypass), CP-311 (bypass) | 48 ft (M-ISO-203) | 5,956.6 | 8,536.6 | carbon steel, copper pipe 4024, copper CDU/cold plates (bypassed) |
| C5 | TI-C5-01/02, L3-S | 4031(1), 4032(1), 4033(3), 4034(4) | CDU-302 (bypass), CP-321 (bypass) | 44 ft (M-ISO-203) | 6,405.8 | 8,985.8 | carbon steel, copper pipe 4034, copper CDU/cold plates (bypassed) |
| C6 | TI-C6-01/02, L3-W | 4041(1), 4042(1), 4043(3) | CP-331 (bypass) | 48 ft (M-ISO-203) | 4,227.1 | 5,677.1 | carbon steel, copper pipe 4043, aluminium/copper cold plates CP-331 (bypassed) |
| C7 | TI-C7-01/02, ROOF | 5011(1), 5012(1), 5013(4) | CL-401 (bypass) | 72 ft (M-ISO-204) | 4,086.0 | 6,036.0 | carbon steel, copper pipe 5013, copper coil bank (fins dry) |
| C8 | TI-C8-01/02, YARD | 6011(1), 6012(1), 6013(2) | ST-601 (in path) | 14 ft (M-ISO-202) | 5,790.8 | 5,790.8 | hot-dip galvanized steel (RFI-022) |

Volumes: pipe volume = legs x length per leg x inside area (M-601 IDs); V_f adds the hold-up of components left in the flushed path (PMP-101, BT-101, ST-601); V_s adds every component hold-up (M-602).

## 4. Design basis

### 4.1 Hydraulic basis
DOE-HDBK-1012/3-92 relations with the 23 25 16 cl.3.2 conventions: nu = 1.08e-5 ft2/s, rho = 62.30 lbm/ft3, g = 32.174 ft/s2; Colebrook-White solved iteratively with the 23 21 16 cl.2.2 roughness (CS 0.00015 ft, galvanized 0.0005 ft, copper 0.000005 ft, lay-flat hose 0.0008 ft); Darcy loss over L + (sum L/D) x D; required head = static lift (M-ISO) + single-leg main lines at total flow + components left in path dP_rated(Q/Q_rated)^2 + per skid 300 ft of hose and the VD-05 strainer (11 ft at 600 gpm, scaled) at the skid share. Skid head is interpolated linearly in the VD-01/VD-02 tables; no duty point lies beyond the last published point.

### 4.2 Flushing flow, governing segment and skid check
Required velocity in every leg of every line = max(3.28 ft/s, UFC 3-230-13 para 5-3.7 suspension velocity; project class 4.0 ft/s for circuits serving a PHE or cold plate, 2.0 ft/s otherwise).

| Circuit | Required v | Min flow (gpm) | Declared flow (gpm) | Governing segment (ID) | v at governing (ft/s) | Re | Skid(s) | Required head (ft) | Skid head (ft) | Head margin |
|---|---|---|---|---|---|---|---|---|---|---|
| C1 | 3.28 | 1181.4 | 1190 | 1043 (6.065 in.) | 3.304 | 154,611 | FS-1200-A | 89.15 | 118.40 | 0.2471 |
| C2 | 4.00 | 623.7 | 630 | 2011 (7.981 in.) | 4.040 | 248,810 | FS-1200-A | 49.32 | 185.10 | 0.7335 |
| C3 | 4.00 | 720.4 | 725 | 2023 (6.065 in.) | 4.026 | 188,392 | FS-1200-A | 57.09 | 175.92 | 0.6755 |
| C4 | 4.00 | 360.2 | 365 | 4021 (6.065 in.) | 4.053 | 189,691 | FS-600-B | 100.25 | 153.47 | 0.3467 |
| C5 | 4.00 | 476.1 | 477 | 4033 (4.026 in.) | 4.007 | 124,482 | FS-600-A | 130.17 | 134.70 | 0.0336 |
| C6 | 4.00 | 360.2 | 365 | 4041 (6.065 in.) | 4.053 | 189,691 | FS-600-B | 103.41 | 153.47 | 0.3262 |
| C7 | 3.28 | 295.4 | 300 | 5011 (6.065 in.) | 3.332 | 155,910 | FS-600-A | 108.21 | 163.00 | 0.3361 |
| C8 | 3.28 | 151.2 | 240 | 6013 (3.068 in.) | 5.208 | 123,285 | FS-600-A | 144.56 | 168.20 | 0.1405 |

Stages run on a different skid set from the cleaning circulation (same flow): C2 DRAIN_RINSE on FS-600-A+FS-600-B (head margin 0.6279); C2 PASSIVATE on FS-600-A+FS-600-B (head margin 0.6279); C3 DRAIN_RINSE on FS-600-A+FS-600-B (head margin 0.5389); C3 PASSIVATE on FS-600-A+FS-600-B (head margin 0.5389); C4 FINAL_FILL on FS-600-A (head margin 0.3467); C6 DRAIN_RINSE on FS-600-A (head margin 0.3262); C6 PASSIVATE on FS-600-A (head margin 0.3262); C6 FINAL_FILL on FS-600-A (head margin 0.3262). Parallel FS-600 units share the flow equally and each develops the required head at its own share (23 25 16 cl.3.2 e).

Why these skids: an FS-600 cannot serve C1 (two FS-600 in parallel need 125 ft at 593 gpm each against 108 ft available - the 4 in. hose loss governs), so C1 is on FS-1200-A. C7 at ROOF has 45 kW: one FS-600 (30 kW) only. C5 runs one FS-600 at 477 gpm, just above the 476.1 gpm needed for 4.0 ft/s in the three 4 in. legs of 4033, with 0.034 head margin. C8 is capped at 244.9 gpm by the ST-601 25 ft maximum allowable dP (6 ft at 120 gpm); 240 gpm gives 24.0 ft. Flows are held through flush, clean and rinse (cl.3.3) and are also used for the passivation and turnover recirculation, so every pumped row meets the flushing velocity.

Components left in the flushed path at the declared flow: PMP-101 and BT-101 are full-bore (dP 0 ft vs 40/15 ft allowed, M-602 Note 5), 68 degF << 200 degF, strainer 380 micron < 800 micron; ST-601 24.0 ft vs 25 ft, 68 degF < 140 degF, 380 < 800 micron. All other components are on full-size bypass spools.

### 4.3 Power check (SW-04 Rev B / E-701 Rev B)
- MER-1: 150 kW available; circuits C1, C2; peak simultaneous connected load 75 kW (skids FS-1200-A, FS-600-A, FS-600-B); margin 0.5000.
- MER-2: 95 kW available; circuits C3; peak simultaneous connected load 75 kW (skids FS-1200-A, FS-600-A, FS-600-B); margin 0.2105.
- L3-N: 90 kW available; circuits C4; peak simultaneous connected load 30 kW (skids FS-600-A, FS-600-B); margin 0.6667.
- L3-S: 90 kW available; circuits C5; peak simultaneous connected load 30 kW (skids FS-600-A); margin 0.6667.
- L3-W: 90 kW available; circuits C6; peak simultaneous connected load 30 kW (skids FS-600-A, FS-600-B); margin 0.6667.
- ROOF: 45 kW available; circuits C7; peak simultaneous connected load 30 kW (skids FS-600-A); margin 0.3333.
- YARD: 120 kW available; circuits C8; peak simultaneous connected load 30 kW (skids FS-600-A); margin 0.7500.
Only one pumped activity runs at a time at MER-1 (C1 and C2 share the panel), so the MER-1 load never exceeds 75 kW.

### 4.4 Chemical cleaning
CL-100 alkaline pre-operational cleaner at 1.5 gal per 1,000 gal of system volume for the carbon steel/copper circuits C1, C2, C3, C4, C5 and C7; CL-210 neutral-pH cleaner at 2.0 gal per 1,000 gal for C6 (aluminium cold plates CP-331) and C8 (galvanized, RFI-022). The C7 coil bank has aluminium fins on the dry air side only (VD-04 note 4), so C7 is not an aluminium system. Cleaners are dosed volumetrically on V_s with target residual N/A (VD-06 Note 4a). PD-45 polyacrylate dispersant is carried at 4.5 ppm active polymer on V_s (UFC 3-230-13 para 5-3.7: about 4 to 5 ppm with 3.28 ft/s). Circulation is 24.0 occupied hours (para 5-7.3.2.2 b), then drain, flush and clean all strainers. Spent-solution conductivity: 2,600 microS/cm (CL-100), 2,150 (CL-210) (VD-06 Note 3).

### 4.5 Treatment programme selection
SW-02: Cl 505 + SO4 355 = 860 mg/L, so nitrite-azole is excluded (> 800 ppm, para 6-2.2.2) and nitrite-molybdate-azole is excluded (860 > (NO2 + Mo) - 100 = 375 ppm, para 6-2.2.4); NB-700 is therefore not ordered (VD-06 Note 4). Sulfite-caustic is a hot-water programme. Silica is 11 mg/L (< 150 mg/L), so silicate is admissible. Polysilicate-azole is selected for all eight circuits: it is the programme the criteria recommend where aluminium is present (para 6-2.2.5; required for C6 by VD-04 note 1), it suits galvanized steel (para 5-7.3.2, pH kept <= 8.5 for white rust), its residual (silica) has no SW-03 local limit, and it is cheaper than molybdate-azole (lower residual, cheaper active). The Table 6-2 listing of polysilicate-azole under diesel jacket systems does not restrict it (23 25 16 cl.3.5: paragraph text governs). Tolyltriazole is carried wherever copper is wetted (C4, C5, C6, C7).

### 4.6 Passivation and film-formation hold
UFC 3-230-13 para 5-7.3.2.4 identifies Tables 5-14 and 5-15 for passivation. Polysilicate 40-50 ppm as SiO2, pH 7.5-8.5, film formation 14-21 days (Table 5-15); tolyltriazole 10-20 ppm as TTA, pH 6.5-7.9 (Table 5-14). Dose on V_s (cl.3.5): PS-330 at 42 ppm (C1) or 45 ppm (others) SiO2, TA-90 at 15 ppm TTA on copper circuits. pH control band 7.5-8.5, or 7.5-7.9 (the intersection with the TTA band, cl.3.8) on C4-C7. Hold = 14 days (336 occupied hours) minimum; actual holds run from the end of passivation to the start of turnover and are all between 336 h and 504 h (21 days). Skids are released during the hold; the hold is unattended.

### 4.7 Rinse displacements and cascade
Criterion (UFC 3-230-13 para 5-7.3.2.2 e): conductivity within 10 percent of makeup -> <= 676.5 microS/cm; pH within 0.3 of makeup 7.6 (7.3-7.9) and within 7.5-8.5: control band 7.5-7.9 satisfies both readings (cl.3.6). Model C_n = 615 + (C_0 - 615) exp(-eta n), eta 0.45 for circuits with a cold-plate manifold bank or coil bank (C4, C5, C6, C7), 0.62 otherwise.

| Circuit | eta | C_0 | n_min (real) | n_r | C_n (microS/cm) | Water source | Rinse draw (gal) | Rinse effluent (gal) |
|---|---|---|---|---|---|---|---|---|
| C1 | 0.62 | 2600 | 5.604 | 6 | 663.1 | MAKEUP | 197,900.4 | 158,511.2 |
| C2 | 0.62 | 2600 | 5.604 | 6 | 663.1 | CASCADE_FROM:C8 | 27,980.2 | 23,753.0 |
| C3 | 0.62 | 2600 | 5.604 | 6 | 663.1 | CASCADE_FROM:C5 | 31,016.0 | 25,059.3 |
| C4 | 0.45 | 2600 | 7.721 | 8 | 669.2 | CASCADE_FROM:C3 | 41,696.4 | 35,905.7 |
| C5 | 0.45 | 2600 | 7.721 | 8 | 669.2 | CASCADE_FROM:C1 | 44,840.8 | 38,637.6 |
| C6 | 0.45 | 2150 | 7.149 | 8 | 656.9 | CASCADE_FROM:C2 | 29,590.0 | 25,504.1 |
| C7 | 0.45 | 2600 | 7.721 | 8 | 669.2 | CASCADE_FROM:C6 | 28,601.7 | 28,601.7 |
| C8 | 0.62 | 2150 | 5.189 | 6 | 652.2 | CASCADE_FROM:C4 | 28,953.8 | 23,357.7 |

Cascade chain (donor -> receiver): C1 -> C5 (6,406 gal), C5 -> C3 (6,203 gal), C3 -> C4 (5,957 gal), C4 -> C8 (5,791 gal), C8 -> C2 (5,596 gal), C2 -> C6 (4,227 gal), C6 -> C7 (4,086 gal). Each receiver takes exactly one cascaded displacement, each donor donates once, every donor V_f is not less than its receiver V_f, and each receiver rinse starts after its donor rinse has finished (schedule predecessors). The chain is the only seven-link arrangement (it must run in descending V_f order) and removes 38,266 gal from both the draw and the sewer.

### 4.8 Discharge routing (SW-03 Rev B, 40 CFR 403)
- Spent cleaning solution from circuits whose flushed path includes copper pipe (C4 line 4024, C5 4034, C6 4043, C7 5013) carries 3.4 mg/L (CL-100) or 1.6 mg/L (CL-210) copper > 1.0 mg/L local limit: HAUL by vacuum tanker from the YARD pad (RFI-031, C-101).
- Spent CL-210 from galvanized C8 carries 5.5 mg/L zinc > 1.0 mg/L: HAUL.
- Spent CL-100 from C1, C2, C3 (carbon steel; copper/zinc not detectable; pH 8.4): SEWER to MH-14.
- Hydrostatic test water, initial flush and rinse effluent (pH 7.6-8.4, 68 degF): SEWER to MH-14, batch-sampled before release; volume, pH and temperature recorded for every event (SW-03 general conditions 3-4).
- Passivation charge is retained (RETAIN_AND_TOP_UP), so no silicate or azole effluent is produced; no molybdate is used anywhere.
- Totals: sewer 496,284.1 gal (cap 500,000; margin 0.0074); haul 26,466.3 gal.

### 4.9 Water
Total draw 607,259 gal: 553,938 gal metered, 53,321 gal trucked. Daily limits: 92,000 gal (62,000 metered + 30,000 trucked); 61,000 gal on days 2-3 and 30,000 gal on day 6 (SI-04). The plan keeps every day at or below 97 percent of its limit. Daily profile (gal): d5 20,922, d7 65,326, d8 66,944, d9 79,380, d10 87,360, d11 55,836, d12 42,433, d13 50,277, d14 64,311, d15 61,210, d30 13,260.

### 4.10 Turnover
RETAIN_AND_TOP_UP on every circuit (permitted: polysilicate maintenance 80-100 ppm is not below passivation 40-50 ppm; TTA maintenance 15 ppm equals passivation 15 ppm). Each circuit is topped up from V_f to V_s (C1 and C8 have no bypassed hold-up, so the top-up volume is zero) with makeup carrying the increment to 84 ppm (C1) or 90 ppm (others) SiO2; the retained charge already carries 15 ppm TTA on V_s. Recirculate 30 minutes and sample while circulating (cl.3.8). Maintenance pH acceptance limits 7.5-8.9 (7.5-8.5 for C6 per VD-04 and C8 galvanized); the control band is 7.5-7.9 on the copper circuits C4-C7 (inside both the programme band and the TTA band, cl.3.8), 7.5-8.5 on C8 and 7.5-8.9 on C1-C3.

## 5. Execution narrative and schedule

Sequence per circuit: [HYDRO where owed] -> INITIAL_FLUSH (1 displacement) -> CHEM_CLEAN (24 occupied hours of circulation with PD-45; strainers cleaned; spent solution held in the isolated circuit until its rinse slot) -> DRAIN_RINSE (first fill displaces the spent solution to its declared route; n_r displacements, last one left in the circuit) -> PASSIVATE (charge dosed into the standing water, V_f circulated plus 30 min) -> HOLD (unattended, >= 336 h) -> FINAL_FILL (top-up to V_s, 30 min recirculation, sample) -> strainer and spool removal at TM-4.

Hydrostatic tests are owed for C3, C5, C6 and C7 only: CX-02 records all eight as passed, but the cited charts TR-0414, TR-0416, TR-0417 and TR-0418 are not on file, so under 01 91 13 cl.1.3 those results are not accepted. TR-0412, TR-0413, TR-0415 and TR-0419 are on file and show 127.5 psig for 120 minutes with no loss, so C1, C2, C4 and C8 are not retested (23 21 16 cl.3.3). Test: 127.5 psig (1.5 x 85 psig operating, not less than 125 psig) held 120 minutes with no loss of pressure and no visible leakage, below the lowest rating in each tested circuit (HX-201B 230 psig, piping and other components 300 psig) and below the 150 psig rating of any temporary equipment, using the contractor test pump and chart recorder (excluded item); the new charts are filed with CX-02 before cleaning starts.

Activity list (hours from mobilisation):

| Activity | Circuit | Stage | Start | Finish | Skid | Crew | Water (gal) |
|---|---|---|---|---|---|---|---|
| A001 | C3 | HYDRO | 132.000 | 134.000 | - | CREW-A | 6,203 |
| A002 | C5 | HYDRO | 134.000 | 136.000 | - | CREW-A | 6,406 |
| A003 | C6 | HYDRO | 136.000 | 138.000 | - | CREW-A | 4,227 |
| A004 | C7 | HYDRO | 138.000 | 140.000 | - | CREW-A | 4,086 |
| A005 | C1 | INITIAL_FLUSH | 168.000 | 168.466 | FS-1200-A | CREW-A | 32,983 |
| A006 | C1 | CHEM_CLEAN | 168.466 | 192.466 | FS-1200-A | CREW-A | 32,983 |
| A007 | C1 | DRAIN_RINSE | 192.466 | 193.247 | FS-1200-A | CREW-A | 55,438 |
| A008 | C2 | INITIAL_FLUSH | 193.247 | 193.399 | FS-1200-A | CREW-A | 5,596 |
| A009 | C2 | CHEM_CLEAN | 193.399 | 217.399 | FS-1200-A | CREW-A | 5,596 |
| A010 | C1 | DRAIN_RINSE | 217.399 | 218.347 | FS-1200-A | CREW-A | 67,292 |
| A011 | C3 | INITIAL_FLUSH | 218.347 | 218.493 | FS-1200-A | CREW-A | 6,203 |
| A012 | C3 | CHEM_CLEAN | 218.493 | 242.493 | FS-1200-A | CREW-A | 6,203 |
| A013 | C1 | DRAIN_RINSE | 242.493 | 243.552 | FS-1200-A | CREW-A | 75,171 |
| A014 | C1 | PASSIVATE | 243.552 | 244.519 | FS-1200-A | CREW-A | 0 |
| A015 | C5 | INITIAL_FLUSH | 244.519 | 244.747 | FS-600-A | CREW-A | 6,406 |
| A039 | C1 | HOLD | 244.519 | 720.000 | - | - | 0 |
| A016 | C5 | CHEM_CLEAN | 244.747 | 268.747 | FS-600-A | CREW-A | 6,406 |
| A017 | C5 | DRAIN_RINSE | 268.747 | 270.545 | FS-600-A | CREW-A | 44,841 |
| A018 | C5 | PASSIVATE | 270.545 | 271.274 | FS-600-A | CREW-A | 0 |
| A019 | C8 | INITIAL_FLUSH | 271.274 | 271.680 | FS-600-A | CREW-A | 5,791 |
| A047 | C5 | HOLD | 271.274 | 722.253 | - | - | 0 |
| A020 | C8 | CHEM_CLEAN | 271.680 | 295.680 | FS-600-A | CREW-A | 5,791 |
| A021 | C3 | DRAIN_RINSE | 295.680 | 296.541 | FS-600-A+FS-600-B | CREW-A | 31,016 |
| A022 | C3 | PASSIVATE | 296.541 | 297.188 | FS-600-A+FS-600-B | CREW-A | 0 |
| A023 | C4 | INITIAL_FLUSH | 297.188 | 297.464 | FS-600-B | CREW-A | 5,957 |
| A043 | C3 | HOLD | 297.188 | 721.071 | - | - | 0 |
| A024 | C4 | CHEM_CLEAN | 297.464 | 321.464 | FS-600-B | CREW-A | 5,957 |
| A025 | C4 | DRAIN_RINSE | 321.464 | 323.648 | FS-600-B | CREW-A | 41,696 |
| A026 | C4 | PASSIVATE | 323.648 | 324.425 | FS-600-B | CREW-A | 0 |
| A027 | C6 | INITIAL_FLUSH | 324.425 | 324.622 | FS-600-B | CREW-A | 4,227 |
| A045 | C4 | HOLD | 324.425 | 721.630 | - | - | 0 |
| A028 | C6 | CHEM_CLEAN | 324.622 | 348.622 | FS-600-B | CREW-A | 4,227 |
| A029 | C8 | DRAIN_RINSE | 348.622 | 351.043 | FS-600-A | CREW-A | 28,954 |
| A030 | C8 | PASSIVATE | 351.043 | 351.950 | FS-600-A | CREW-A | 0 |
| A031 | C2 | DRAIN_RINSE | 351.950 | 352.844 | FS-600-A+FS-600-B | CREW-A | 27,980 |
| A053 | C8 | HOLD | 351.950 | 724.032 | - | - | 0 |
| A032 | C2 | PASSIVATE | 352.844 | 353.497 | FS-600-A+FS-600-B | CREW-A | 0 |
| A033 | C7 | INITIAL_FLUSH | 353.497 | 353.728 | FS-600-A | CREW-A | 4,086 |
| A041 | C2 | HOLD | 353.497 | 720.504 | - | - | 0 |
| A034 | C7 | CHEM_CLEAN | 353.728 | 377.728 | FS-600-A | CREW-A | 4,086 |
| A035 | C6 | DRAIN_RINSE | 377.728 | 379.279 | FS-600-A | CREW-A | 29,590 |
| A036 | C6 | PASSIVATE | 379.279 | 379.977 | FS-600-A | CREW-A | 0 |
| A037 | C7 | DRAIN_RINSE | 379.977 | 381.800 | FS-600-A | CREW-A | 28,602 |
| A049 | C6 | HOLD | 379.977 | 722.848 | - | - | 0 |
| A038 | C7 | PASSIVATE | 381.800 | 382.532 | FS-600-A | CREW-A | 0 |
| A051 | C7 | HOLD | 382.532 | 723.419 | - | - | 0 |
| A040 | C1 | FINAL_FILL | 720.000 | 720.504 | FS-1200-A | CREW-A | 0 |
| A042 | C2 | FINAL_FILL | 720.504 | 721.071 | FS-1200-A | CREW-A | 2,350 |
| A044 | C3 | FINAL_FILL | 721.071 | 721.630 | FS-1200-A | CREW-A | 2,350 |
| A046 | C4 | FINAL_FILL | 721.630 | 722.253 | FS-600-A | CREW-A | 2,580 |
| A048 | C5 | FINAL_FILL | 722.253 | 722.848 | FS-600-A | CREW-A | 2,580 |
| A050 | C6 | FINAL_FILL | 722.848 | 723.419 | FS-600-A | CREW-A | 1,450 |
| A052 | C7 | FINAL_FILL | 723.419 | 724.032 | FS-600-A | CREW-A | 1,950 |
| A054 | C8 | FINAL_FILL | 724.032 | 724.536 | FS-600-A | CREW-A | 0 |

Milestones: hydrostatic tests complete h140.0 (TM-1 h144); cleaning complete h377.7 (TM-2 h528); film formation complete h724.0 (TM-3 h1056); last activity h724.5 (TM-4 h1128, contractual).

Crews: CREW-A attends the activities in sequence (one activity at a time per crew), which packs the attended hours into consecutive shifts; not more than two crews are ever on the works. Skids: FS-1200-A from hour 48 only (SI-05). A unit serves one circuit at a time; it is released for the film-formation hold.

Skid and crew holding: FS-1200-A days [7, 8, 9, 10, 30]; FS-600-A days [10, 11, 12, 14, 15, 30]; FS-600-B days [12, 13, 14]; crew shifts CREW-A [11, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 60].

Log (23 25 16 cl.1.5, CX-03 form): for every circuit the minimum velocity and governing segment, the 40-mesh strainer and its removal at TM-4, the 24 h circulation record, the rinse results (clarity, TSS, conductivity, pH) against SW-02, the passivation SiO2/TTA residual and pH at the start of film formation and the hold duration, and every discharge event (volume, route, pH, temperature) are recorded and submitted with the acceptance matrix. SDS for every product are on site before delivery (CX-03 item 10).

## 6. Acceptance criteria (acceptance_matrix.csv)
- RINSE: conductivity <= 676.5 microS/cm; pH >= 7.5 and <= 7.9; clarity and SS to match makeup (UFC 3-230-13 para 5-7.3.2.2 e; SW-02).
- PASSIVATION: polysilicate residual >= 40 ppm as SiO2 at the start of film formation (Table 5-15); TTA >= 10 ppm on copper circuits (Table 5-14); pH 7.5-8.5 (7.5-7.9 with TTA); hold >= 336 h.
- DISCHARGE (at MH-14): pH >= 6.0 (and <= 9.0); temperature <= 104 degF; Cu, Zn <= 1.0 mg/L; Mo <= 0.5 mg/L; TSS <= 300 mg/L (SW-03 Rev B cl.3; more restrictive than 40 CFR 403.5(b)(2) pH 5.0 and 403.5(b)(5) 40 degC).
- TURNOVER: maintenance polysilicate residual >= 80 ppm as SiO2 (para 6-2.2.5); total aerobic bacteria <= 1,000 CFU/mL (< 10^3, Table 6-3 for closed systems; the 10^4 of Table 5-8 is for cooling towers and is not used); TTA >= 10 ppm on copper circuits.
Sample points: low-point drains DV-C1-01 ... DV-C8-01 (M-ISO), sampled while circulating; discharge samples at MH-14 before each batch release; hauled loads sampled at the tanker.

## 7. Conflicts between documents and their resolution
1. Discharge cap: RFI-031 (2026-07-06) states 540,000 gal; SW-03 Rev B (2026-07-21) supersedes the authorised volume with 500,000 gal. Resolution: 500,000 gal governs; the plan sewers 496,284 gal using the full cascade chain.
2. Hydrostatic record: CX-02 lists all eight circuits as PASS, but 01 91 13 cl.1.3 accepts a result only with its cited evidence on file; charts TR-0414/0416/0417/0418 are missing. Resolution: retest C3, C5, C6, C7 before cleaning (23 21 16 cl.3.3); do not retest C1, C2, C4, C8 (retesting an accepted circuit is a change in scope).
3. M-PID-103 Rev A vs Rev C: line 4033 shown in C4 (x2) on Rev A and in C5 (x3) on Rev C. Resolution: Rev C (M-601 Note 5, leg count matches M-601).
4. UFC Table 6-2 lists polysilicate-azole only for diesel jacket systems, while para 6-2.2.5 recommends it where aluminium is present (process cooling loops). Resolution: paragraph text governs (23 25 16 cl.3.5); polysilicate-azole used.
5. UFC tabulates inhibitor dosages in Table 5-11 (open cooling initial/maintenance, polysilicate 40-60 ppm, 10-12 days) and in Tables 5-14/5-15 (passivation, 40-50 ppm, 14-21 days). Resolution: the passivation tables govern (cl.3.5) -> 40-50 ppm, 14 days.
6. Rinse pH: UFC gives "+/-0.3 pH units from 7.5 to 8.5" (tolerance about makeup 7.6 -> 7.3-7.9, or window 7.5-8.5). Resolution: both readings are acceptable (cl.3.6); limits filed as 7.5 lower and 7.9 upper (intersection).
7. Passivation pH: polysilicate 7.5-8.5 vs tolyltriazole 6.5-7.9. Resolution: control to the intersection 7.5-7.9 on copper circuits (cl.3.8).
8. Bacteria limit: UFC Table 5-8 (cooling towers) < 10^4 CFU/mL vs Table 6-3 (closed systems) < 10^3. Resolution: closed system, 1,000 CFU/mL.
9. PHE pressure drop: VD-03 quotes 46 ft at 610 gpm; M-602 gives 58 ft as the maximum allowable. Resolution: 46 ft is the developed drop, 58 ft the limit (VD-03 note 5, M-602 Note 6); the PHEs are bypassed for flushing in any case.
10. Makeup hardness: UFC 3-230-13 Table 6-1 and step 1 of every closed-system programme (para 6-2.2.2 to 6-2.2.5) call for makeup softened below 250 mg/L total hardness for chilled systems; SW-02 reports 288 mg/L (not softened). Section 23 25 16 neither invokes softening nor bases a turnover method on softened water, and softening carries no line in the cl.3.10 cost basis. Resolution: the programme follows cl.3.8 with metered makeup; the exceedance does not change the programme selection (it applies equally to all four closed-system programmes) and is recorded for the Engineer by RFI, together with the base-building softened outlet SV-2 shown on C-101 (SF-1, 88,000 grains between daily regenerations, about 5,200 gal/day of softened water at 288 mg/L). If softened turnover water is directed, the RETAIN_AND_TOP_UP top-ups (largest 2,580 gal, total 13,260 gal) can be drawn through SV-2 on separate days within SF-1 capacity, which brings C2-C7 below 250 mg/L by dilution; C1 and C8 have no bypassed hold-up and would need their last rinse displacement drawn softened.
11. Discharge temperature: 40 CFR 403.5(b)(5) limits heat at the POTW (40 degC); SW-03 limits 104 degF at MH-14. Resolution: the more restrictive local limit at the discharge point is applied (SW-03 general condition 1). Likewise SW-03 pH 6.0 is applied in place of the 40 CFR 403.5(b)(2) pH 5.0 floor.
12. Water availability: SW-01 cl.1 gives 62,000 gal/day metered for every day; SI-04 (later instruction) reduces it to 31,000 gal on days 2-3 and 0 on day 6, trucked water unaffected. Resolution: SI-04 governs on those days (limits 61,000 and 30,000 gal); planned draws on days 2, 3 and 6 are day 2: 0 gal, day 3: 0 gal, day 6: 0 gal.
13. Skid delivery: SW-01 cl.3 makes all three units available to the scope; SI-05 (later) delivers FS-1200-A at hour 48. Resolution: no FS-1200-A activity before hour 48 (first use hour 168.0).
14. Aluminium cold plates: VD-04 limits fluid pH to 7.0-8.5 in service while the polysilicate-azole maintenance band is 7.5-8.9. Resolution: C6 is controlled to the intersection 7.5-8.5. Galvanized C8: UFC para 5-7.3.1 limits pH to 8.5 during cleaning and passivation; C8 is held at 7.5-8.5 throughout, including at turnover.
15. Water margin basis: SW-01 cl.2 states the daily limit is 92,000 gal and that the 62,000 gal metered allocation is the point where the price changes, not a limit; 23 25 16 cl.3.10 refers to the metered figure as the daily allocation. Resolution: the water margin in the design basis is measured against the SW-01 cl.2 limit of the day (92,000; 61,000 on days 2-3; 30,000 on day 6); trucked volumes above the metered allocation are priced at the trucked rate.

## 8. Defects found in the documents
- SW-02 is internally inconsistent: chloride 505 + sulfate 355 mg/L cannot coexist with a specific conductance of 615 microS/cm (those ions alone imply well over 1,500 microS/cm). The plan uses the reported values as instructed (615 microS/cm for the rinse model, Cl + SO4 = 860 for programme selection); the inconsistency should be referred to the laboratory, because a higher true conductivity would loosen the rinse endpoint and the Cl+SO4 exclusion of nitrite would stand either way.
- UFC 3-230-13 Table 5-14 prints the orthophosphate and tolyltriazole dosages in "days" ("20-30 days as PO4", "10-20 days as TTA"); read as ppm.
- UFC 3-230-13 Table 6-1 prints two hardness lines for chilled systems (< 250 and < 50 ppm); < 250 ppm is the figure repeated in para 6-2.1 and the programme steps.
- VD-03 numbers its notes 1, 5, 2, 3, 4 (note 5 out of order).
- VD-06 lists two different "Note 4" entries (4 and 4a).
- CX-02 cites pressure charts that are not filed (TR-0414, TR-0416, TR-0417, TR-0418).
- RFI-031 still quotes the superseded 540,000 gal programme total.
- M-PID-103 Rev A remains in the library although superseded (filename marked SUPERSEDED).
- M-602 lists HX-201A/B as "2 units" and CDU-301/302 as "4 units" against a single rated flow; the rated flow is taken as the tag figure (only relevant at turnover, where the spools stay fitted for the recirculation).

## 9. Judgement calls
- Flows for C1-C7 are set just above the velocity-governed minimum (velocity 0.2-1.3 percent above the requirement) to keep head margin; C8 runs at 240 gpm, set by the ST-601 25 ft allowable dP (24.0 ft) rather than by velocity. The same flow is used for every pumped stage of a circuit.
- PD-45 at 4.5 ppm, the middle of the "about 4 to 5 ppm" band; one 1-gal bottle per circuit either way.
- SiO2 levels chosen inside the bands with whole-package economy: C1 42/84 ppm (2 + 2 pails), others 45/90 ppm (1 + 1 pail); TTA 15 ppm (one bottle per copper circuit), maintenance kept at 15 ppm so the top-up adds no TTA.
- Turnover recirculation with the full-size bypass spools still fitted and the component isolation valves opened to fill the hold-up, so components see only the spool differential and remain far inside their M-602 limits; spools and strainers are removed at TM-4 after the turnover sample is accepted.
- C1 rinse (6 displacements, 2.788 occupied hours, 197,900 gal) is split into 3 occupied blocks on days [8, 9, 10] so that no day exceeds its water limit; idle gaps between the blocks are not counted as rinse time.
- Crews used: CREW-A (not more than two, 01 91 13 cl.1.7). Crew-shifts and skid-days are bought by the period (cl.3.10), so attended work is sequenced back-to-back to fill every charged shift.
- Discharge pH reported on rinse rows is 7.9, a value inside the SW-03 6.0-9.0 band between the spent solution (8.1-8.4) and makeup (7.6).
- Velocity class: decided from the components drawn inside each circuit tie-in limits (as for the eta rule of cl.3.6). C1 (pumps and buffer tank), C7 (coil bank) and C8 (break tank) contain no plate heat exchanger or cold-plate device, so their class is 2.0 ft/s and the 3.28 ft/s suspension velocity governs; C2-C6 are 4.0 ft/s.
- Between the end of its 24 h circulation and its slot in the rinse chain, each cleaned circuit is isolated with the spent solution standing in it (strainer cleaned at the end of circulation); the first rinse fill displaces the spent solution to its declared route (HAUL for C4-C8, SEWER for C1-C3). The circuit is never left drained, so freshly cleaned steel is not exposed to air. Idle standing time is not counted as contact or rinse time.
- Initial-flush and rinse batches are checked for TSS before release to MH-14; any batch above the 300 mg/L local limit is settled in the cascade holding tank or hauled (not expected after the 380 micron strainer).
- Hydrostatic test water is drained to MH-14 after the test; the four retested circuits stand empty and isolated until their initial flush.

## 10. Contractor-provided items excluded from the priced comparison (23 25 16 cl.3.10 f)
- Hydrostatic test pump with calibrated recorder for C3, C5, C6 and C7 (127.5 psig, 120 minutes); the flush skids are not used for the test.
- Portable holding tank(s) and transfer pump to carry each cascaded displacement (up to 6,406 gal) from the donor tie-in to the receiver tie-in (MER-1, MER-2, L3-N, L3-S, L3-W, ROOF, YARD).
- Fine filtration (<= 50 micron cartridge, and <= 300 micron for the CDUs) on the fill connection when the hold-up of CDU-301/302 and CP-311/321/331 is filled at turnover, since the 40-mesh (380 micron) VD-05 strainer does not reach the 50/300 micron limits of M-602/VD-04.

## 11. Safety - hazard communication (29 CFR 1910.1200)
Products brought on site: CL-100, CL-210 (DANGER - Skin Corr. 1B, Eye Dam. 1), PS-330, TA-90, PD-45 (WARNING - Eye Irrit. 2A) (VD-07). MO-500, NB-700 and SA-100 are not ordered.
- Written hazard communication program (1910.1200(e)(1)): this MOP section plus the site HazCom binder, with the list of hazardous chemicals above keyed to the SDS, the labeling system and the training plan; non-routine task hazards (chemical charging, draining spent solution, tanker transfer) are covered.
- Multi-employer site (1910.1200(e)(2)): the general contractor and other trades are given the chemical list, SDS access location, precautionary measures and the labeling system before chemicals arrive; barricades at each skid pad during charging and draining.
- Labels (1910.1200(f)): manufacturer labels on every pail and bottle kept legible; workplace labels (product identifier and hazard words/pictograms) on every secondary container, dosing pot and day tank, and on the circuit tie-in tags while a cleaning or passivation charge is in the circuit (f)(6).
- Safety data sheets (1910.1200(g)): VD-07 SDS for each product kept at the YARD pad and in each skid location binder, readily accessible to the crew during every shift (g)(8); SDS checked on receipt of each delivery (g)(1).
- Training (1910.1200(h)): every crew member trained before first handling (initial assignment) and whenever a new product is introduced, covering the operations where chemicals are present, detection of releases, the physical and health hazards, PPE and emergency procedures, and how to read labels and SDS (h)(3).
- Controls from the SDS (sections 4 and 8): chemical splash goggles, face shield, chemical-resistant gloves and apron for all transfers; portable emergency eyewash and quick-drench shower within 10 seconds of every handling point (skid pads and tanker standing); 15-minute eye flush first aid; secondary containment for pails at each pad; spill kit with neutraliser; no mixing of products outside the dosing pot.
- Other hazards: exclusion zone and pressure-rated hose restraints during hydrostatic tests (127.5 psig) and flushing (temporary equipment rated 150 psig); lock-out of tie-in valves; temporary power connections by the general contractor to SW-04 panels only; vacuum tanker operations at the YARD pad only; no discharge to storm or Tull Creek.

## 12. Cost (23 25 16 cl.3.10)
Skid rental $7,820.00; crew $16,400.00; water $4,490.18; effluent $9,111.41; chemicals $6,694.00; total $44,515.59.

| Circuit | Skid | Crew | Water | Effluent | Chemicals | Total |
|---|---|---|---|---|---|---|
| C1 | 1,460.70 | 2,018.40 | 1,951.08 | 2,110.09 | 1,722.00 | 9,262.27 |
| C2 | 1,175.22 | 1,858.40 | 307.02 | 328.48 | 660.00 | 4,329.13 |
| C3 | 1,529.80 | 2,058.94 | 384.32 | 410.49 | 660.00 | 5,043.54 |
| C4 | 705.07 | 1,973.58 | 415.48 | 1,394.22 | 752.00 | 5,240.35 |
| C5 | 648.37 | 2,141.02 | 492.73 | 1,559.80 | 752.00 | 5,593.93 |
| C6 | 717.85 | 2,136.51 | 323.28 | 1,029.37 | 800.00 | 5,007.02 |
| C7 | 723.55 | 2,226.43 | 316.54 | 1,032.11 | 640.00 | 4,938.64 |
| C8 | 859.45 | 1,986.71 | 299.72 | 1,246.84 | 708.00 | 5,100.73 |

Chemical orders (whole packages, rounded per dosing row; order day = first-use day - lead time - 1):
- PS-330: 18 x 5 gal (lead 18 d, first use day 10, order by day -9).
- CL-100: 24 x 5 gal (lead 10 d, first use day 7, order by day -4).
- CL-210: 6 x 5 gal (lead 14 d, first use day 11, order by day -4).
- TA-90: 4 x 1 gal (lead 12 d, first use day 11, order by day -2).
- PD-45: 8 x 1 gal (lead 7 d, first use day 7, order by day -1).

